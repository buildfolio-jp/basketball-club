"""Local Excel-backed equipment choices; events retain their own name snapshots."""
import base64, json, secrets, hashlib, re,time
import admin_access, local_fees
DEFAULTS=['ボールケース','救急箱','タイマー','作戦板','ユニフォーム']
HEADERS=['操作','備品ID','備品名']
def init(c):
 c.execute('CREATE TABLE IF NOT EXISTS equipment_master(id TEXT PRIMARY KEY,name TEXT UNIQUE)')
 if not c.execute("SELECT 1 FROM meta WHERE key='equipment_seeded'").fetchone():
  c.executemany('INSERT OR IGNORE INTO equipment_master VALUES(?,?)',[(f'equipment{i+1}',n) for i,n in enumerate(DEFAULTS)])
  c.execute("INSERT INTO meta VALUES('equipment_seeded','1')")
def read(c):return [dict(r) for r in c.execute('SELECT * FROM equipment_master ORDER BY rowid')]
def apply(c,u,d):
 if not admin_access.full(u):raise PermissionError('管理者のみ備品マスターを変更できます。')
 try:raw=base64.b64decode(d.get('content',''),validate=True)
 except Exception:raise ValueError('Excelを読み込めません。')
 if not 0<len(raw)<=5*1024*1024:raise ValueError('Excelは5MB以内にしてください。')
 rows=local_fees.parse(raw,'備品マスター',HEADERS);records=[];seen=set()
 if len(rows)>1000:raise ValueError('備品は1000行以内にしてください。')
 for action,rid,name in rows:
  if not any((action,rid,name)):continue
  if action not in ('','登録・更新','削除'):raise ValueError('操作は登録・更新か削除にしてください。')
  if not rid:rid='eq_'+hashlib.sha256(name.encode()).hexdigest()[:16]
  if not re.fullmatch(r'[A-Za-z0-9_-]{1,50}',rid) or rid in seen:raise ValueError('備品IDは重複のない半角英数字にしてください。')
  if action!='削除' and not 0<len(name)<=80:raise ValueError('備品名は1〜80文字で入力してください。')
  seen.add(rid);records.append((action,rid,name))
 candidate={}
 for action,rid,name in records:
  if action=='削除':candidate.pop(rid,None)
  else:candidate[rid]=name
 if len(candidate.values())!=len(set(candidate.values())):raise ValueError('備品名が重複しています。')
 c.execute('DELETE FROM equipment_master');c.executemany('INSERT INTO equipment_master VALUES(?,?)',candidate.items())
 return {'ok':True,'equipment_master':read(c)}
def save_event(c,eid,items):
 if not isinstance(items,list) or len(items)>30:raise ValueError('必要な備品は30件までです。')
 clean=[];seen=set()
 for item in items:
  if not isinstance(item,dict) or not isinstance(item.get('name'),str) or not 0<len(item['name'].strip())<=80 or type(item.get('required')) is not bool:raise ValueError('備品名を確認してください。')
  name=item['name'].strip()
  if name in seen:raise ValueError('同じ備品を重複して選択しないでください。')
  seen.add(name);clean.append({'name':name,'required':item['required']})
 row=c.execute('SELECT * FROM event_briefings WHERE event_id=?',(eid,)).fetchone()
 event=c.execute('SELECT note FROM events WHERE id=?',(eid,)).fetchone()
 base={'event_id':eid,'mode':'all','member_ids':[],'names':[],'note':event['note'] if event else '','map_url':'','address':'','files':[],'updated':time.strftime('%Y-%m-%d %H:%M:%S')}
 draft=json.loads(row['draft']) if row else dict(base)
 published=json.loads(row['published']) if row and row['published'] else dict(base)
 for value in (draft,published):value['equipment_items']=clean;value['revision']=secrets.token_hex(12);value['updated']=time.strftime('%Y-%m-%d %H:%M:%S')
 c.execute('INSERT OR REPLACE INTO event_briefings VALUES(?,?,?)',(eid,json.dumps(draft,ensure_ascii=False),json.dumps(published,ensure_ascii=False)))
