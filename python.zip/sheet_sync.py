"""Server-side Google Sheets export queue. Credentials never reach the browser."""
import json, os, re, time, urllib.request
TABLES=('users','member_families','member_categories','member_schools','member_enrollment','events','event_details','event_addresses','reports','results','trials','staff_activity','staff_activity_approvals','portal_items','portal_entries','private_messages','withdrawals','family_payment_methods','family_payment_receipts','payment_method_history','fee_ledger','fee_amounts','fee_adjustments','fee_collection_receipts','shop_products','shop_orders','shop_order_items','shop_order_lines','basket_notes','basket_note_statuses','worksheets','worksheet_answers','finance_reports','finance_entries','logistics_settings','logistics_answers','logistics_plans','logistics_expenses','logistics_messages','logistics_history','logistics_confirmations','submission_files','skill_videos')
def init(c):
 c.execute("INSERT OR IGNORE INTO meta VALUES('sheet_sync',?)",(json.dumps({'url':'','revision':0,'sent_revision':0,'updated':'','error':''}),))
def state(c):return json.loads(c.execute("SELECT value FROM meta WHERE key='sheet_sync'").fetchone()[0])
def save(c,s):c.execute("UPDATE meta SET value=? WHERE key='sheet_sync'",(json.dumps(s,ensure_ascii=False),))
def status(c):
 s=state(c);ready=bool(os.environ.get('CHEETAHS_SHEETS_WEBHOOK') and os.environ.get('CHEETAHS_SHEETS_SECRET'))
 return {**s,'configured':ready,'browser_demo':os.environ.get('CHEETAHS_BROWSER_DEMO')=='1','pending':s['revision']>s['sent_revision']}
def mark(c):
 s=state(c);s['revision']+=1;save(c,s)
def configure(c,d):
 url=str(d.get('url','')).strip()
 if not re.fullmatch(r'https://docs\.google\.com/spreadsheets/d/[A-Za-z0-9_-]+(?:/[^\s]*)?',url):raise ValueError('Googleスプレッドシートの共有URLを入力してください。')
 s=state(c);s.update(url=url,revision=s['revision']+1,error='');save(c,s);return {'ok':True,'sheet_sync':status(c)}
def snapshot(c):
 available={r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")};sheets=[]
 forbidden={'hash','password','token','token_hash','signature','content'}
 for table in TABLES:
  if table not in available:continue
  cols=[r[1] for r in c.execute('PRAGMA table_info('+table+')') if r[1] not in forbidden]
  rows=[]
  for record in c.execute('SELECT '+','.join('"'+k+'"' for k in cols)+' FROM '+table):
   values=[]
   for key,value in zip(cols,record):
    if table=='withdrawals' and key=='body':
     b=json.loads(value);b.pop('signature',None);value=json.dumps(b,ensure_ascii=False)
    if isinstance(value,bytes):value='添付ファイル（サイトに保管）'
    values.append(value if value is not None else '')
   rows.append(values)
  sheets.append({'name':'管理_'+table,'headers':cols,'rows':rows})
 # Editable billing settings are versioned separately from operation tables.
 row=c.execute("SELECT value FROM meta WHERE key='billing_plan'").fetchone()
 if row:
  import billing_plan
  for name,headers,rows in billing_plan.sheets(json.loads(row[0])):sheets.append({'name':'管理_'+name,'headers':headers,'rows':rows})
 return sheets
def run(connect,lock):
 while True:
  try:
   with lock:
    with connect() as c:s=state(c);tables=snapshot(c) if s['revision']>s['sent_revision'] else None
   endpoint=os.environ.get('CHEETAHS_SHEETS_WEBHOOK','');secret=os.environ.get('CHEETAHS_SHEETS_SECRET','')
   if tables is not None and s['url'] and secret and re.fullmatch(r'https://script.google.com/macros/s/[A-Za-z0-9_-]+/exec',endpoint):
    payload=json.dumps({'secret':secret,'spreadsheet_id':s['url'].split('/d/')[1].split('/')[0],'revision':s['revision'],'sheets':tables},ensure_ascii=False).encode()
    request=urllib.request.Request(endpoint,data=payload,headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(request,timeout=60) as response:result=json.loads(response.read())
    if result.get('ok') is not True:raise ValueError('スプレッドシート側の接続設定・編集権限を確認してください。')
    with lock:
     with connect() as c:
      latest=state(c);latest.update(sent_revision=s['revision'],updated=time.strftime('%Y-%m-%d %H:%M:%S'),error='');save(c,latest)
  except Exception:
   with lock:
    with connect() as c:
     latest=state(c);latest['error']='スプレッドシートへの同期に失敗しました。接続を確認してください。自動再試行します。';save(c,latest)
  time.sleep(30)
