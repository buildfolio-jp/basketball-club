"""Date-oriented attendance and an Excel member selector with portable formulas."""
from collections import Counter
from datetime import date

def formula(text,cached='',percent=False):
    return {'formula':text,'cached':cached,'percent':percent}

def sheets(d):
    users=[u for u in d['users'] if u['role']=='member']
    reports=sorted(d['reports'],key=lambda r:(r['date'],r['event_id'],r['user_id']))
    meta={(r['user_id'],r['event_id']):r for r in d.get('attendance_meta',[])}
    daily=[]
    for r in reports:
        m=meta.get((r['user_id'],r['event_id']),{})
        daily.append([r['date'],r['title'],r['user_id'],r['name'],r.get('attendance') or '未回答',r.get('actual') or '未確認',m.get('note',''),m.get('reviewed_at',''),m.get('updated',r['updated'])])
    records=[];counts=Counter()
    for r in reversed(reports):
        uid=r['user_id'];counts[uid]+=1;m=meta.get((uid,r['event_id']),{})
        records.append([uid+'|'+str(counts[uid]),uid,r['name'],r['date'],r['title'],r.get('attendance') or '未回答',r.get('actual') or '未確認',m.get('note',''),m.get('reviewed_at','')])
    choices=[[u['name']+'（'+u['id']+'）',u['id'],u['name']] for u in users]
    uid=users[0]['id'] if users else '';today=date.today().isoformat()
    selected=[r for r in records if r[1]==uid]
    past=[r for r in selected if r[3]<=today]
    attended=sum(r[6] in ('出席','遅刻','早退','遅刻・早退') for r in past)
    absent=sum(r[6]=='欠席' for r in past);confirmed=attended+absent
    n=max(2,len(records)+1);m=max(2,len(users)+1)
    source=f"'出欠集計データ'!$A$2:$I${n}"
    def count(status):
        return f'COUNTIFS(\'出欠集計データ\'!$B$2:$B${n},$B$3,\'出欠集計データ\'!$D$2:$D${n},"<="&$B$5,\'出欠集計データ\'!$G$2:$G${n},"{status}")'
    rows=[['会員を選択',choices[0][0] if choices else ''],
          ['会員ID',formula(f'IFERROR(VLOOKUP(B2,\'会員選択リスト\'!$A$2:$C${m},2,FALSE),"")',uid)],
          ['氏名',formula(f'IFERROR(VLOOKUP(B2,\'会員選択リスト\'!$A$2:$C${m},3,FALSE),"")',users[0]['name'] if users else '')],
          ['集計基準日',today],
          ['集計対象','基準日まで・実際の出欠を確認済みの活動'],
          ['確認済み活動数',formula('B8+B9',confirmed)],
          ['参加数（遅刻・早退含む）',formula('+'.join(count(s) for s in ('出席','遅刻','早退','遅刻・早退')),attended)],
          ['欠席数',formula(count('欠席'),absent)],
          ['出席率',formula('IF(B7=0,"",B8/B7)',attended/confirmed if confirmed else '',True)],
          ['計算方法','参加数 ÷ 確認済み活動数。未確認・未来の予定は除外。'],
          ['表示について','履歴は新しい日付順。記録がない場合、出席率は空欄。'],
          ['保存について','出欠更新時に再出力。会員選択は閲覧専用です。'],
          ['日付','練習・試合名','出欠予定','実際の出欠','出欠の連絡事項','コーチ確認日時']]
    for i in range(1,max(20,max(counts.values(),default=0))+1):
        record=selected[i-1] if i<=len(selected) else None
        rows.append([formula(f'IFERROR(VLOOKUP($B$3&"|{i}",{source},{ci},FALSE),"")',record[ci-1] if record else '') for ci in (4,5,6,7,8,9)])
    return [('日付別出欠',['日付','練習・試合名','会員ID','氏名','出欠予定','実際の出欠','出欠の連絡事項','コーチ確認日時','出欠更新日時'],daily),
            ('会員別出席',['会員別の出席確認','','','','',''],rows),
            ('会員選択リスト',['選択名','会員ID','氏名'],choices),
            ('出欠集計データ',['照合キー','会員ID','氏名','日付','練習・試合名','出欠予定','実際の出欠','出欠の連絡事項','コーチ確認日時'],records)]
