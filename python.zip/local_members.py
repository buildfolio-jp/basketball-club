"""Local-only workbook input. Private contact columns are never imported."""
import hashlib,json,re,time,zipfile
from pathlib import Path
from xml.sax.saxutils import escape
import local_fees,school_year,enrollment,credentials
import xml.etree.ElementTree as ET
HEADERS={
 '会員入力':['会員ID','氏名','学年','活動区分','家族ID','在籍状況','初期パスワード','保護者氏名（ローカルのみ）','住所（ローカルのみ）','電話番号（ローカルのみ）','メール（ローカルのみ）','LINE ID（ローカルのみ）','学校名'],
 'スタッフ入力':['会員ID','氏名','担当学年','スタッフ区分','権限','在籍状況','初期パスワード','住所（ローカルのみ）','電話番号（ローカルのみ）','メール（ローカルのみ）','LINE ID（ローカルのみ）']}
GROUPS={'男子A','男子B','女子A','女子B','U15A','U15B'}
def init(c):
 enrollment.init(c)
 c.execute('CREATE TABLE IF NOT EXISTS member_schools(user_id TEXT PRIMARY KEY,school TEXT)')
 c.execute('CREATE TABLE IF NOT EXISTS staff_profiles(user_id TEXT PRIMARY KEY,kind TEXT)')
def status(c):
 r=c.execute("SELECT value FROM meta WHERE key='member_input_status'").fetchone()
 return json.loads(r[0]) if r else {'ok':False,'message':'会員スタッフ入力.xlsxを保存すると反映します。'}
def parse(content,c):
 result=[];seen=set()
 for sheet,headers in HEADERS.items():
  legacy=False
  try:sheet_rows=local_fees.parse(content,sheet,headers)
  except ValueError:
   if sheet!='会員入力':raise
   sheet_rows=local_fees.parse(content,sheet,headers[:-1]);legacy=True
  for number,row in enumerate(sheet_rows,2):
   core=row[:7]
   if not any(core):continue
   uid,name,grade,x,y,active,pw=core
   def error(message):raise ValueError(f'{sheet} {number}行目：{message}')
   if not re.fullmatch(r'[A-Za-z0-9_-]{1,40}',uid):error('会員IDは40文字以内の半角英数字・ハイフン・下線にしてください。')
   if uid in seen:error('同じ会員IDが重複しています。')
   seen.add(uid)
   if not name or len(name)>100 or len(grade)>40:error('氏名・学年を確認してください。')
   if active not in ('在籍','休会','退会','停止'):error('在籍状況は「在籍」「休会」「退会」です。')
   old=c.execute('SELECT * FROM users WHERE id=?',(uid,)).fetchone()
   member=sheet=='会員入力'
   if old and (old['role']=='member')!=member:error('会員とスタッフの相互変更はできません。別IDを使用してください。')
   if not old and credentials.taken(c,uid):error('このログインIDは使用されています。')
   if not old and not 8<=len(pw)<=128:error('新規IDには8〜128文字の初期パスワードを入力してください。')
   if member:
    cats=[v.strip() for v in re.split('[、,]',x) if v.strip()]
    if not cats or any(v not in GROUPS for v in cats):error('活動区分は男子A・男子B・女子A・女子B・U15A・U15Bから入力してください。')
    if y and not re.fullmatch(r'[A-Za-z0-9_-]{1,40}',y):error('家族IDの形式を確認してください。')
    role='member';kind='';family=y;categories='、'.join(dict.fromkeys(cats))
   else:
    if x not in ('コーチ','スタッフ'):error('スタッフ区分は「コーチ」「スタッフ」です。')
    if y not in ('コーチ','スタッフ','管理者'):error('権限は「コーチ」「スタッフ」「管理者」です。')
    role='admin' if y=='管理者' else 'coach';kind=x;family='';categories=''
   school=row[-1].strip() if member and not legacy else None
   if school is not None and len(school)>150:error('学校名は150文字以内です。')
   result.append({'school':school,'id':uid,'name':name,'grade':grade,'role':role,'enrollment_status':'退会' if active=='停止' else active,'active':int(active in ('在籍','休会')),'categories':categories,'family_id':family,'staff_kind':kind,'password':pw if not old else ''})
 return result

def sync(c,path,hash_password):
 if not path.exists():return False
 raw=path.read_bytes();digest=hashlib.sha256(raw).hexdigest()
 old=status(c)
 if old.get('digest')==digest:return False
 state={'digest':digest,'ok':False,'updated':time.strftime('%Y-%m-%d %H:%M:%S')}
 try:
  records=parse(raw,c)
  baseline_row=c.execute("SELECT value FROM meta WHERE key='member_input_baseline'").fetchone()
  baseline=json.loads(baseline_row[0]) if baseline_row else {}
  next_baseline={r['id']:{k:v for k,v in r.items() if k!='password'} for r in records}
  records=[r for r in records if next_baseline[r['id']]!=baseline.get(r['id'])]
  admins={r[0] for r in c.execute("SELECT id FROM users WHERE role='admin' AND active=1")}
  for r in records:
   admins.discard(r['id'])
   if r['role']=='admin' and r['active']:admins.add(r['id'])
  if not admins:raise ValueError('有効な管理者を最低1名残してください。')
  for r in records:
   olduser=c.execute('SELECT * FROM users WHERE id=?',(r['id'],)).fetchone()
   if olduser and baseline.get(r['id'],{}).get('grade')==r['grade']:r['grade']=olduser['grade']
   h=olduser['hash'] if olduser else hash_password(r['password'])
   c.execute('INSERT INTO users VALUES(?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,grade=excluded.grade,role=excluded.role,active=excluded.active',(r['id'],r['name'],r['grade'],r['role'],h,r['active']))
   if r['role']=='member':
    previous=enrollment.read(c,r['id'])
    
    if not olduser or baseline.get(r['id'],{}).get('enrollment_status')!=r['enrollment_status']:
     enrollment.save(c,r['id'],r['enrollment_status'],previous['reason'],previous['note'])
    if r.get('school') is not None:c.execute('INSERT OR REPLACE INTO member_schools VALUES(?,?)',(r['id'],r['school']))
    # Only a changed grade is treated as a manual correction.
    if not olduser or olduser['grade']!=r['grade']:school_year.anchor(c,r['id'],r['grade'])
    c.execute('INSERT OR REPLACE INTO member_categories VALUES(?,?)',(r['id'],r['categories']))
    c.execute('DELETE FROM member_families WHERE user_id=?',(r['id'],))
    if r['family_id']:c.execute('INSERT INTO member_families VALUES(?,?)',(r['id'],r['family_id']))
   else:c.execute('INSERT OR REPLACE INTO staff_profiles VALUES(?,?)',(r['id'],r['staff_kind']))
  baseline.update(next_baseline)
  c.execute('INSERT OR REPLACE INTO meta VALUES(?,?)',('member_input_baseline',json.dumps(baseline,ensure_ascii=False)))
  state.update(ok=True,message=f"会員{sum(r['role']=='member' for r in records)}名・スタッフ{sum(r['role']!='member' for r in records)}名を反映しました。")
 except (ValueError,KeyError,StopIteration,zipfile.BadZipFile,IndexError,ET.ParseError) as e:
  state['message']=str(e) or 'Excelの形式を確認してください。'
 c.execute('INSERT OR REPLACE INTO meta VALUES(?,?)',('member_input_status',json.dumps(state,ensure_ascii=False)))
 return True

def ensure_template(path):
 """Portable blank input workbook; never overwrite an existing local master."""
 if path.exists():
  upgrade_school_header(path)
  return
 from excel_export import sheet_xml
 path.parent.mkdir(parents=True,exist_ok=True)
 sheets=list(HEADERS.items())
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
  z.writestr('[Content_Types].xml','<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'+''.join(f'<Override PartName="/xl/worksheets/sheet{i}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' for i in (1,2))+'</Types>')
  z.writestr('_rels/.rels','<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
  z.writestr('xl/workbook.xml','<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>'+''.join(f'<sheet name="{escape(name)}" sheetId="{i}" r:id="rId{i}"/>' for i,(name,_) in enumerate(sheets,1))+'</sheets></workbook>')
  z.writestr('xl/_rels/workbook.xml.rels','<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'+''.join(f'<Relationship Id="rId{i}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{i}.xml"/>' for i in (1,2))+'</Relationships>')
  for i,(_,headers) in enumerate(sheets,1):
   # Strip style IDs because this simple input workbook uses Excel defaults.
   xml=re.sub(r' s="\d+"','',sheet_xml(headers,[]))
   z.writestr(f'xl/worksheets/sheet{i}.xml',xml)

def upgrade_school_header(path):
 """Append the school header without changing rows, retaining a pre-migration copy."""
 import io
 raw=path.read_bytes()
 try:local_fees.parse(raw,'会員入力',HEADERS['会員入力']);return
 except ValueError:pass
 try:local_fees.parse(raw,'会員入力',HEADERS['会員入力'][:-1])
 except (ValueError,KeyError):return
 ns=local_fees.NS;namespace='{'+ns['s']+'}'
 with zipfile.ZipFile(io.BytesIO(raw)) as source:
  book=ET.fromstring(source.read('xl/workbook.xml'));sheet=next(s for s in book.findall('s:sheets/s:sheet',ns) if s.get('name')=='会員入力')
  rid=sheet.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id');rel=next(r for r in ET.fromstring(source.read('xl/_rels/workbook.xml.rels')) if r.get('Id')==rid);target=rel.get('Target');name=target.lstrip('/') if target.startswith('/') else 'xl/'+target
  xml=ET.fromstring(source.read(name));row=xml.find('s:sheetData/s:row',ns);cell=ET.SubElement(row,namespace+'c',{'r':'M1','t':'inlineStr'});text=ET.SubElement(ET.SubElement(cell,namespace+'is'),namespace+'t');text.text='学校名'
  backup=path.with_name(path.stem+'-学校名追加前.xlsx')
  if not backup.exists():backup.write_bytes(raw)
  temp=path.with_suffix('.school.tmp.xlsx')
  with zipfile.ZipFile(temp,'w',zipfile.ZIP_DEFLATED) as out:
   for item in source.infolist():out.writestr(item,ET.tostring(xml,encoding='utf-8',xml_declaration=True) if item.filename==name else source.read(item.filename))
 temp.replace(path)
