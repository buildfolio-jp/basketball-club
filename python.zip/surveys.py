import json,time,hashlib
from datetime import datetime,timezone,timedelta
JST=timezone(timedelta(hours=9))
CLOSED_MESSAGE="回答時間外です。直接コーチへご連絡お願いします"
def check_deadline(c,item_id):
    row=c.execute("SELECT deadline FROM survey_deadlines WHERE item_id=?",(item_id,)).fetchone()
    if row and row[0] and datetime.now(JST)>=datetime.fromisoformat(row[0]).replace(tzinfo=JST):
        raise ValueError(CLOSED_MESSAGE)

def init(c):
    c.execute('CREATE TABLE IF NOT EXISTS survey_forms(item_id TEXT PRIMARY KEY,kind TEXT,menus TEXT)')
    c.execute('CREATE TABLE IF NOT EXISTS survey_deadlines(item_id TEXT PRIMARY KEY,deadline TEXT)')
    c.execute('CREATE TABLE IF NOT EXISTS lunch_answers(item_id TEXT,user_id TEXT,body TEXT,updated TEXT,PRIMARY KEY(item_id,user_id))')
    if not c.execute("SELECT 1 FROM meta WHERE key='lunch_seed'").fetchone():
        c.execute("INSERT OR IGNORE INTO portal_items VALUES('lunch-demo','surveys','お弁当の注文アンケート（サンプル）','練習試合のお弁当注文を回答してください。メニュー・金額はサンプルです。回答だけでは決済・業者への注文は発生しません。',0)")
        c.execute("INSERT OR IGNORE INTO survey_forms VALUES('lunch-demo','lunch',?)",(json.dumps([{'name':'からあげ弁当','price':600},{'name':'ハンバーグ弁当','price':650},{'name':'焼き魚弁当','price':700}],ensure_ascii=False),))
        c.execute("INSERT INTO meta VALUES('lunch_seed','1')")
    if not c.execute("SELECT 1 FROM meta WHERE key='survey_deadline_demo'").fetchone():
        future=(datetime.now(JST)+timedelta(days=30)).strftime('%Y-%m-%dT23:59')
        past=(datetime.now(JST)-timedelta(days=1)).strftime('%Y-%m-%dT18:00')
        c.execute("INSERT OR IGNORE INTO survey_deadlines VALUES('lunch-demo',?)",(future,))
        c.execute("INSERT OR IGNORE INTO portal_items VALUES('expired-survey-demo','surveys','練習試合の送迎アンケート（期限切れサンプル）','送迎へのご協力についてのアンケートです。回答期限を過ぎた場合の表示を確認できます。',0)")
        c.execute("INSERT OR IGNORE INTO survey_forms VALUES('expired-survey-demo','text','[]')")
        c.execute("INSERT OR IGNORE INTO survey_deadlines VALUES('expired-survey-demo',?)",(past,))
        c.execute("INSERT INTO meta VALUES('survey_deadline_demo','1')")

def forms(c):
    result=[]
    for row in c.execute("SELECT f.*,i.title,i.body,d.deadline FROM survey_forms f JOIN portal_items i ON i.id=f.item_id LEFT JOIN survey_deadlines d ON d.item_id=f.item_id WHERE i.kind='surveys'"):
        r=dict(row);r['menus']=json.loads(r['menus']);r['revision']=hashlib.sha256(json.dumps(r,ensure_ascii=False,sort_keys=True).encode()).hexdigest();result.append(r)
    return result
def read(c,u):
    return {'forms':forms(c),'answers':[{'item_id':r['item_id'],'user_id':r['user_id'],'name':r['name'],'updated':r['updated'],**json.loads(r['body'])} for r in c.execute('SELECT a.*,u.name FROM lunch_answers a JOIN users u ON u.id=a.user_id'+(' WHERE a.user_id=?' if u['role']=='member' else ''),(u['id'],) if u['role']=='member' else ())]}
def configure(c,rid,d):
    deadline=str(d.get('deadline','')).strip()
    if deadline:
        try: deadline=datetime.strptime(deadline,'%Y-%m-%dT%H:%M').strftime('%Y-%m-%dT%H:%M')
        except ValueError: raise ValueError('回答期限の日時を確認してください。')
    kind=d.get('survey_type','text')
    if kind not in ('text','lunch','camp'):raise ValueError('アンケート形式を選択してください。')
    menus=[]
    if kind=='lunch':
        for line in str(d.get('menu_lines','')).splitlines():
            if not line.strip():continue
            parts=line.rsplit('|',1)
            if len(parts)!=2 or not parts[0].strip() or len(parts[0].strip())>60 or not parts[1].strip().isdigit() or not 0<=int(parts[1])<=100000:raise ValueError('メニューは「からあげ弁当|600」の形式で入力してください。')
            menus.append({'name':parts[0].strip(),'price':int(parts[1])})
        if not 1<=len(menus)<=20 or len({m['name'] for m in menus})!=len(menus):raise ValueError('重複しないメニューを1〜20種類登録してください。')
    c.execute('INSERT OR REPLACE INTO survey_deadlines VALUES(?,?)',(rid,deadline))
    c.execute('INSERT OR REPLACE INTO survey_forms VALUES(?,?,?)',(rid,kind,json.dumps(menus,ensure_ascii=False)))
def answer(c,u,d):
    if u['role']!='member':raise ValueError('会員のみ回答できます。')
    form=next((f for f in forms(c) if f['item_id']==d.get('item_id') and f['kind']=='lunch'),None)
    if not form or d.get('revision')!=form['revision']:raise ValueError('アンケート内容が更新されています。画面を更新してください。')
    check_deadline(c,form['item_id'])
    order=d.get('order')
    if order not in ('はい','いいえ'):raise ValueError('注文の有無を選択してください。')
    body={'title':form['title'],'order':order,'who':'','meals':[],'total':0,'revision':form['revision']}
    if order=='はい':
        who=d.get('who');meals=d.get('meals')
        if who not in ('子供のみ','保護者のみ','両方') or not isinstance(meals,list) or not 1<=len(meals)<=20:raise ValueError('注文する方・個数を確認してください。')
        groups=[]
        for meal in meals:
            if not isinstance(meal,dict):raise ValueError('メニューを確認してください。')
            group=meal.get('group');index=meal.get('menu')
            if group not in ('子供','保護者') or isinstance(index,bool) or not isinstance(index,int) or not 0<=index<len(form['menus']):raise ValueError('すべてのお弁当のメニューを選択してください。')
            body['meals'].append({'group':group,**form['menus'][index]});groups.append(group)
        expected={'子供のみ':{'子供'},'保護者のみ':{'保護者'},'両方':{'子供','保護者'}}[who]
        if set(groups)!=expected:raise ValueError('注文する方と個数が一致していません。')
        body['who']=who;body['total']=sum(m['price'] for m in body['meals'])
    c.execute('INSERT OR REPLACE INTO lunch_answers VALUES(?,?,?,?)',(form['item_id'],u['id'],json.dumps(body,ensure_ascii=False),time.strftime('%Y-%m-%d %H:%M:%S')))


def camp_body(c,u,item_id,d):
    if u['role']!='member':raise ValueError('会員のみ回答できます。')
    form=next((f for f in forms(c) if f['item_id']==item_id and f['kind']=='camp'),None)
    if not form or d.get('revision')!=form['revision']:raise ValueError('アンケート内容が更新されています。画面を更新してください。')
    lines=[]
    for key,label in (('watch','保護者見守り'),('serving','配膳')):
        value=d.get(key)
        if value not in ('可能','不可能','一部可能'):raise ValueError(label+'の可否を選択してください。')
        line=label+'：'+value
        if value=='一部可能':
            start=str(d.get(key+'_start',''));end=str(d.get(key+'_end',''))
            try:
                a=datetime.strptime(start,'%H:%M');b=datetime.strptime(end,'%H:%M')
            except ValueError:raise ValueError(label+'の開始・終了時刻を選択してください。')
            if a>=b:raise ValueError(label+'の終了時刻は開始時刻より後にしてください。')
            line+='（'+a.strftime('%H:%M')+'〜'+b.strftime('%H:%M')+'）'
        lines.append(line)
    note=str(d.get('note','')).strip()
    if len(note)>2000:raise ValueError('備考は2000文字以内にしてください。')
    if note:lines.append('備考：'+note)
    return '\n'.join(lines)
