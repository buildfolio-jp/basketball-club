"""Authenticated temporary uploads; final endpoints still validate access and files."""
import sqlite3,time,secrets,hashlib,base64

def connect(folder):
 c=sqlite3.connect(folder/'upload-staging.sqlite3');c.row_factory=sqlite3.Row
 c.execute('CREATE TABLE IF NOT EXISTS uploads(id TEXT PRIMARY KEY,owner TEXT,digest TEXT,content TEXT,created REAL)')
 c.execute('DELETE FROM uploads WHERE created<?',(time.time()-3600,));return c

def stage(folder,u,d):
 if not u:raise PermissionError('ログインしてください。')
 content=d.get('content')
 if not isinstance(content,str) or not 0<len(content)<=14*1024*1024:raise ValueError('1件10MB以下にしてください。')
 try:raw=base64.b64decode(content,validate=True)
 except Exception:raise ValueError('ファイルが不正です。')
 if len(raw)>10*1024*1024:raise ValueError('1件10MB以下にしてください。')
 digest=hashlib.sha256(raw).hexdigest()
 with connect(folder) as c:
  old=c.execute('SELECT id FROM uploads WHERE owner=? AND digest=?',(u['id'],digest)).fetchone()
  if old:return old['id']
  if c.execute('SELECT COUNT(*) FROM uploads WHERE owner=?',(u['id'],)).fetchone()[0]>=60:raise ValueError('一時保存が多いため、現在のファイルを保存してから追加してください。')
  token=secrets.token_hex(24);c.execute('INSERT INTO uploads VALUES(?,?,?,?,?)',(token,u['id'],digest,content,time.time()));return token

def hydrate(folder,u,d):
 tokens=[]
 def walk(v):
  if isinstance(v,list):return [walk(x) for x in v]
  if not isinstance(v,dict):return v
  if '_staged_upload' in v:
   if not u:raise PermissionError('ログインしてください。')
   if len(tokens)>=30:raise ValueError('ファイルは30件までです。')
   token=v['_staged_upload']
   with connect(folder) as c:row=c.execute('SELECT content FROM uploads WHERE id=? AND owner=?',(token,u['id'])).fetchone()
   if not row:raise ValueError('添付の一時保存期限が切れました。ファイルを選び直してください。')
   tokens.append(token);return row['content']
  return {k:walk(x) for k,x in v.items()}
 return walk(d),tokens

def discard(folder,u,tokens):
 if u and tokens:
  with connect(folder) as c:c.executemany('DELETE FROM uploads WHERE id=? AND owner=?',[(t,u['id']) for t in tokens])
