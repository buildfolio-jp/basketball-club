"""Excel choice labels mapped to established application behaviors."""
import base64,io,json,zipfile,xml.etree.ElementTree as ET
import admin_access,equipment_master,venues
# Label variants retain their explicit base behavior, so authorization and aggregates stay consistent.
SPECS=[
 ('role','権限',['権限'],[['member','会員'],['coach','コーチ'],['admin','管理者']]),
 ('attendance','出欠',['出欠','出欠予定','実際の出欠'],[(x,x) for x in ['出席','欠席','遅刻','早退','遅刻・早退','未確認','未定']]),
 ('method','支払い方法',['支払い方法','実際に受け取った支払い方法'],[(x,x) for x in ['クレジットカード','コンビニ決済']]),
 ('enrollment','在籍状況',['在籍状況'],[(x,x) for x in ['在籍','即日休会','指定日休会','即日退会','指定日退会']]),
 ('grade','学年',['学年'],[(x,x) for x in ['年長',*[f'小学{i}年' for i in range(1,7)],*[f'中学{i}年' for i in range(1,4)]]]),
 ('category','カテゴリ',['カテゴリー','カテゴリー区分','対象チーム','活動区分'],[(x,x) for x in ['男子A','男子B','女子U９','女子U12','U15アドバンス','U15ベーシック','体験']]),
 ('activity','活動内容',['活動内容'],[(x,x) for x in ['練習','練習試合','試合']]),
 ('cycle','支払い期間',['支払い期間'],[(x,x) for x in ['毎月払い','半年払い','年払い']]),
 ('account_type','会計区分',['会計区分'],[(x,x) for x in ['一般会計','特別会計','NEW YEARチャレンジカップ','合宿']]),
 ('direction','収支',['収支'],[(x,x) for x in ['支出','収入']]),
 ('message_type','連絡の種類',['連絡の種類'],[(x,x) for x in ['欠席連絡','早退連絡','遅刻連絡']]),
 ('ride','配車協力',['今回、配車に協力できますか？'],[(x,x) for x in ['可能','不可','条件付きで可能']]),
 ('ride_direction','配車の方向',['協力できる方向','方向'],[(x,x) for x in ['往復','行き','帰り']]),
 ('mode','参加対象',['参加対象'],[['all','活動区分の全員'],['selected','選択した会員']]),
 ('permission','画面ごとの権限',[],[['none','非表示'],['view','閲覧のみ'],['edit','編集可能']]),
 ('coach_kind','コーチの種類',['コーチの種類'],[(x,x) for x in ['閲覧中心','運営コーチ','個別設定']]),
 ('referee','審判資格',['審判資格'],[(x,x) for x in ['あり','なし']]),
 ('published','公開状態',['公開状態'],[['0','下書き'],['1','公開する']]),
 ('input_type','入力形式',['入力形式'],[['text','短い文章'],['textarea','長い文章'],['select','選択式']]),
 ('review_kind','口コミの種類',['口コミの種類'],[['trial','体験者（写真なし）'],['member','会員（写真・バスケ歴あり）']]),
 ('reason','休会退会の理由',['停止理由'],[(x,x) for x in ['けが・病気','家庭の事情','学業・受験','長期欠席','その他']]),
 ('notification','登録通知',['登録完了のお知らせ方法'],[['email','メール'],['line','LINE']]),
 ('visibility','試合記録の公開範囲',['公開範囲'],[['draft','下書き（スタッフのみ）'],['personal','各会員は自分の記録のみ'],['team','会員はベンチメンバー全員も閲覧可能']]),
 ('survey_type','アンケート形式',['アンケート形式'],[['text','自由記入'],['camp','合宿（見守り・配膳）'],['lunch','お弁当注文']]),
 ('order','弁当の注文可否',['1. お弁当を注文しますか'],[(x,x) for x in ['はい','いいえ']]),
 ('who','弁当の注文者',['2. 注文する方'],[(x,x) for x in ['子供のみ','保護者のみ','両方']]),
 ('scope','会費個別設定の適用範囲',['適用する範囲'],[['once','この期間だけ（途中入会の初回など）'],['ongoing','この期間以降も同じ金額']]),
 ('apply','会費個別設定の適用時期',['いつの請求に適用するか'],[['current','今回の請求'],['next','次回の請求']]),
 ('answer_type','配車撮影の回答形式',['回答形式'],[['text','text'],['select','select']]),
 ('equipment','チーム備品',[],[]),('venue','会場',[],[])
]
HEADERS=['表示名','処理区分・住所']
NS={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
def init(c):c.execute('CREATE TABLE IF NOT EXISTS choice_masters(kind TEXT PRIMARY KEY,options TEXT)')
def read(c):
 saved={r[0]:json.loads(r[1]) for r in c.execute('SELECT * FROM choice_masters')}
 result=[{'kind':k,'title':t,'labels':labels,'options':saved.get(k,[{'value':v,'label':l} for v,l in opts]),'defaults':[{'value':v,'label':l} for v,l in opts]} for k,t,labels,opts in SPECS if opts]
 result += [{'kind':'extra','title':target,'labels':[target],'options':options,'defaults':[]} for target,options in saved.get('__extra__',{}).items()]
 return result
def column(n):
 s=''
 while n:n,r=divmod(n-1,26);s=chr(65+r)+s
 return s
def cells(raw,sheet_name='選択肢マスター'):
 with zipfile.ZipFile(io.BytesIO(raw)) as z:
  if sum(i.file_size for i in z.infolist())>10000000:raise ValueError('Excelのサイズが大きすぎます。')
  book=ET.fromstring(z.read('xl/workbook.xml'));sheet=next((s for s in book.findall('s:sheets/s:sheet',NS) if s.get('name')==sheet_name),None)
  if sheet is None:raise ValueError('「'+sheet_name+'」シートが必要です。')
  rid=sheet.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id');rel=next(r for r in ET.fromstring(z.read('xl/_rels/workbook.xml.rels')) if r.get('Id')==rid);target=rel.get('Target');path=target.lstrip('/') if target.startswith('/') else 'xl/'+target
  strings=[''.join(n.itertext()) for n in ET.fromstring(z.read('xl/sharedStrings.xml'))] if 'xl/sharedStrings.xml' in z.namelist() else []
  out={}
  for cell in ET.fromstring(z.read(path)).findall('.//s:sheetData/s:row/s:c',NS):
   if cell.find('s:f',NS) is not None:raise ValueError('マスターは数式ではなく文字を入力してください。')
   value=cell.findtext('s:v','',NS)
   if cell.get('t')=='s':value=strings[int(value)]
   elif cell.get('t')=='inlineStr':value=''.join(cell.find('s:is',NS).itertext())
   out[cell.get('r')]=value.strip()
  return out
def apply(c,u,d):
 if not admin_access.full(u):raise PermissionError('マスターの変更は管理者のみです。')
 try:raw=base64.b64decode(d.get('content',''),validate=True)
 except Exception:raise ValueError('Excelを読み込めません。')
 if not 0<len(raw)<=5*1024*1024:raise ValueError('Excelは5MB以内にしてください。')
 values=cells(raw);parsed={}
 for i,(kind,title,labels,opts) in enumerate(SPECS):
  a,b=column(i*3+1),column(i*3+2)
  if values.get(a+'3')!='■ '+title:raise ValueError(title+'の見出しを変更しないでください。')
  lookup={l:v for v,l in opts};rows=[];seen=set()
  for n in range(5,105):
   label,base=values.get(a+str(n),''),values.get(b+str(n),'')
   if not label and not base:continue
   if not label or len(label)>100 or label in seen:raise ValueError(title+'：名称の空欄・重複・文字数を確認してください。')
   seen.add(label)
   if opts:
    value=lookup.get(base)
    if value is None:raise ValueError(title+'：処理区分を選択してください。新しい名称にも既存の処理区分を指定します。')
   else:value=label
   if len(base)>500:raise ValueError('住所は500文字以内にしてください。')
   rows.append({'value':value,'label':label,'address':base if kind=='venue' else ''})
  if opts and not rows:raise ValueError(title+'には1件以上の選択肢を残してください。')
  parsed[kind]=rows
 # Additional controls can use their on-screen label without changing application behavior.
 extra_cells=cells(raw,'追加選択肢');extra={}
 for n in range(2,1002):
  target,label,base=[extra_cells.get(column(i)+str(n),'') for i in (1,2,3)]
  if not any((target,label,base)):continue
  if not all((target,label,base)) or any(len(x)>150 for x in (target,label,base)):raise ValueError('追加選択肢の項目名・表示名・元の選択肢を入力してください。')
  extra.setdefault(target,[]).append({'label':label,'base':base,'value':base})
 for target,rows in extra.items():
  if len({r['label'] for r in rows})!=len(rows):raise ValueError('追加選択肢の表示名が重複しています。')
 parsed['__extra__']=extra
 for kind,rows in parsed.items():
  if kind=='equipment':
   import hashlib
   c.execute('DELETE FROM equipment_master');c.executemany('INSERT INTO equipment_master VALUES(?,?)',[('eq_'+hashlib.sha256(r['label'].encode()).hexdigest()[:16],r['label']) for r in rows])
  elif kind=='venue':
   import hashlib,secrets
   c.execute('DELETE FROM venues');c.executemany('INSERT INTO venues VALUES(?,?,?,?)',[('venue_'+hashlib.sha256(r['label'].encode()).hexdigest()[:16],r['label'],r['address'],secrets.token_hex(12)) for r in rows])
  else:c.execute('INSERT OR REPLACE INTO choice_masters VALUES(?,?)',(kind,json.dumps(rows,ensure_ascii=False)))
 return {'ok':True,'choice_masters':read(c),'equipment_master':equipment_master.read(c),'venues':venues.listing(c)}

def workbook(c,template):
 """Populate the styled template with the currently registered choice masters."""
 current={r['kind']:r['options'] for r in read(c)};updates={};extra_updates={}
 for i,(kind,title,labels,opts) in enumerate(SPECS):
  a,b=column(i*3+1),column(i*3+2);base=dict(opts)
  if kind=='equipment':rows=[(r['name'],'') for r in equipment_master.read(c)]
  elif kind=='venue':rows=[(r['name'],r['address']) for r in venues.listing(c)]
  else:rows=[(r['label'],base[r['value']]) for r in current[kind]]
  for n in range(5,105):updates[a+str(n)],updates[b+str(n)]=rows[n-5] if n-5<len(rows) else ('','')
 extra=c.execute("SELECT options FROM choice_masters WHERE kind='__extra__'").fetchone();rows=[(target,r['label'],r['base']) for target,rs in (json.loads(extra[0]) if extra else {}).items() for r in rs]
 for n in range(2,max(102,len(rows)+2)):
  for j,val in enumerate(rows[n-2] if n-2<len(rows) else ('','',''),1):extra_updates[column(j)+str(n)]=val
 ns='{'+NS['s']+'}';out=io.BytesIO()
 with zipfile.ZipFile(io.BytesIO(template)) as source,zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as target:
  for item in source.infolist():
   data=source.read(item.filename);changes=updates if item.filename=='xl/worksheets/sheet3.xml' else extra_updates if item.filename=='xl/worksheets/sheet4.xml' else None
   if changes is not None:
    root=ET.fromstring(data);sd=root.find(ns+'sheetData');row_map={int(r.get('r')):r for r in sd};cell_map={cell.get('r'):cell for row in sd for cell in row}
    for ref,text in changes.items():
     cell=cell_map.get(ref)
     if cell is None:
      number=int(''.join(x for x in ref if x.isdigit()));row=row_map.get(number)
      if row is None:row=ET.SubElement(sd,ns+'row',{'r':str(number)});row_map[number]=row
      cell=ET.SubElement(row,ns+'c',{'r':ref})
     for child in list(cell):cell.remove(child)
     cell.set('t','inlineStr');ET.SubElement(ET.SubElement(cell,ns+'is'),ns+'t').text=text
    data=ET.tostring(root,encoding='utf-8',xml_declaration=True)
   target.writestr(item,data)
 return out.getvalue()
