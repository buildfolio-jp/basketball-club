"""Enrollment and suspension of new invoices; historical invoices are retained."""
import time,datetime
REASONS=['けが・病気','家庭の事情','学業・受験','長期欠席','その他']
def init(c):
 c.execute("CREATE TABLE IF NOT EXISTS member_enrollment(user_id TEXT PRIMARY KEY,status TEXT,reason TEXT,note TEXT,revision INTEGER DEFAULT 0)")
 columns={r[1] for r in c.execute('PRAGMA table_info(member_enrollment)')}
 for name in ('pause_mode','pause_date'):
  if name not in columns:c.execute('ALTER TABLE member_enrollment ADD COLUMN '+name+" TEXT NOT NULL DEFAULT ''")
def today():return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9))).date().isoformat()
def read(c,uid):
 r=c.execute('SELECT * FROM member_enrollment WHERE user_id=?',(uid,)).fetchone()
 u=c.execute('SELECT active FROM users WHERE id=?',(uid,)).fetchone()
 result=dict(r) if r else {'status':'在籍','reason':'','note':'','revision':0,'pause_mode':'','pause_date':''}
 result['scheduled_status']=result['status']
 if u and not u[0]:result['status']='退会'
 elif result['status'] in ('休会','退会') and result.get('pause_mode')=='scheduled' and result.get('pause_date','')>today():result['status']='在籍'
 result['pause_pending']=result['status']=='在籍' and result.get('pause_mode')=='scheduled' and result.get('pause_date','')>today()
 return result
def paused(c,uid):return read(c,uid)['status'] in ('休会','退会')
def save(c,uid,status,reason='',note='',revision=None,pause_date=None):
 mode='scheduled' if status in ('指定日休会','指定日退会') else 'immediate' if status in ('休会','即時休会','即日休会','退会','即日退会') else ''
 if status in ('指定日休会','即時休会','即日休会'):status='休会'
 if status in ('指定日退会','即日退会'):status='退会'
 date=''
 if mode=='scheduled':
  try:date=datetime.date.fromisoformat(str(pause_date or '')).isoformat()
  except ValueError:raise ValueError('開始日を選択してください。')
 if status not in ('在籍','休会','退会'):raise ValueError('在籍状況を選択してください。')
 if not c.execute("SELECT 1 FROM users WHERE id=? AND role='member'",(uid,)).fetchone():raise ValueError('会員を選択してください。')
 old=read(c,uid)
 if revision is not None and int(revision)!=old['revision']:raise ValueError('在籍状況が変更されています。画面を読み直してください。')
 if status=='休会':
  if reason and reason not in REASONS:raise ValueError('停止理由を選択してください。')
  if len(note)>1000 or (reason=='その他' and not note.strip()):raise ValueError('その他の理由を1000文字以内で入力してください。')
 else:reason='';note=''
 c.execute('INSERT OR REPLACE INTO member_enrollment(user_id,status,reason,note,revision,pause_mode,pause_date) VALUES(?,?,?,?,?,?,?)',(uid,status,reason,note,old['revision']+1,mode,date))
 c.execute('UPDATE users SET active=? WHERE id=?',(int(status!='退会' or (mode=='scheduled' and date>today())),uid))
def attach(c,person):
 if person['role']=='member':person['enrollment']=read(c,person['id'])
 return person

def sync_due(c):
 c.execute("UPDATE users SET active=0 WHERE role='member' AND active=1 AND id IN (SELECT user_id FROM member_enrollment WHERE status='退会' AND pause_mode='scheduled' AND pause_date<=?)",(today(),))
