"""Versioned manual collection periods, category tariffs and per-member choices."""
import json,secrets,time,re,copy,base64
import local_fees,enrollment
CATEGORIES=['年長','小学1年生〜3年生','小学4年生〜6年生','中学1年生〜3年生A','中学1年生〜3年生B']
HEADERS={'徴収期間':['適用先','開始月','終了月'],'カテゴリー料金':['カテゴリー','月会費','入会金','年会費','スポーツ保険料','備考'],'会員別会費設定':['適用先','会員ID','氏名','カテゴリー','期間会費上書き','入会金','年会費','スポーツ保険','個別開始月','個別終了月','備考'],'会費設定版':['設定版']}
def monthnum(v):
    if not isinstance(v,str) or not re.fullmatch(r'20\d\d-(0[1-9]|1[0-2])',v):raise ValueError('年月はYYYY-MM形式（2000〜2099年）で入力してください。')
    y,m=map(int,v.split('-'));return y*12+m-1
def note(v):
    if not isinstance(v,str) or len(v)>2000:raise ValueError('備考は2000文字以内で入力してください。')
    return v

def money(v):
    if v in ('',None):return None
    if isinstance(v,bool) or not re.fullmatch(r'\d{1,8}',str(v)) or int(v)>10000000:raise ValueError('金額は0〜10000000円の整数、未設定は空欄にしてください。')
    return int(v)
def load(c):
    row=c.execute("SELECT value FROM meta WHERE key='billing_plan'").fetchone()
    if row:return json.loads(row[0])
    y=int(time.strftime('%Y'));m=int(time.strftime('%m'));y=y-1 if m<4 else y;start=f'{y}-04' if 4<=m<10 else f'{y}-10';end=f'{y}-09' if 4<=m<10 else f'{y+1}-03';ns=f'{y}-10' if 4<=m<10 else f'{y+1}-04';ne=f'{y+1}-03' if 4<=m<10 else f'{y+1}-09'
    return {'revision':'initial','enabled':False,'periods':{'今回':{'start':start,'end':end},'次回':{'start':ns,'end':ne}},'rates':[{ 'category':cat,'monthly':None,'entry':None,'annual':None,'insurance':None} for cat in CATEGORIES],'profiles':[]}
def read(c):
    value=load(c);known={(r['slot'],r['user_id']) for r in value['profiles']}
    for u in c.execute("SELECT id,name,grade FROM users WHERE role='member' AND active=1"):
        grade=u['grade'];cat=CATEGORIES[0] if grade=='年長' else CATEGORIES[3] if grade.startswith('中学') else CATEGORIES[1] if any(x in grade for x in ['1','2','3']) else CATEGORIES[2]
        for slot in ('今回','次回'):
            if (slot,u['id']) not in known:value['profiles'].append({'slot':slot,'user_id':u['id'],'name':u['name'],'category':cat,'override':None,'entry':False,'annual':grade.startswith('中学'),'insurance':False})
    names={u[0]:u[1] for u in c.execute("SELECT id,name FROM users WHERE role='member' AND active=1")}
    value['profiles']=[{**r,'name':names[r['user_id']]} for r in value['profiles'] if r['user_id'] in names]
    for p in value['profiles']:
        p['paused']=enrollment.paused(c,p['user_id'])
        saved=c.execute('SELECT amount FROM fee_ledger WHERE user_id=? AND start_month=?',(p['user_id'],value['periods'][p['slot']]['start'])).fetchone()
        p['saved_amount']=saved[0] if saved else 0
    return value
def profile_period(plan,profile):
    return profile.get('period') or plan['periods'][profile['slot']]

def line(plan,slot,uid,name):
    p=next((r for r in plan['profiles'] if r['slot']==slot and r['user_id']==uid),None)
    if not p:return {'id':uid,'name':name,'amount':None,'category':'未設定','components':[]}
    rate=next(r for r in plan['rates'] if r['category']==p['category']);period=profile_period(plan,p);months=monthnum(period['end'])-monthnum(period['start'])+1
    base=p['override'] if p['override'] is not None else rate['monthly']*months if rate['monthly'] is not None else None
    components=[{'label':'期間会費（個別設定）' if p['override'] is not None else f'月会費×{months}か月','amount':base}]
    for flag,label in [('entry','入会金'),('annual','年会費'),('insurance','スポーツ保険')]:
        if p[flag] and (flag!='annual' or period['start'].endswith('-04')):components.append({'label':label,'amount':rate[flag]})
    if p.get('paused'):
        components=[{'label':'休会（新しい請求を停止）','amount':p.get('saved_amount',0)}]
    total=sum(v['amount'] for v in components) if all(v['amount'] is not None for v in components) else None
    return {'id':uid,'name':name,'category':p['category'],'amount':total,'components':components,'period_start':period['start'],'period_end':period['end'],'annual_skipped':p['annual'] and not period['start'].endswith('-04')}
def summary(c,u,start):
    plan=read(c);slot=next((s for s,p in plan['periods'].items() if p['start']==start),None)
    if not slot:return None
    lines=[line(plan,slot,ch['id'],ch['name']) for ch in u.get('family_members',[u])]
    return {'lines':lines,'total':sum(x['amount'] for x in lines) if all(x['amount'] is not None for x in lines) else None,'family_override':False,'cycle':'半年払い','billing_plan':True}
def validate(c,d):
    old=read(c)
    if d.get('revision')!=old['revision']:raise ValueError('別の画面で設定が変更されています。最新のExcelまたは画面を読み直してください。')
    periods=d.get('periods',{});rates=d.get('rates',[]);profiles=d.get('profiles',[])
    if set(periods)!={'今回','次回'}:raise ValueError('今回・次回の徴収期間を設定してください。')
    for p in periods.values():
        start=monthnum(p.get('start'));end=monthnum(p.get('end'))
        if end-start!=5 or p['start'][-2:] not in ('04','10'):raise ValueError('徴収期間は4〜9月、または10〜翌年3月にしてください。')
    if monthnum(periods['次回']['start'])!=monthnum(periods['今回']['end'])+1:raise ValueError('次回は今回の翌月からの半年間にしてください。')
    if not isinstance(rates,list) or len(rates)!=5 or {r.get('category') for r in rates}!=set(CATEGORIES):raise ValueError('5つのカテゴリーをすべて設定してください。')
    rates=[{'category':r['category'],'note':note(r.get('note','')),**{k:money(r.get(k)) for k in ('monthly','entry','annual','insurance')}} for r in rates]
    users={r['id']:dict(r) for r in c.execute("SELECT id,name FROM users WHERE role='member' AND active=1")};seen=set();clean=[]
    for p in profiles:
        pair=(p.get('slot'),p.get('user_id'))
        if pair[0] not in periods or pair[1] not in users or pair in seen or p.get('category') not in CATEGORIES:raise ValueError('会員ID・適用先・カテゴリー・重複行を確認してください。')
        seen.add(pair)
        if any(type(p.get(k)) is not bool for k in ('entry','annual','insurance')):raise ValueError('各費用の有無を設定してください。')
        individual=p.get('period')
        if individual is not None:
            if not isinstance(individual,dict):raise ValueError('個別の開始月・終了月を設定してください。')
            a,b=monthnum(individual.get('start')),monthnum(individual.get('end'))
            if not 0<=b-a<12:raise ValueError('個別の期間は開始月から1〜12か月で設定してください。')
            individual={'start':individual['start'],'end':individual['end']}
        clean.append({'note':note(p.get('note','')),'period':individual,'slot':p['slot'],'user_id':p['user_id'],'name':users[p['user_id']]['name'],'category':p['category'],'override':money(p.get('override')),**{k:p[k] for k in ('entry','annual','insurance')}})
    if seen!={(s,uid) for s in periods for uid in users}:raise ValueError('在籍会員全員の今回・次回設定が必要です。最新のExcelを使用してください。')
    for row in clean:
        before=next((p for p in old['profiles'] if p['user_id']==row['user_id'] and p['slot']==row['slot']),{})
        row['paused']=before.get('paused',False)
        saved=c.execute('SELECT amount FROM fee_ledger WHERE user_id=? AND start_month=?',(row['user_id'],periods[row['slot']]['start'])).fetchone()
        row['saved_amount']=saved[0] if saved else 0
    for uid in users:
        current=next(r for r in clean if r['user_id']==uid and r['slot']=='今回')
        upcoming=next(r for r in clean if r['user_id']==uid and r['slot']=='次回')
        current_period=profile_period({'periods':periods},current);next_period=profile_period({'periods':periods},upcoming)
        if monthnum(next_period['start'])<=monthnum(current_period['end']):raise ValueError(users[uid]['name']+'：次回の開始月は今回の終了月より後にしてください。')
    return {'revision':old['revision'],'enabled':True,'periods':periods,'rates':rates,'profiles':clean}
def save(c,d):
    plan=validate(c,d);plan['revision']=secrets.token_hex(12)
    c.execute('INSERT OR REPLACE INTO meta VALUES(?,?)',('billing_plan',json.dumps(plan,ensure_ascii=False)))
    settings={'cycle':'半年払い','start_month':plan['periods']['今回']['start'],'updated':time.strftime('%Y-%m-%d %H:%M:%S'),'updated_by':'admin'}
    c.execute('INSERT OR REPLACE INTO meta VALUES(?,?)',('billing_settings',json.dumps(settings,ensure_ascii=False)))
    return plan
def sheets(plan):
    return [('徴収期間',HEADERS['徴収期間'],[[s,p['start'],p['end']] for s,p in plan['periods'].items()]),('カテゴリー料金',HEADERS['カテゴリー料金'],[[r['category']]+[r[k] for k in ('monthly','entry','annual','insurance')]+[r.get('note','')] for r in plan['rates']]),('会員別会費設定',HEADERS['会員別会費設定'],[[r['slot'],r['user_id'],r['name'],r['category'],r['override']]+['有' if r[k] else '無' for k in ('entry','annual','insurance')]+[(r.get('period') or {}).get(k,'') for k in ('start','end')]+[r.get('note','')] for r in plan['profiles']]),('会費設定版',HEADERS['会費設定版'],[[plan['revision']]])]
def import_file(c,d):
    try:raw=base64.b64decode(d.get('content',''),validate=True)
    except Exception:raise ValueError('Excelを読み込めません。')
    if len(raw)>5*1024*1024:raise ValueError('Excelは5MB以下にしてください。')
    try:
        tabs={}
        for name,headers in HEADERS.items():
            try:tabs[name]=local_fees.parse(raw,name,headers)
            except ValueError:
                if name=='カテゴリー料金':
                    old_rates={r['category']:r for r in read(c)['rates']}
                    tabs[name]=[row+[old_rates.get(row[0],{}).get('note','')] for row in local_fees.parse(raw,name,headers[:5])]
                elif name=='会員別会費設定':
                    old_profiles={(r['slot'],r['user_id']):r for r in read(c)['profiles']}
                    try:previous=local_fees.parse(raw,name,headers[:10])
                    except ValueError:previous=[row+[(old_profiles.get((row[0],row[1]),{}).get('period') or {}).get(k,'') for k in ('start','end')] for row in local_fees.parse(raw,name,headers[:8])]
                    tabs[name]=[row+[old_profiles.get((row[0],row[1]),{}).get('note','')] for row in previous]
                else:raise
    except Exception as e:raise ValueError('会費設定Excelを確認してください：'+str(e))
    if len(tabs['会費設定版'])!=1:raise ValueError('会費設定版を確認してください。')
    plan={'revision':tabs['会費設定版'][0][0],'periods':{},'rates':[],'profiles':[]}
    for slot,start,end in tabs['徴収期間']:
        if not any((slot,start,end)):continue
        if slot in plan['periods']:raise ValueError('徴収期間の行が重複しています。')
        plan['periods'][slot]={'start':start,'end':end}
    for cat,monthly,entry,annual,insurance,remarks in tabs['カテゴリー料金']:
        if cat:plan['rates'].append({'category':cat,'monthly':monthly,'entry':entry,'annual':annual,'insurance':insurance,'note':remarks})
    for slot,uid,name,cat,amount,entry,annual,insurance,start,end,remarks in tabs['会員別会費設定']:
        if not any((slot,uid,name,cat,amount,entry,annual,insurance)):continue
        if any(v not in ('有','無') for v in (entry,annual,insurance)):raise ValueError('費用の有無は「有」「無」で選択してください。')
        plan['profiles'].append({'slot':slot,'user_id':uid,'name':name,'category':cat,'override':amount,'entry':entry=='有','annual':annual=='有','insurance':insurance=='有','note':remarks,'period':{'start':start,'end':end} if start or end else None})
    return validate(c,plan)
