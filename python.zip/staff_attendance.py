"""Schedule-based staff attendance, independent of member reports and work logs."""
import datetime
import admin_access
STATUSES=('出席','欠席','遅刻・早退','未定')
def init(c):
 c.execute('CREATE TABLE IF NOT EXISTS staff_attendance(event_id TEXT,user_id TEXT,status TEXT,note TEXT,updated TEXT,updated_by TEXT,revision INTEGER,PRIMARY KEY(event_id,user_id))')
def allowed(c,u):
 return bool(u and c.execute("SELECT 1 FROM users WHERE id=? AND role IN ('coach','admin') AND active=1",(u['id'],)).fetchone())
def manages(u):return bool(not u.get('delegated_coach') and not u.get('delegated_officer') and admin_access.can(u,'staff-attendance',True))
def read(c,u):
 if not allowed(c,u):return {'available':False,'rows':[]}
 return {'available':True,'can_manage':manages(u),'events':[dict(r) for r in c.execute('SELECT id,title,date,time,place FROM events ORDER BY date,time')],'staff':[dict(r) for r in c.execute("SELECT id,name FROM users WHERE role IN ('coach','admin') AND active=1")],'rows':[dict(r) for r in c.execute('SELECT * FROM staff_attendance')]}
def save(c,u,d):
 if not allowed(c,u):raise PermissionError('スタッフ・管理者専用です。')
 uid=d.get('user_id');eid=d.get('event_id')
 if uid!=u['id'] and not manages(u):raise PermissionError('自分の出欠のみ登録できます。')
 if not c.execute("SELECT 1 FROM users WHERE id=? AND role IN ('coach','admin') AND active=1",(uid,)).fetchone():raise ValueError('在籍中のスタッフを選択してください。')
 if not c.execute('SELECT 1 FROM events WHERE id=?',(eid,)).fetchone():raise ValueError('日程が見つかりません。')
 status=d.get('status');note=d.get('note','')
 if status not in STATUSES or not isinstance(note,str) or len(note)>1000:raise ValueError('出欠を選択し、連絡事項は1000文字以内で入力してください。')
 old=c.execute('SELECT revision FROM staff_attendance WHERE event_id=? AND user_id=?',(eid,uid)).fetchone();revision=old[0] if old else 0
 if d.get('revision')!=revision:raise ValueError('出欠が更新されています。画面を開き直してください。')
 now=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9))).isoformat(timespec='seconds')
 c.execute('INSERT OR REPLACE INTO staff_attendance VALUES(?,?,?,?,?,?,?)',(eid,uid,status,note.strip(),now,u['id'],revision+1))
