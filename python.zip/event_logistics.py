"""Family-scoped ride and filming surveys, versioned assignments and settlement."""
import json,secrets,datetime,re,os,uuid
import scheduling
JST=datetime.timezone(datetime.timedelta(hours=9))
GROUPS=['男子A','男子B','女子U９','女子U12','U15アドバンス','U15ベーシック']
def now():return datetime.datetime.now(JST)
def stamp():return now().isoformat(timespec='seconds')
def encode(v):return json.dumps(v,ensure_ascii=False)
def manager(u):return bool(u and u['role']=='admin' and not u.get('delegated_coach') and not u.get('delegated_officer') and u.get('admin_rank')==1)
def require_manager(u):
 if not manager(u):raise PermissionError('配車・撮影の操作は管理者のみです。')
def init(c):
 c.executescript('''
 CREATE TABLE IF NOT EXISTS logistics_settings(event_id TEXT,kind TEXT,body TEXT,revision INTEGER,PRIMARY KEY(event_id,kind));
 CREATE TABLE IF NOT EXISTS logistics_answers(event_id TEXT,kind TEXT,family_id TEXT,body TEXT,updated TEXT,actor TEXT,PRIMARY KEY(event_id,kind,family_id));
 CREATE TABLE IF NOT EXISTS logistics_plans(event_id TEXT,kind TEXT,draft TEXT,published TEXT,version INTEGER,PRIMARY KEY(event_id,kind));
 CREATE TABLE IF NOT EXISTS logistics_confirmations(event_id TEXT,kind TEXT,family_id TEXT,version INTEGER,updated TEXT,PRIMARY KEY(event_id,kind,family_id));
 CREATE TABLE IF NOT EXISTS logistics_expenses(event_id TEXT,family_id TEXT,body TEXT,reviewed INTEGER,updated TEXT,PRIMARY KEY(event_id,family_id));
 CREATE TABLE IF NOT EXISTS logistics_history(event_id TEXT,kind TEXT,family_id TEXT,date TEXT,PRIMARY KEY(event_id,kind,family_id));
 CREATE TABLE IF NOT EXISTS logistics_messages(id TEXT PRIMARY KEY,dedup TEXT UNIQUE,event_id TEXT,kind TEXT,family_id TEXT,categories TEXT,type TEXT,mode TEXT,body TEXT,status TEXT,created TEXT,sent TEXT,error TEXT,retry_key TEXT);
 ''')
def family(c,uid):
 r=c.execute('SELECT family_id FROM member_families WHERE user_id=?',(uid,)).fetchone()
 return 'family:'+r[0] if r and r[0] else 'student:'+uid
def settings(c,eid,kind):
 if kind not in ('ride','film'):raise ValueError('配車・撮影を選択してください。')
 r=c.execute('SELECT * FROM logistics_settings WHERE event_id=? AND kind=?',(eid,kind)).fetchone()
 return {**json.loads(r['body']),'revision':r['revision']} if r else {'enabled':False,'deadline':'','remind_hours':6,'confirm_hours':30,'categories':[],'questions':[],'games':[],'costs':{},'revision':0}
def targets(c,e,s):
 out={};roster=c.execute('SELECT member_ids FROM match_rosters WHERE event_id=? AND published=1',(e['id'],)).fetchone();selected=set(json.loads(roster[0])) if roster else None
 for r in c.execute("SELECT u.id,u.name,m.categories FROM users u LEFT JOIN member_categories m ON m.user_id=u.id WHERE u.role='member' AND u.active=1"):
  cats=scheduling.categories(r['categories']);categories=set(s['categories'])
  if not cats&categories or not scheduling.eligible(c,r['id'],e) or (selected is not None and r['id'] not in selected):continue
  fid=family(c,r['id']);f=out.setdefault(fid,{'id':fid,'names':[],'children':[],'pending_children':[],'categories':[]});f['names'].append(r['name']);f['categories']=sorted(set(f['categories'])|(cats&categories))
  answer=c.execute('SELECT attendance FROM reports WHERE user_id=? AND event_id=?',(r['id'],e['id'])).fetchone()
  if answer and answer[0] in ('出席','遅刻','遅刻・早退'):f['children'].append({'id':r['id'],'name':r['name']})
  elif not answer or answer[0] in ('','未定'):f['pending_children'].append(r['name'])
 return out
def line_targets():
 path=os.environ.get('CHEETAHS_LINE_FAMILY_TARGETS_FILE','')
 if not path:return {}
 try:
  with open(path) as f:d=json.load(f)
  return {k:v for k,v in d.items() if isinstance(k,str) and isinstance(v,str) and re.fullmatch('U[0-9a-f]{32}',v)}
 except (OSError,ValueError,AttributeError):return {}
def plan(c,eid,kind):
 r=c.execute('SELECT * FROM logistics_plans WHERE event_id=? AND kind=?',(eid,kind)).fetchone()
 published=json.loads(r['published']) if r and r['published'] else None
 return {'draft':json.loads(r['draft']) if r else None,'published':published,'version':r['version'] if r else 0,'published_version':published.get('_version',r['version']) if published else 0}
def answers(c,eid,kind):return {r['family_id']:{**json.loads(r['body']),'updated':r['updated']} for r in c.execute('SELECT * FROM logistics_answers WHERE event_id=? AND kind=?',(eid,kind))}
def event(c,eid):
 r=c.execute('SELECT * FROM events WHERE id=?',(eid,)).fetchone()
 if not r:raise ValueError('日程がありません。')
 return dict(r)
def state(c,u,eid,kind):
 if u.get('delegated_officer') and not __import__('admin_access').can(u,'schedule'):raise PermissionError('日程の閲覧権限がありません。')
 e=event(c,eid);s=settings(c,eid,kind);fs=targets(c,e,s);p=plan(c,eid,kind);ans=answers(c,eid,kind);own=family(c,u['id']) if u['role']=='member' else None
 if own and (not s['enabled'] or own not in fs):raise PermissionError('このアンケートの対象ではありません。')
 if not own and u['role'] not in ('coach','admin'):raise PermissionError('閲覧できません。')
 confirmations={r['family_id']:r['updated'] for r in c.execute('SELECT * FROM logistics_confirmations WHERE event_id=? AND kind=? AND version=?',(eid,kind,p['published_version']))}
 linked=line_targets();people=[{**f,'answer':ans.get(fid),'confirmed':fid in confirmations,'linked':fid in linked} for fid,f in fs.items()]
 history=[dict(r) for r in c.execute('SELECT * FROM logistics_history ORDER BY date DESC')]
 expenses=[{**dict(r),'body':json.loads(r['body'])} for r in c.execute('SELECT * FROM logistics_expenses WHERE event_id=?',(eid,)) if not own or r['family_id']==own]
 result={'line_configured':bool(os.environ.get('CHEETAHS_LINE_CHANNEL_ACCESS_TOKEN')),'family_names':{fid:'・'.join(f['names']) for fid,f in fs.items()},'player_names':{p['id']:p['name'] for f in fs.values() for p in f['children']},'event':e,'kind':kind,'settings':s,'version':p['version'],'published_version':p['published_version'],'published':p['published'],'own':own,'family':fs.get(own),'answer':ans.get(own),'confirmed':own in confirmations,'expenses':expenses,'can_manage':manager(u),'history':history if not own else [r for r in history if r['family_id']==own]}
 if not own:result.update(families=people,draft=p['draft'],messages=[dict(r) for r in c.execute('SELECT * FROM logistics_messages WHERE event_id=? AND kind=? ORDER BY created DESC',(eid,kind))] if manager(u) else [])
 return result
def summary(c,u,events):
 out={}
 for e in events:
  kinds={}
  for kind in ('ride','film'):
   s=settings(c,e['id'],kind)
   if not s['enabled']:continue
   try:r=state(c,u,e['id'],kind)
   except PermissionError:continue
   kinds[kind]={k:r[k] for k in ('settings','answer','confirmed','published','version','family','own')}
   if 'families' in r:kinds[kind].update(total=len(r['families']),answered=sum(bool(f['answer']) for f in r['families']))
  if kinds:out[e['id']]=kinds
 return out

def integer(v,maximum=100):
 if type(v) is not int or not 0<=v<=maximum:raise ValueError('人数・金額を確認してください。')
 return v
def text(v,n=2000):
 if not isinstance(v,str) or len(v)>n:raise ValueError('入力が長すぎます。')
 return v.strip()
def deadline(s):
 try:return datetime.datetime.fromisoformat(s['deadline']).replace(tzinfo=JST)
 except (ValueError,TypeError):raise ValueError('回答期限を設定してください。')
def save_settings(c,u,e,kind,d):
 require_manager(u);old=settings(c,e['id'],kind)
 if d.get('revision')!=old['revision']:raise ValueError('設定が更新されています。開き直してください。')
 s=d.get('settings',{});cats=s.get('categories',[])
 if not isinstance(cats,list) or any(v not in GROUPS for v in cats):raise ValueError('カテゴリを確認してください。')
 s={'enabled':bool(s.get('enabled')),'deadline':text(s.get('deadline',''),30),'remind_hours':integer(s.get('remind_hours',6),720),'confirm_hours':integer(s.get('confirm_hours',30),720),'categories':list(dict.fromkeys(cats)),'questions':s.get('questions',[]),'games':s.get('games',[]),'costs':s.get('costs',{})}
 if s['enabled']:
  deadline(s)
  if not cats:raise ValueError('対象カテゴリを選択してください。')
 if not isinstance(s['questions'],list) or len(s['questions'])>30:raise ValueError('質問は30件以内にしてください。')
 clean=[]
 for q in s['questions']:
  options=q.get('options',[])
  if q.get('type') not in ('text','select') or not isinstance(options,list) or len(options)>30:raise ValueError('質問形式を確認してください。')
  clean.append({'id':text(q.get('id',''),80) or secrets.token_hex(8),'label':text(q.get('label',''),100),'type':q['type'],'options':[text(x,100) for x in options]})
 s['questions']=clean
 if not isinstance(s['games'],list) or len(s['games'])>100:raise ValueError('試合は100件以内にしてください。')
 s['games']=[{k:text(g.get(k,''),200) for k in ('id','date','time','opponent','court','number')} for g in s['games']]
 for g in s['games']:
  g['id']=g['id'] or secrets.token_hex(8)
  try:datetime.date.fromisoformat(g['date']);datetime.time.fromisoformat(g['time'].zfill(5))
  except ValueError:raise ValueError('試合の日付・時刻を確認してください。')
  if not g['opponent'] or not re.fullmatch(r'\d{1,2}:\d{2}',g['time']):raise ValueError('試合時間と対戦相手を入力してください。')
 if len({g['id'] for g in s['games']})!=len(s['games']):raise ValueError('同じ試合を重複登録できません。')
 if not isinstance(s['costs'],dict):raise ValueError('交通費を確認してください。')
 for k,v in s['costs'].items():
  if k not in ('gas','toll','parking'):raise ValueError('費目を確認してください。')
  if v is not None:integer(v,1000000)
 c.execute('INSERT OR REPLACE INTO logistics_settings VALUES(?,?,?,?)',(e['id'],kind,encode(s),old['revision']+1))

def save_answer(c,u,e,kind,d):
 if u['role']!='member':raise PermissionError('会員のみ回答できます。')
 s=settings(c,e['id'],kind);fs=targets(c,e,s);fid=family(c,u['id'])
 if not s['enabled'] or fid not in fs:raise PermissionError('対象家庭ではありません。')
 if now()>deadline(s) or plan(c,e['id'],kind)['published']:raise ValueError('回答期間は終了しています。')
 if d.get('revision')!=s['revision']:raise ValueError('質問が変更されています。開き直してください。')
 body=d.get('answer',{});out={'note':text(body.get('note','')),'extra':{},'questions':s['questions']}
 for q in s['questions']:
  value=text(body.get('extra',{}).get(q['id'],''))
  if q['type']=='select' and value not in q['options']:raise ValueError('追加質問の回答を選択してください。')
  out['extra'][q['id']]=value
 if kind=='ride':
  if body.get('available') not in ('可能','不可','条件付きで可能') or body.get('direction') not in ('往復','行き','帰り'):raise ValueError('配車の可否・方向を選択してください。')
  out.update(available=body['available'],direction=body['direction'],adults=integer(body.get('adults')),capacity=integer(body.get('capacity')),children=len(fs[fid]['children']))
  if d.get('confirmed_children')!=out['children']:raise ValueError('参加するお子さまの人数が変わりました。確認画面を開き直してください。')
 else:
  games=body.get('games',[])
  if not isinstance(games,list) or any(g not in {x['id'] for x in s['games']} for g in games):raise ValueError('撮影可能な試合を選択してください。')
  out['games']=list(dict.fromkeys(games))
 c.execute('INSERT OR REPLACE INTO logistics_answers VALUES(?,?,?,?,?,?)',(e['id'],kind,fid,encode(out),stamp(),u.get('login_id',u['id'])))

def fair_key(c,fid,kind,e):
 history=[dict(r) for r in c.execute('SELECT * FROM logistics_history WHERE kind=? AND date<? ORDER BY date DESC,event_id',(kind,e['date']))]
 dates=list(dict.fromkeys(r['event_id'] for r in history))[:3];owned=[r for r in history if r['family_id']==fid]
 year=int(e['date'][:4])-(int(e['date'][5:7])<4);start=f'{year}-04-01';end=f'{year+1}-04-01'
 return (sum(r['event_id'] in dates for r in owned),max((r['date'] for r in owned),default='0000'),sum(start<=r['date']<end for r in owned),fid)
def propose(c,e,kind):
 s=settings(c,e['id'],kind);fs=targets(c,e,s);ans=answers(c,e['id'],kind);out={'cars':[],'films':[],'warnings':[]}
 unanswered=[f['names'] for fid,f in fs.items() if fid not in ans]
 if unanswered:out['warnings'].append('未回答家庭があります。同行大人数を含め確認してください。')
 if any(f['pending_children'] for f in fs.values()):out['warnings'].append('出欠未定・未回答の選手は割り振りに含めていません。')
 order=sorted(fs,key=lambda f:fair_key(c,f,kind,e))
 if kind=='film':
  counts={f:0 for f in fs}
  for g in s['games']:
   eligible=[f for f in order if g['id'] in ans.get(f,{}).get('games',[])]
   fid=min(eligible,key=lambda f:(counts[f],fair_key(c,f,kind,e))) if eligible else ''
   if fid:counts[fid]+=1
   else:out['warnings'].append(g['time']+' '+g['opponent']+'：撮影担当候補なし')
   out['films'].append({'game_id':g['id'],'family_id':fid})
 else:
  if not any(f['children'] or ans.get(fid,{}).get('adults',0) for fid,f in fs.items()):return out
  for direction in ('行き','帰り'):
   candidates=[f for f in order if ans.get(f,{}).get('available') in ('可能','条件付きで可能') and ans[f]['direction'] in ('往復',direction)]
   selected=[]
   for fid in candidates:
    selected.append(fid)
    capacity=sum(ans[f]['capacity'] for f in selected)
    need=sum(len(f['children'])+ans.get(k,{}).get('adults',0) for k,f in fs.items() if k not in selected)
    if capacity>=need:break
   passengers=[p['id'] for fid,f in fs.items() if fid not in selected for p in f['children']]
   adults=sum(ans.get(fid,{}).get('adults',0) for fid in fs if fid not in selected)
   for fid in selected:
    free=ans[fid]['capacity'];children=passengers[:free];passengers=passengers[free:];take=min(adults,free-len(children));adults-=take
    out['cars'].append({'family_id':fid,'direction':direction,'car':'','children':[p['id'] for p in fs[fid]['children']]+children,'adults':ans[fid]['adults']+take})
    if ans[fid]['available']=='条件付きで可能':out['warnings'].append('条件付き回答：'+'・'.join(fs[fid]['names'])+' '+ans[fid]['note'])
   if passengers or adults:out['warnings'].append(f'{direction}：選手{len(passengers)}人・大人{adults}人の席が不足しています。')
 return out

def validate_plan(c,e,kind,body):
 s=settings(c,e['id'],kind);fs=targets(c,e,s);ans=answers(c,e['id'],kind)
 if not isinstance(body,dict):raise ValueError('割り振りを確認してください。')
 out={'cars':[],'films':[],'warnings':[]};children={p['id'] for f in fs.values() for p in f['children']}
 if kind=='film':
  if not s['games']:raise ValueError('撮影対象の試合を設定してください。')
  seen=set()
  for a in body.get('films',[]):
   g=a.get('game_id');f=a.get('family_id')
   if g in seen or g not in {x['id'] for x in s['games']} or f not in fs or g not in ans.get(f,{}).get('games',[]):raise ValueError('試合と撮影可能な担当家庭を確認してください。')
   seen.add(g);out['films'].append({'game_id':g,'family_id':f})
  if seen!={x['id'] for x in s['games']}:raise ValueError('すべての試合に撮影担当を設定してください。')
 else:
  for direction in ('行き','帰り'):
   seen=set();drivers=set();adult_total=0
   for a in body.get('cars',[]):
    if a.get('direction')!=direction:continue
    f=a.get('family_id');ids=a.get('children',[]);adult=integer(a.get('adults'));r=ans.get(f,{})
    if f in drivers or f not in fs or r.get('available') not in ('可能','条件付きで可能') or r.get('direction') not in ('往復',direction):raise ValueError('担当家庭の回答・行き帰りを確認してください。')
    if not isinstance(ids,list) or len(ids)!=len(set(ids)) or any(i not in children or i in seen for i in ids):raise ValueError('選手の重複・参加予定を確認してください。')
    own=len(fs[f]['children']);max_total=own+r['adults']+r['capacity']
    if len(ids)+adult>max_total:raise ValueError('乗車可能人数を超えています。')
    seen.update(ids);drivers.add(f);adult_total+=adult
    out['cars'].append({'family_id':f,'direction':direction,'car':text(a.get('car',''),100),'children':ids,'adults':adult})
   if seen!=children:raise ValueError(direction+'の乗車選手に不足があります。')
   if adult_total!=sum(ans.get(fid,{}).get('adults',0) for fid in fs):raise ValueError(direction+'の同行大人数が回答合計と一致しません。')
 return out

def recipients(c,e,kind,typ):
 s=settings(c,e['id'],kind);fs=targets(c,e,s);ans=answers(c,e['id'],kind);p=plan(c,e['id'],kind)
 if not s['enabled']:return {}
 if typ=='unanswered':return {} if p['published'] else {f:v for f,v in fs.items() if f not in ans}
 if typ=='unconfirmed':
  if not p['published']:return {}
  done={r[0] for r in c.execute('SELECT family_id FROM logistics_confirmations WHERE event_id=? AND kind=? AND version=?',(e['id'],kind,p['published_version']))};return {f:v for f,v in fs.items() if f not in done}
 if typ=='parking':
  if kind!='ride' or not p['published'] or 'parking' not in s['costs']:return {}
  drivers={a['family_id'] for a in p['published']['cars']};done={r[0] for r in c.execute('SELECT family_id FROM logistics_expenses WHERE event_id=?',(e['id'],))};return {f:v for f,v in fs.items() if f in drivers and f not in done}
 if typ=='result' and not p['published']:return {}
 return fs

def message_key(e,kind,fid,typ,s,p):
 revision=p['published_version'] if typ in ('result','unconfirmed','parking') else s['deadline'] if typ=='unanswered' else s['revision']
 return f"{e['id']}|{kind}|{fid}|{typ}|{revision}"

def enqueue(c,e,kind,typ,mode='manual'):
 if typ not in ('survey','unanswered','result','unconfirmed','parking'):raise ValueError('通知の種類を確認してください。')
 s=settings(c,e['id'],kind);p=plan(c,e['id'],kind);targets_=recipients(c,e,kind,typ);linked=line_targets();configured=bool(os.environ.get('CHEETAHS_LINE_CHANNEL_ACCESS_TOKEN'));count=0
 title={'ride':'配車','film':'撮影'}[kind];desc={'survey':'アンケートに回答してください。','unanswered':'アンケートが未回答です。','result':'確定内容をご確認ください。','unconfirmed':'確定内容が未確認です。','parking':'駐車場代が未報告です。'}[typ]
 body=f"{e['date']} {e['title']}\n{title}：{desc}\n回答期限：{s['deadline']}\n"+os.environ.get('CHEETAHS_PUBLIC_ORIGIN','')+'/#schedule?event='+e['id']
 for fid,f in targets_.items():
  dedup=message_key(e,kind,fid,typ,s,p)
  status='queued' if configured and fid in linked else '未送信（LINE未連携）'
  cur=c.execute('INSERT OR IGNORE INTO logistics_messages VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(str(uuid.uuid4()),dedup,e['id'],kind,fid,encode(f['categories']),typ,mode,body,status,stamp(),'','',str(uuid.uuid4())))
  count+=cur.rowcount
  if configured and fid in linked:c.execute("UPDATE logistics_messages SET status='queued' WHERE dedup=? AND status='未送信（LINE未連携）'",(dedup,))
 return {'count':count,'linked':sum(f in linked for f in targets_),'total':len(targets_),'configured':configured}

def mutate(c,u,d):
 if not u:raise PermissionError('ログインしてください。')
 eid=d.get('event_id');kind=d.get('kind');e=event(c,eid);s=settings(c,eid,kind);action=d.get('action');p=plan(c,eid,kind)
 if action=='settings':save_settings(c,u,e,kind,d)
 elif action=='answer':save_answer(c,u,e,kind,d)
 elif action=='confirm':
  state(c,u,eid,kind)
  if u['role']!='member' or not p['published'] or d.get('version')!=p['published_version']:raise ValueError('最新の確定内容を開いてください。')
  c.execute('INSERT OR REPLACE INTO logistics_confirmations VALUES(?,?,?,?,?)',(eid,kind,family(c,u['id']),p['published_version'],stamp()))
 elif action=='expense':
  if u['role']!='member' or kind!='ride':raise PermissionError('配車担当会員のみ報告できます。')
  fid=family(c,u['id']);state(c,u,eid,kind)
  if not p['published'] or fid not in {x['family_id'] for x in p['published']['cars']}:raise PermissionError('配車担当ではありません。')
  body={'account_type':__import__('accounting').account_type(d.get('account_type','一般会計')),'parking':integer(d.get('parking'),1000000),'additional':integer(d.get('additional'),1000000),'note':text(d.get('note',''))}
  c.execute('INSERT OR REPLACE INTO logistics_expenses VALUES(?,?,?,0,?)',(eid,fid,encode(body),stamp()))
 else:
  require_manager(u)
  if action in ('propose','draft','publish'):
   if d.get('version')!=p['version']:raise ValueError('割り振りが更新されています。開き直してください。')
   body=propose(c,e,kind) if action=='propose' else d.get('plan')
   if not isinstance(body,dict) or any(not isinstance(body.get(k,[]),list) or len(body.get(k,[]))>200 for k in ('cars','films')):raise ValueError('割り振りの形式を確認してください。')
   if action=='draft':
    body={'cars':[{'family_id':text(a.get('family_id',''),120),'direction':text(a.get('direction',''),10),'car':text(a.get('car',''),100),'adults':integer(a.get('adults',0)),'children':[text(x,80) for x in a.get('children',[])]} for a in body.get('cars',[])],'films':[{'game_id':text(a.get('game_id',''),200),'family_id':text(a.get('family_id') or '',120)} for a in body.get('films',[])],'warnings':[]}
   if action=='publish':
    body=validate_plan(c,e,kind,body);fs=targets(c,e,s)
    body.update(_version=p['version']+1,games=s['games'],family_names={f:'・'.join(v['names']) for f,v in fs.items()},player_names={x['id']:x['name'] for v in fs.values() for x in v['children']})
   c.execute('INSERT OR REPLACE INTO logistics_plans VALUES(?,?,?,?,?)',(eid,kind,encode(body),encode(body) if action=='publish' else (encode(p['published']) if p['published'] else ''),p['version']+1))
  elif action=='notify':return enqueue(c,e,kind,d.get('type'))
  elif action=='expense_review':c.execute('UPDATE logistics_expenses SET reviewed=? WHERE event_id=? AND family_id=?',(int(bool(d.get('reviewed'))),eid,d.get('family_id')))
  elif action=='history':
   if not p['published']:raise ValueError('先に確定してください。')
   if e['date']>now().date().isoformat():raise ValueError('実績は開催日以降に登録できます。')
   fs={x['family_id'] for x in p['published']['cars' if kind=='ride' else 'films']}
   c.execute('DELETE FROM logistics_history WHERE event_id=? AND kind=?',(eid,kind))
   for f in fs:c.execute('INSERT INTO logistics_history VALUES(?,?,?,?)',(eid,kind,f,e['date']))
  else:raise ValueError('操作を確認してください。')
 return {'ok':True}

def export_messages(c,u,eid):
 require_manager(u)
 import accounting,io
 from zipfile import ZipFile,ZIP_DEFLATED
 from excel_export import sheet_xml
 logs=[dict(r) for r in c.execute('SELECT m.*,e.title FROM logistics_messages m JOIN events e ON e.id=m.event_id WHERE m.event_id=? ORDER BY created',(eid,))]
 heads=['送信日時','自動／手動','種類','日程','カテゴリ','対象家庭','送信件数','成功／失敗','本文']
 types={'survey':'アンケート送信','unanswered':'未回答催促','result':'確定結果通知','unconfirmed':'未確認催促','parking':'駐車場代未報告通知'}
 rows=[[r['sent'] or r['created'],'自動' if r['mode']=='auto' else '手動',('配車' if r['kind']=='ride' else '撮影')+' '+types[r['type']],r['title'],'・'.join(json.loads(r['categories'])),r['family_id'],int(r['status'].startswith('成功')),r['status'],r['body']] for r in logs]
 original=accounting.xlsx_bytes({'year':now().year,'entries':[],'income':0,'expense':0,'balance':0});out=io.BytesIO()
 with ZipFile(io.BytesIO(original)) as src,ZipFile(out,'w',ZIP_DEFLATED) as dst:
  for name in src.namelist():
   value=src.read(name)
   if name=='xl/workbook.xml':value=value.decode().replace('収支報告','LINE送信履歴').replace('明細','集計').encode()
   if name=='xl/worksheets/sheet1.xml':value=sheet_xml(heads,rows).encode()
   if name=='xl/worksheets/sheet2.xml':value=sheet_xml(['項目','件数'],[['対象履歴',len(rows)],['成功（受付済み）',sum(r[6] for r in rows)]]).encode()
   dst.writestr(name,value)
 return out.getvalue()
