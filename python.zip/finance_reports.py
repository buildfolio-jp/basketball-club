"""Member receipts awaiting treasurer review; never booked automatically."""
import secrets,datetime,accounting,submission_files

def init(c):
 c.execute('CREATE TABLE IF NOT EXISTS finance_reports(id TEXT PRIMARY KEY,user_id TEXT,year INTEGER,date TEXT,category TEXT,amount INTEGER,note TEXT,status TEXT,entry_id TEXT,updated TEXT,revision TEXT)')
 if 'account_type' not in {r[1] for r in c.execute('PRAGMA table_info(finance_reports)')}:c.execute("ALTER TABLE finance_reports ADD COLUMN account_type TEXT NOT NULL DEFAULT '一般会計'")
def read(c,u,year=None):
 if not u:return []
 own=u['role']=='member'
 if not own:accounting.access(c,u,year)
 rs=c.execute('SELECT r.*,u.name FROM finance_reports r JOIN users u ON u.id=r.user_id WHERE '+('user_id=?' if own else 'year=?')+' ORDER BY updated DESC',(u['id'] if own else year,))
 return [{**dict(r),'files':submission_files.listing(c,'finance-report',r['id'])} for r in rs]
def submit(c,u,d):
 if not u or u['role']!='member':raise PermissionError('会員のみ報告できます。')
 date=datetime.date.fromisoformat(str(d.get('date','')));year=date.year-(date.month<4)
 category=d.get('category');amount=d.get('amount');note=str(d.get('note','')).strip()
 if category not in accounting.CATEGORIES[4:] or type(amount)is not int or not 0<=amount<=100000000 or len(note)>3000:raise ValueError('費目・金額・備考を確認してください。')
 if not d.get('uploads'):raise ValueError('レシート写真またはPDFを添付してください。')
 section=accounting.account_type(d.get('account_type','一般会計'))
 rid=secrets.token_hex(16)
 c.execute('INSERT INTO finance_reports VALUES(?,?,?,?,?,?,?,\'未確認\',\'\',?,?,?)',(rid,u['id'],year,date.isoformat(),category,amount,note,accounting.now(),secrets.token_hex(12),section))
 submission_files.add(c,'finance-report',rid,d['uploads'])
def review(c,u,d):
 r=c.execute('SELECT * FROM finance_reports WHERE id=?',(d.get('id'),)).fetchone()
 if not r:raise ValueError('報告がありません。')
 accounting.access(c,u,r['year'],True)
 if r['revision']!=d.get('revision'):raise ValueError('報告が更新されています。再読み込みしてください。')
 status=d.get('status')
 if status not in ('未確認','確認済み'):raise ValueError('確認状態を指定してください。')
 c.execute('UPDATE finance_reports SET status=?,revision=? WHERE id=?',(status,secrets.token_hex(12),r['id']))
 accounting.audit(c,u,'会員報告の確認',r['id'],{'status':status})
