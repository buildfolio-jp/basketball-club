"""One member schema for administrator forms and explicit Excel upserts/deletions."""
import base64,hashlib,json,re,secrets,zipfile,datetime
import xml.etree.ElementTree as ET
import accounts,admin_access,credentials,enrollment,school_year,local_fees
HEADERS=['操作','会員ID','氏名','学校名','学年','カテゴリー','家族ID','在籍状況','指定日','初期パスワード','保護者氏名','メールアドレス','電話番号']
KEYS=['action','id','name','school','grade','categories','family_id','enrollment_status','pause_date','password','parent_name','email','phone']
GROUPS=['男子A','男子B','女子U９','女子U12','U15アドバンス','U15ベーシック','体験']
STATUSES=['在籍','即日休会','指定日休会','即日退会','指定日退会']
def authorized(u):
 if not admin_access.full(u):raise PermissionError('管理者のみ会員を一括登録できます。')
def normalize(c,d):
 r={k:str(d.get(k,'') or '').strip() for k in KEYS};uid=r['id'];r['action']=r['action'] or '登録・更新'
 if not re.fullmatch(r'[A-Za-z0-9_-]{1,40}',uid):raise ValueError('会員IDは40文字以内の半角英数字・下線・ハイフンで入力してください。')
 old=c.execute('SELECT * FROM users WHERE id=?',(uid,)).fetchone()
 if old and old['role']!='member':raise ValueError('スタッフ・管理者のIDは会員として変更できません。')
 if r['action'] not in ('登録・更新','削除'):raise ValueError('操作は「登録・更新」または「削除」です。')
 if r['action']=='削除':
  if not old:raise ValueError('削除対象の会員IDがありません。')
  return r
 if c.execute('SELECT 1 FROM deleted_members WHERE user_id=?',(uid,)).fetchone():raise ValueError('削除済みのIDです。新しいIDで登録してください。')
 if not old and credentials.taken(c,uid):raise ValueError('会員IDは使用済みです。')
 if not r['name'] or len(r['name'])>100 or len(r['school'])>150:raise ValueError('氏名・学校名を確認してください。')
 if r['grade'] not in ['年長']+[f'小学{i}年' for i in range(1,7)]+[f'中学{i}年' for i in range(1,4)]:raise ValueError('学年を選択してください。')
 cats=[x.strip() for x in re.split('[、,]',r['categories']) if x.strip()];cats=[{'男子Aチーム':'男子A','男子Bチーム':'男子B','女子U9':'女子U９'}.get(x,x) for x in cats]
 if not cats or any(x not in GROUPS for x in cats):raise ValueError('カテゴリーを確認してください。')
 r['categories']='、'.join(dict.fromkeys(cats))
 if r['family_id'] and not re.fullmatch(r'[A-Za-z0-9_-]{1,40}',r['family_id']):raise ValueError('家族IDの形式を確認してください。')
 r['enrollment_status']=r['enrollment_status'] or '在籍'
 if r['enrollment_status'] not in STATUSES:raise ValueError('在籍状況を確認してください。')
 if r['enrollment_status'].startswith('指定日'):
  try:
   if r['pause_date'].replace('.','',1).isdigit():r['pause_date']=(datetime.date(1899,12,30)+datetime.timedelta(days=int(float(r['pause_date'])))).isoformat()
   r['pause_date']=datetime.date.fromisoformat(r['pause_date'].replace('/','-')).isoformat()
  except (ValueError,OverflowError):raise ValueError('指定日はYYYY-MM-DDで入力してください。')
 if r['password'] and not old and not 8<=len(r['password'])<=128:raise ValueError('初期パスワードは8〜128文字です。')
 if len(r['parent_name'])>100:raise ValueError('保護者氏名は100文字以内です。')
 if r['email']:r['email']=accounts.email(r['email'])
 if r['phone'] and not re.fullmatch(r'(?:0[0-9]{9,10}|\+[1-9][0-9]{7,14})',re.sub(r'[\s()（）-]','',r['phone'])):raise ValueError('電話番号を確認してください。')
 return r

def save(c,u,d,hash_password):
 authorized(u);r=normalize(c,d);uid=r['id']
 if r['action']=='削除':accounts.remove_member(c,u,{'user_id':uid});return '削除'
 old=c.execute('SELECT * FROM users WHERE id=?',(uid,)).fetchone()
 h=old['hash'] if old else hash_password(r['password'] or secrets.token_urlsafe(32))
 c.execute('INSERT INTO users VALUES(?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,grade=excluded.grade',(uid,r['name'],r['grade'],'member',h,1))
 if not old and not r['password']:
  c.execute('INSERT INTO student_only VALUES(?)',(uid,));c.execute('INSERT INTO member_access VALUES(?,0)',(uid,))
 previous=enrollment.read(c,uid)
 enrollment.save(c,uid,r['enrollment_status'],previous['reason'],previous['note'],pause_date=r['pause_date'])
 school_year.anchor(c,uid,r['grade'])
 c.execute('INSERT OR REPLACE INTO member_categories VALUES(?,?)',(uid,r['categories']))
 c.execute('INSERT OR REPLACE INTO member_schools VALUES(?,?)',(uid,r['school']))
 c.execute('DELETE FROM member_families WHERE user_id=?',(uid,))
 if r['family_id']:c.execute('INSERT INTO member_families VALUES(?,?)',(uid,r['family_id']))
 c.execute("INSERT INTO account_profiles VALUES(?,?,?,?,?) ON CONFLICT(login_id) DO UPDATE SET parent_name=excluded.parent_name,email=excluded.email",(uid,r['parent_name'],r['email'],accounts.now(),''))
 accounts.save_phone(c,uid,r);accounts.ensure_invites(c)
 if r['enrollment_status']=='即日退会':c.execute('DELETE FROM login_sessions WHERE user_id=? OR user_id IN (SELECT login_id FROM guardian_accounts WHERE student_id=?)',(uid,uid))
 return '更新' if old else '追加'

def apply(c,u,d,hash_password):
 authorized(u)
 try:raw=base64.b64decode(d.get('content',''),validate=True)
 except Exception:raise ValueError('Excelファイルを選択してください。')
 if not raw or len(raw)>5*1024*1024:raise ValueError('Excelは5MB以内です。')
 try:rows=local_fees.parse(raw,'会員登録',HEADERS)
 except (ValueError,KeyError,StopIteration,zipfile.BadZipFile,ET.ParseError,IndexError) as e:raise ValueError('指定の会員登録テンプレートを使用してください。 '+str(e))
 records=[];seen=set();fingerprints={};previous=d.get('previous') or {}
 if not isinstance(previous,dict):raise ValueError('読込履歴が不正です。')
 if len(rows)>1000:raise ValueError('一度に1000名までです。')
 for i,row in enumerate(rows,2):
  if not any(row):continue
  uid=row[1];digest=hashlib.sha256(json.dumps(row,ensure_ascii=False).encode()).hexdigest()
  if uid in seen:raise ValueError(f'{i}行目：会員IDが重複しています。')
  seen.add(uid);fingerprints[uid]=digest
  if previous.get(uid)==digest:continue
  try:records.append(normalize(c,dict(zip(KEYS,row))))
  except ValueError as e:raise ValueError(f'{i}行目：{e}')
 counts={'追加':0,'更新':0,'削除':0}
 for r in records:counts[save(c,u,r,hash_password)]+=1
 return {'ok':True,'counts':counts,'fingerprints':fingerprints}
