"""Administrator-only notebook form definitions."""
import json,uuid,admin_access
KEYS=('low-practice','low-match','high-practice','high-match')
def defaults(key):
 low=key.startswith('low');match=key.endswith('match');fields=[]
 def add(fid,label,kind='textarea',options=None):fields.append({'id':fid,'label':label,'type':kind,'options':options or []})
 if not low and not match:add('leader','今日のリーダー','text')
 add('goal','① きょうのもくひょう（まえの④とおなじでOK）' if low else '① 今日の目標（前回の④と同じでOK）')
 if match:
  for i in range(3):
   add('team_'+str(i),'② '+('しあいしたチーム ' if low else '試合したチーム ')+str(i+1),'text')
   add('result_'+str(i),'けっか '+str(i+1) if low else '結果 '+str(i+1)+'（例：97–58 勝ち）','select' if low else 'text',['かち','まけ','ひきわけ'] if low else [])
 else:
  for i in range(7 if low else 12):add('drill_'+str(i),'② '+('れんしゅうしたこと ' if low else '練習したこと ')+str(i+1),'text')
 if low:add('good','③ '+('しあい' if match else 'れんしゅう')+'でがんばったこと');add('bad','④ つぎのれんしゅうでがんばること')
 elif match:
  for fid,label in [('good_self','③ 試合でできたこと：自分'),('good_team','③ 試合でできたこと：チーム'),('bad_self','④ 試合でできなかったこと：自分'),('bad_team','④ 試合でできなかったこと：チーム')]:add(fid,label)
 else:add('good','③ 練習でできたこと');add('bad','④ 練習でできなかったこと')
 return {'revision':0,'fields':fields,'feedback':not low or match}
def read(c):
 r=c.execute("SELECT value FROM meta WHERE key='basket_note_templates'").fetchone();saved=json.loads(r[0]) if r else {}
 return {k:saved.get(k,defaults(k)) for k in KEYS}
def save(c,u,d):
 if not admin_access.full(u):raise PermissionError('管理者のみノート項目を変更できます。')
 key=d.get('key');forms=read(c)
 if key not in KEYS or d.get('revision')!=forms[key]['revision']:raise ValueError('設定が更新されています。開き直してください。')
 fields=d.get('fields');seen=set()
 if not isinstance(fields,list) or not 1<=len(fields)<=40:raise ValueError('項目は1〜40個にしてください。')
 for f in fields:
  if not isinstance(f,dict) or not isinstance(f.get('id'),str) or len(f['id'])>60 or f['id'] in seen or not isinstance(f.get('label'),str) or not 1<=len(f['label'])<=150 or f.get('type') not in ('text','textarea','select'):raise ValueError('項目名・形式を確認してください。')
  seen.add(f['id'])
  if not isinstance(f.get('options'),list) or len(f['options'])>20 or any(not isinstance(v,str) or not 1<=len(v)<=100 for v in f['options']) or (f['type']=='select' and len(f['options'])<2):raise ValueError('選択肢を2〜20個入力してください。')
 forms[key]={'revision':forms[key]['revision']+1,'fields':fields,'feedback':bool(d.get('feedback'))}
 c.execute('INSERT OR REPLACE INTO meta VALUES(?,?)',('basket_note_templates',json.dumps(forms,ensure_ascii=False)))
