import payment_methods
"""Collection view combines current/next settings and saved historical receipts."""
import billing_plan, fee_ledger, family_payments,enrollment

METHODS=[*payment_methods.METHODS,'旧方式','未登録']

def read(c,settings):
    ledger=fee_ledger.read(c)
    records={(r['user_id'],r['start_month']):dict(r) for r in ledger['invoices']}
    plan=billing_plan.read(c)
    methods={r['user_id']:r['method'] for r in ledger['methods']}
    periods={r['start_month']:{'start':r['start_month'],'end':r['end_month'],'slot':'過去の期間'} for r in records.values()}
    if plan['enabled']:
        for slot,period in plan['periods'].items():
            start,end=period['start'],period['end'];periods[start]={'start':start,'end':end,'slot':slot}
            for user in c.execute("SELECT id,name FROM users WHERE role='member' AND active=1"):
                if enrollment.paused(c,user['id']):continue
                key=(user['id'],start)
                if records.get(key,{}).get('confirmed'):continue
                line=billing_plan.line(plan,slot,user['id'],user['name'])
                profile=next(r for r in plan['profiles'] if r['slot']==slot and r['user_id']==user['id'])
                rate=next(r for r in plan['rates'] if r['category']==profile['category'])
                records[key]={'user_id':user['id'],'name':user['name'],'start_month':start,'end_month':end,'period_start':line['period_start'],'period_end':line['period_end'],'amount':line['amount'],'family_key':family_payments.key(c,dict(user)),'family_total':line['amount'],'family_override':False,'confirmed':False,'confirmed_at':'','confirmed_by':'','method':methods.get(user['id'],'未登録'),'receipt_method':'','note':profile.get('note',''),'category_note':rate.get('note','')}
    else:
        start,end=family_payments.period(settings)
        if start in periods:periods[start]['slot']='今回'
    # Older family-total overrides need an allocation so the total is not counted per sibling.
    families={}
    for r in records.values():
        if r.get('family_override'):families.setdefault((r['family_key'],r['start_month']),[]).append(r)
    for group in families.values():
        group.sort(key=lambda r:r['user_id']);total=group[0]['family_total']
        if total is None:
            for r in group:r['amount']=None
            continue
        weights=[max(0,r['amount'] or 0) for r in group];denominator=sum(weights)
        if not denominator:weights=[1]*len(group);denominator=len(group)
        amounts=[total*w//denominator for w in weights]
        for i in range(total-sum(amounts)):amounts[i%len(amounts)]+=1
        for r,amount in zip(group,amounts):r['amount']=amount;r['note']='家庭一括金額を会員ごとの金額比率で按分'
    output=[]
    for r in records.values():
        amount=r['amount'];method=(r.get('receipt_method') if r['confirmed'] else '') or r.get('method') or '未登録'
        if method not in METHODS:method='旧方式'
        output.append({**r,'method':method,'due':amount,'collected':amount if r['confirmed'] and amount is not None else 0,'unpaid':amount if not r['confirmed'] and amount is not None else 0,'collection_status':'金額未設定' if amount is None else '納入不要' if amount==0 else '納入済み' if r['confirmed'] else '未納入'})
    output.sort(key=lambda r:(r['start_month'],r['name'],r['user_id']),reverse=True)
    summaries=[]
    for period in sorted(periods.values(),key=lambda p:p['start'],reverse=True):
        selected=[r for r in output if r['start_month']==period['start']]
        def totals(items):return {'due':sum(r['due'] or 0 for r in items),'collected':sum(r['collected'] for r in items),'unpaid':sum(r['unpaid'] for r in items),'unknown':sum(r['due'] is None for r in items),'count':len(items)}
        summaries.append({**period,**totals(selected),'methods':[{'method':method,**totals([r for r in selected if r['method']==method])} for method in METHODS]})
    return {'periods':summaries,'rows':output,'default_period':plan['periods']['今回']['start'] if plan['enabled'] else settings.get('start_month','')}

def confirm(c,user,d,settings):
    if user['role']!='admin':raise ValueError('入金確認は管理者のみ操作できます。')
    rows=read(c,settings)['rows']
    row=next((r for r in rows if r['user_id']==d.get('user_id') and r['start_month']==d.get('start_month')),None)
    if not row:raise ValueError('対象の会員・期間を選択してください。')
    if type(d.get('confirmed')) is not bool:raise ValueError('納入状態を選択してください。')
    if d['confirmed']:
        if row['due'] is None:raise ValueError('金額を設定してから入金確認してください。')
        if not payment_methods.valid(d.get('method')):raise ValueError('実際に受け取った支払い方法を選択してください。')
    if not row['confirmed']:
        c.execute('INSERT INTO fee_ledger(user_id,start_month,end_month,amount,family_key,family_total,family_override,confirmed,confirmed_at,confirmed_by,period_start,period_end) VALUES(?,?,?,?,?,?,?,0,?,?,?,?) ON CONFLICT(user_id,start_month) DO UPDATE SET amount=excluded.amount,end_month=excluded.end_month,period_start=excluded.period_start,period_end=excluded.period_end',
                  (row['user_id'],row['start_month'],row['end_month'],row['amount'],row['family_key'],row['family_total'],int(row['family_override']),'','',row.get('period_start') or row['start_month'],row.get('period_end') or row['end_month']))
    fee_ledger.confirm(c,user,d)
