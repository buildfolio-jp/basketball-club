"""Advance attendance and published match rosters, separate from daily condition."""
import json
import report_templates
import time
import re

def categories(text):
    result=set()
    for part in re.split('[、,]',text or ''):
        p=part.strip()
        if p in ('小学生','年長・小学生'):result.update(('U9','U12'))
        elif p=='中学生':result.add('U15')
        elif p=='小中学生':result.update(('U9','U12','U15'))
        elif p:result.add(p)
    return result

def eligible(c,uid,event):
    row=c.execute('SELECT categories FROM member_categories WHERE user_id=?',(uid,)).fetchone()
    return bool(categories(row[0] if row else 'U12') & categories(event['group_name'])) and event['kind']!='体験会'

def init(c):
    c.execute('CREATE TABLE IF NOT EXISTS member_categories(user_id TEXT PRIMARY KEY,categories TEXT NOT NULL)')
    c.execute("INSERT OR IGNORE INTO member_categories SELECT id,CASE WHEN grade LIKE '中学%' THEN 'U15' ELSE 'U12' END FROM users WHERE role='member'")
    c.execute('CREATE TABLE IF NOT EXISTS event_details(event_id TEXT PRIMARY KEY,map_url TEXT)')
    columns={r[1] for r in c.execute('PRAGMA table_info(reports)')}
    for name in ('body_condition','mind_condition','breakfast','unwell_area','condition_updated'):
        if name not in columns:c.execute(f'ALTER TABLE reports ADD COLUMN {name} TEXT')
    c.execute("CREATE TABLE IF NOT EXISTS attendance_meta(user_id TEXT,event_id TEXT,note TEXT,updated TEXT,reviewed_at TEXT DEFAULT '',PRIMARY KEY(user_id,event_id))")
    c.execute("CREATE TABLE IF NOT EXISTS match_rosters(event_id TEXT PRIMARY KEY,member_ids TEXT,published INTEGER,updated TEXT)")
    c.execute("UPDATE reports SET attendance='遅刻・早退' WHERE attendance='遅刻'")

def read(c,u):
    staff=u['role']!='member'
    attendance=[dict(r) for r in c.execute('SELECT * FROM attendance_meta'+('' if staff else ' WHERE user_id=?'),() if staff else (u['id'],))]
    rosters=[]
    for row in c.execute('SELECT * FROM match_rosters'+('' if staff else ' WHERE published=1')):
        r=dict(row); ids=json.loads(r.pop('member_ids'));r['member_ids']=ids
        r['names']=[dict(x) for x in c.execute('SELECT id,name FROM users WHERE role="member"') if x['id'] in ids]
        rosters.append(r)
    return {'attendance':attendance,'rosters':rosters}

def mutate(c,u,kind,d):
    eid=d.get('event_id');staff=u['role']!='member'
    e=c.execute('SELECT * FROM events WHERE id=?',(eid,)).fetchone()
    if not e: raise ValueError('日程が見つかりません。')
    if not staff and kind in ('attendance','condition') and not eligible(c,u['id'],e):raise ValueError('この会員の対象日程ではありません。')
    now=time.strftime('%Y-%m-%d %H:%M:%S')
    if kind=='attendance':
        value=d.get('attendance')
        if value not in ('出席','欠席','遅刻・早退','未定'): raise ValueError('出欠を選択してください。')
        note='' if value=='出席' else str(d.get('note','')).strip()
        if value=='遅刻・早退' and not note: raise ValueError('遅刻・早退の理由を入力してください。')
        if len(note)>2000: raise ValueError('連絡事項は2000文字以内で入力してください。')
        c.execute('INSERT INTO reports(user_id,event_id,attendance,updated) VALUES(?,?,?,?) ON CONFLICT(user_id,event_id) DO UPDATE SET attendance=excluded.attendance,updated=excluded.updated',(u['id'],eid,value,now))
        c.execute("INSERT INTO attendance_meta VALUES(?,?,?,?, '') ON CONFLICT(user_id,event_id) DO UPDATE SET note=excluded.note,updated=excluded.updated,reviewed_at=''",(u['id'],eid,note,now))
    elif kind=='condition':
        body=d.get('body_condition');mind=d.get('mind_condition');breakfast=d.get('breakfast')
        if any(d.get(q['id']) not in q['options'] for q in report_templates.read(c,'condition')['questions'] if q['type']=='select'):raise ValueError('体の調子・心の調子・朝ご飯をすべて選択してください。')
        c.execute('INSERT INTO reports(user_id,event_id,body_condition,mind_condition,breakfast,unwell_area,note,updated) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(user_id,event_id) DO UPDATE SET body_condition=excluded.body_condition,mind_condition=excluded.mind_condition,breakfast=excluded.breakfast,unwell_area=excluded.unwell_area,note=excluded.note,updated=excluded.updated',(u['id'],eid,body,mind,breakfast,str(d.get('unwell_area','')).strip()[:2000],str(d.get('note',''))[:2000],now))
        c.execute('UPDATE reports SET condition_updated=? WHERE user_id=? AND event_id=?',(now,u['id'],eid))
    elif kind=='attendance_review':
        if not staff: raise ValueError('スタッフ権限が必要です。')
        c.execute('UPDATE attendance_meta SET reviewed_at=? WHERE event_id=? AND user_id=?',('' if d.get('reviewed') is False else now,eid,d.get('user_id')))
    elif kind=='roster':
        if not staff: raise ValueError('スタッフ権限が必要です。')
        if e['kind']!='試合': raise ValueError('試合のみ選出メンバーを登録できます。')
        ids=d.get('member_ids',[]);published=d.get('published',False)
        valid={r[0] for r in c.execute("SELECT id FROM users WHERE role='member' AND active=1")}
        if not isinstance(ids,list) or any(not isinstance(x,str) or x not in valid for x in ids): raise ValueError('選手を確認してください。')
        c.execute('INSERT OR REPLACE INTO match_rosters VALUES(?,?,?,?)',(eid,json.dumps(list(dict.fromkeys(ids))),int(bool(published)),now))
