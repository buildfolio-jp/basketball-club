"""Administrator venue directory and per-event address snapshots."""
import secrets
from urllib.parse import quote
import admin_access

def init(c):
 c.execute('CREATE TABLE IF NOT EXISTS venues(id TEXT PRIMARY KEY,name TEXT UNIQUE,address TEXT,revision TEXT)')
 c.execute('CREATE TABLE IF NOT EXISTS schedule_titles(id TEXT PRIMARY KEY,name TEXT UNIQUE,revision TEXT)')
 c.execute('CREATE TABLE IF NOT EXISTS event_addresses(event_id TEXT PRIMARY KEY,address TEXT)')
 if not c.execute("SELECT 1 FROM meta WHERE key='schedule_directory_seeded'").fetchone():
  for row in c.execute("SELECT DISTINCT place FROM events WHERE place<>''").fetchall():c.execute('INSERT OR IGNORE INTO venues VALUES(?,?,?,?)',(secrets.token_hex(12),row[0],'',secrets.token_hex(12)))
  for row in c.execute("SELECT DISTINCT title FROM events WHERE title<>''").fetchall():c.execute('INSERT OR IGNORE INTO schedule_titles VALUES(?,?,?)',(secrets.token_hex(12),row[0],secrets.token_hex(12)))
  c.execute("INSERT INTO meta(key,value) VALUES('schedule_directory_seeded','1')")


def listing(c):return [dict(r) for r in c.execute('SELECT * FROM venues ORDER BY name')]
def address(value):
 value=str(value or '').strip()
 if len(value)>500:raise ValueError('住所は500文字以内で入力してください。')
 return value
def map_url(value):return 'https://www.google.com/maps?q='+quote(value) if value else ''
def save_address(c,eid,value):
 value=address(value)
 c.execute('INSERT OR REPLACE INTO event_addresses VALUES(?,?)',(eid,value))
 return value
def enrich(c,events):
 addresses={r[0]:r[1] for r in c.execute('SELECT * FROM event_addresses')}
 for e in events:e['address']=addresses.get(e['id'],'')
def save(c,u,d):
 if not admin_access.full(u):raise PermissionError('管理者のみ会場を登録できます。')
 rid=d.get('id') or secrets.token_hex(12)
 old=c.execute('SELECT * FROM venues WHERE id=?',(rid,)).fetchone()
 if d.get('id') and (not old or old['revision']!=d.get('revision')):raise ValueError('会場情報が更新されています。開き直してください。')
 if d.get('delete'):
  c.execute('DELETE FROM venues WHERE id=?',(rid,));return
 name=str(d.get('name','')).strip();value=address(d.get('address'))
 if not name or len(name)>100 or not value:raise ValueError('会場名（100文字以内）と住所を入力してください。')
 if c.execute('SELECT 1 FROM venues WHERE name=? AND id<>?',(name,rid)).fetchone():raise ValueError('同じ会場名が登録されています。')
 c.execute('INSERT OR REPLACE INTO venues VALUES(?,?,?,?)',(rid,name,value,secrets.token_hex(12)))

def titles(c):return [dict(r) for r in c.execute('SELECT * FROM schedule_titles ORDER BY name')]
def save_title(c,u,d):
 if not admin_access.full(u):raise PermissionError('管理者のみタイトルを登録できます。')
 rid=d.get('id') or secrets.token_hex(12);old=c.execute('SELECT * FROM schedule_titles WHERE id=?',(rid,)).fetchone()
 if d.get('id') and (not old or old['revision']!=d.get('revision')):raise ValueError('情報が更新されています。開き直してください。')
 if d.get('delete'):
  c.execute('DELETE FROM schedule_titles WHERE id=?',(rid,));return
 name=str(d.get('name','')).strip()
 if not name or len(name)>100:raise ValueError('タイトルは100文字以内で入力してください。')
 if c.execute('SELECT 1 FROM schedule_titles WHERE name=? AND id<>?',(name,rid)).fetchone():raise ValueError('同じタイトルが登録されています。')
 c.execute('INSERT OR REPLACE INTO schedule_titles VALUES(?,?,?)',(rid,name,secrets.token_hex(12)))
