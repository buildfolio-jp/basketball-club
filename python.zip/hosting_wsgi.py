"""WSGI entry point for persistent Python hosting (one worker)."""
import io
import os
from email.message import Message
from http import HTTPStatus
import server

server.init()


def application(environ, start_response):
    handler = server.Handler.__new__(server.Handler)
    handler.command = environ.get('REQUEST_METHOD', 'GET')
    handler.path = environ.get('PATH_INFO', '/')
    if environ.get('QUERY_STRING'):
        handler.path += '?' + environ['QUERY_STRING']
    handler.request_version = 'HTTP/1.1'
    handler.client_address = (environ.get('REMOTE_ADDR', ''), 0)
    handler.headers = Message()
    for key, value in environ.items():
        if key.startswith('HTTP_'):
            handler.headers[key[5:].replace('_', '-')] = value
    for key, name in [('CONTENT_TYPE', 'Content-Type'), ('CONTENT_LENGTH', 'Content-Length')]:
        if environ.get(key):
            handler.headers[name] = environ[key]
    handler.rfile = environ['wsgi.input']
    handler.wfile = io.BytesIO()
    response = {'status': 200, 'headers': []}
    handler.send_response = lambda code, message=None: response.update(status=code)
    handler.send_header = lambda name, value: response['headers'].append((name, str(value)))
    handler.end_headers = lambda: None
    if handler.command == 'GET':
        handler.do_GET()
    elif handler.command == 'POST':
        handler.do_POST()
    else:
        handler.send({'error': 'Method not allowed'}, 405)
    body = handler.wfile.getvalue()
    response['headers'].append(('Content-Length', str(len(body))))
    start_response(str(response['status']) + ' ' + HTTPStatus(response['status']).phrase, response['headers'])
    return [body]
