"""Replace public login names without changing stable member record IDs."""
import re,secrets,admin_access

def init(c):c.execute('CREATE TABLE IF NOT EXISTS login_names(account_id TEXT PRIMARY KEY,login_id TEXT UNIQUE,revision TEXT)')
def resolve(c,login):
 r=c.execute('SELECT account_id FROM login_names WHERE login_id=?',(login,)).fetchone();return r[0] if r else login
def display(c,account):
 r=c.execute('SELECT login_id FROM login_names WHERE account_id=?',(account,)).fetchone();return r[0] if r else account
def taken(c,login):return c.execute('SELECT 1 FROM login_names WHERE login_id=?',(login,)).fetchone() is not None
def listing(c):
 import accounts
 out=[]
 for u in c.execute("SELECT id,name,role FROM users WHERE role IN ('member','coach','admin')"):
  if accounts.direct_login_allowed(c,u['id']):out.append({'user_id':u['id'],'account_id':u['id'],'name':u['name'],'login_id':display(c,u['id'])})
 for r in c.execute("SELECT student_id,login_id,parent_name FROM guardian_accounts WHERE status IN ('pending','approved')"):
  out.append({'user_id':r['student_id'],'account_id':r['login_id'],'name':r['parent_name'],'login_id':display(c,r['login_id'])})
 for r in out:
  rev=c.execute('SELECT revision FROM login_names WHERE account_id=?',(r['account_id'],)).fetchone();r['revision']=rev[0] if rev else ''
 return out

def reset(c,u,d,hash_password):
 if not admin_access.full(u):raise PermissionError('管理者のみログイン情報を再設定できます。')
 account=str(d.get('account_id',''));target=next((r for r in listing(c) if r['account_id']==account and r['user_id']==d.get('user_id')),None)
 if not target or target['revision']!=d.get('revision',''):raise ValueError('対象のログイン情報を開き直してください。')
 login=str(d.get('login_id','')).strip();pw=d.get('password','')
 if not re.fullmatch(r'[A-Za-z0-9_-]{3,40}',login) or not isinstance(pw,str) or not 8<=len(pw)<=128 or pw!=d.get('password_confirm'):raise ValueError('IDと8〜128文字の新しいパスワードを確認してください。')
 if login!=account and (c.execute('SELECT 1 FROM users WHERE id=?',(login,)).fetchone() or c.execute('SELECT 1 FROM guardian_accounts WHERE login_id=?',(login,)).fetchone()):raise ValueError('このIDは使用されています。')
 if c.execute('SELECT 1 FROM login_names WHERE login_id=? AND account_id<>?',(login,account)).fetchone():raise ValueError('このIDは使用されています。')
 guardian=c.execute('SELECT 1 FROM guardian_accounts WHERE login_id=?',(account,)).fetchone()
 c.execute('UPDATE '+('guardian_accounts SET hash=? WHERE login_id=?' if guardian else 'users SET hash=? WHERE id=?'),(hash_password(pw),account))
 c.execute('INSERT OR REPLACE INTO login_names VALUES(?,?,?)',(account,login,secrets.token_hex(12)))
 c.execute('DELETE FROM login_sessions WHERE user_id=?',(account,));c.execute('DELETE FROM account_reset_tokens WHERE login_id=?',(account,))
 return account
