"""Optimistic edit snapshots. Caller holds the server write lock through mutation."""
import hashlib,json,secrets,time
SNAPSHOTS={}
TABLES=['admin_access','student_only','member_access','deleted_members','guardian_accounts','account_profiles','shop_deliveries','fee_ledger','announcement_files','board_files','staff_activity','staff_week_approval','events','event_details','event_briefings','match_rosters','reports','users','member_categories','member_families','results','game_stats','game_stats_publication','portal_items','portal_entries','survey_forms','survey_deadlines','shop_products','schedule_documents','fee_adjustments','content','meta','attendance_meta','trial_reviews']
def capture(c,uid):
    now=time.time()
    for key in list(SNAPSHOTS):
        if SNAPSHOTS[key][0]<now-28800:SNAPSHOTS.pop(key,None)
    while len(SNAPSHOTS)>=2000:SNAPSHOTS.pop(next(iter(SNAPSHOTS)))
    tables={r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    state={}
    for table in TABLES:
        if table not in tables:continue
        state[table]=[{k:(hashlib.sha256(v).hexdigest() if isinstance(v,bytes) else v) for k,v in dict(row).items()} for row in c.execute('SELECT * FROM '+table)]
    token=secrets.token_urlsafe(24);SNAPSHOTS[token]=(now,uid,state)
    return token

def scopes(path,d):
    rid=d.get('id');eid=d.get('event_id');uid=d.get('user_id');action=d.get('action')
    def one(table,key,value):return (table,{key:value})
    if path in ('member_approval','member_remove'):return [('users',{'id':uid}),('member_access',{'user_id':uid}),('guardian_accounts',{'student_id':uid})]
    if path=='admin_access':return [('admin_access',{'user_id':rid}),('users',{'id':rid})]
    if path=='guardian_update':return [('guardian_accounts',{'student_id':uid}),('account_profiles',{'login_id':d.get('login_id')})]
    if path=='guardian_remove':return [('guardian_accounts',{'student_id':uid}),('student_only',{'user_id':uid}),('users',{'id':uid})]
    if path=='account_review':return [('guardian_accounts',{}),('users',{})]
    if path=='shop_delivery':return [] # shop.delivery validates each product revision atomically
    if path=='fee_receipt':return [('fee_ledger',{'user_id':uid,'start_month':d.get('start_month')})]+([('meta',{})] if d.get('collection') else [])
    if path=='staff_activity':return [('staff_activity',{'user_id':uid}),('staff_week_approval',{'user_id':uid})]
    if path=='event':
        if not rid:return []
        out=[one('events','id',rid),one('event_details','event_id',rid)]
        if d.get('delete'):out += [one(t,'event_id',rid) for t in ['reports','event_briefings','match_rosters','attendance_meta']]
        return out
    if path=='result':return [] if not rid else [one('results','id',rid),one('game_stats','result_id',rid),one('game_stats_publication','result_id',rid)]
    if path=='member_workbook':return [(t,{}) for t in ('users','member_categories','member_families','account_profiles','deleted_members')]
    if path=='member_record':return [one('users','id',rid),one('member_categories','user_id',rid),one('member_families','user_id',rid),one('account_profiles','login_id',rid)]
    if path=='user':return [one('users','id',rid),one('member_categories','user_id',rid),one('member_families','user_id',rid)]
    if path=='actual':return [('reports',{'user_id':uid,'event_id':eid},['user_id','event_id','actual'])]
    if path=='attendance_review':return [('attendance_meta',{'user_id':uid,'event_id':eid})]
    if path=='trial_review':return [one('trial_reviews','trial_id',rid)]
    if path in ('event_briefing','roster'):return [one('events','id',eid),one('event_details','event_id',eid),one('event_briefings','event_id',eid),one('match_rosters','event_id',eid)]
    if path=='game_stats':return [one('results','id',d.get('result_id')),one('game_stats','result_id',d.get('result_id')),one('game_stats_publication','result_id',d.get('result_id'))]
    if path=='game_stats_import':return [(t,{}) for t in ['results','game_stats','game_stats_publication']] if d.get('confirm') else []
    if path=='schedule_document':return [] if not rid else [one('schedule_documents','id',rid)]
    if path=='shop_product':return [] if not rid else [one('portal_items','id',rid),one('shop_products','item_id',rid)]
    if path=='content':return [('content',{})]
    if path in ('billing_plan','billing_plan_import'):return [('meta',{})] if d.get('confirm') else []
    if path=='fee_adjustment':return [('fee_adjustments',{})]
    if path=='portal':
        if action in ('board_item','board_delete'):return [] if not rid else [one('portal_entries','id',rid),one('board_files','entry_id',rid)]
        if action in ('item','delete'):return [] if not rid else [one('portal_items','id',rid),one('announcement_files','entry_id',rid),one('survey_forms','item_id',rid),one('survey_deadlines','item_id',rid)]
        if action=='review':return [one('portal_entries','id',rid)]
        if action=='billing_settings':return [('meta',{})]
    return []

def selected(state,scope):
    table,where=scope[:2];cols=scope[2] if len(scope)>2 else None
    records=[r for r in state.get(table,[]) if all(r.get(k)==v for k,v in where.items())]
    if table=='meta':records=[r for r in records if r.get('key') in ('billing_plan','billing_settings')]
    if cols:records=[{k:r.get(k) for k in cols} for r in records]
    return sorted(records,key=lambda r:json.dumps(r,sort_keys=True,ensure_ascii=False))

def safe(value):
    if isinstance(value,dict):return {k:('[非表示]' if k in ('hash','password','content','uploads','image') else safe(v)) for k,v in value.items() if not k.startswith('_edit')}
    if isinstance(value,list):return [safe(v) for v in value]
    return value

def check(c,u,path,d):
    scope=scopes(path,d)
    if not scope:return None
    old=SNAPSHOTS.get(d.get('_edit_token',''))
    if not old or old[1]!=u['id'] or old[0]<time.time()-28800:
        return {'error':'編集情報の期限が切れています。画面を再読み込みしてから編集してください。','code':'edit_expired'}
    token=capture(c,u['id']);current=SNAPSHOTS[token][2]
    changes=[]
    for spec in scope:
        before=selected(old[2],spec);after=selected(current,spec)
        if before!=after:changes.append({'item':spec[0],'before':safe(before),'latest':safe(after)})
    if not changes:return None
    return {'error':'他の操作で同じ項目が更新されています。保存する内容を選んでください。','code':'edit_conflict','token':token,'changes':changes,'proposed':safe(d)}
