import payment_methods
"""Per-member invoice snapshots and explicit manual receipt confirmation."""
import json,time,secrets
import family_payments,billing_plan,fee_adjustments,enrollment

def init(c):
 c.execute('CREATE TABLE IF NOT EXISTS fee_ledger(user_id TEXT,start_month TEXT,end_month TEXT,amount INTEGER,family_key TEXT,family_total INTEGER,family_override INTEGER,confirmed INTEGER DEFAULT 0,confirmed_at TEXT,confirmed_by TEXT,PRIMARY KEY(user_id,start_month))')
 columns={r[1] for r in c.execute('PRAGMA table_info(fee_ledger)')}
 for col in ('period_start','period_end','receipt_method'):
  if col not in columns:c.execute('ALTER TABLE fee_ledger ADD COLUMN '+col+' TEXT')
 c.execute('CREATE TABLE IF NOT EXISTS payment_method_history(id TEXT PRIMARY KEY,family_key TEXT,method TEXT,updated TEXT,changed_by TEXT)')

def sync(c,settings):
 start,end=family_payments.period(settings);plan=billing_plan.load(c)
 if plan['enabled']:end=plan['periods']['今回']['end']
 # Import historical demo checkout lines without treating checkout as receipt of money.
 for r in c.execute('SELECT * FROM family_payment_receipts'):
  body=json.loads(r['body'])
  for line in body['lines']:
   c.execute('INSERT OR IGNORE INTO fee_ledger(user_id,start_month,end_month,amount,family_key,family_total,family_override,confirmed_at,confirmed_by) VALUES(?,?,?,?,?,?,0,?,?)',(line['id'],body['start_month'],body['end_month'],line.get('amount'),r['family_key'],body['total'],'',''))
 for row in c.execute("SELECT id,name,grade FROM users WHERE role='member' AND active=1"):
  if enrollment.paused(c,row['id']):continue
  u=dict(row);fk=family_payments.key(c,u)
  if fk.startswith('family:'):
   u['family_members']=[dict(r) for r in c.execute("SELECT u.id,u.name,u.grade FROM users u JOIN member_families f ON f.user_id=u.id WHERE f.family_id=? AND u.active=1 AND u.role='member'",(fk[7:],))]
  summary=billing_plan.summary(c,u,start) if plan['enabled'] else fee_adjustments.summary(c,u,settings['cycle'],start)
  if not summary:continue
  line=next((r for r in summary['lines'] if r['id']==u['id']),None)
  if not line:continue
  c.execute('INSERT INTO fee_ledger(user_id,start_month,end_month,amount,family_key,family_total,family_override,confirmed,confirmed_at,confirmed_by,period_start,period_end) VALUES(?,?,?,?,?,?,?,0,?,?,?,?) ON CONFLICT(user_id,start_month) DO UPDATE SET period_start=excluded.period_start,period_end=excluded.period_end,end_month=excluded.end_month,amount=excluded.amount,family_key=excluded.family_key,family_total=excluded.family_total,family_override=excluded.family_override WHERE fee_ledger.confirmed=0',(u['id'],start,end,line.get('amount'),fk,summary['total'],int(summary.get('family_override',False)),'','',line.get('period_start',start),line.get('period_end',end)))
 for r in c.execute('SELECT * FROM family_payment_methods'):
  if not c.execute('SELECT 1 FROM payment_method_history WHERE family_key=?',(r['family_key'],)).fetchone():c.execute('INSERT INTO payment_method_history VALUES(?,?,?,?,?)',(secrets.token_hex(12),r['family_key'],r['method'],r['updated'],'既存登録'))

def read(c):
 invoices=[]
 for row in c.execute('SELECT l.*,u.name FROM fee_ledger l JOIN users u ON u.id=l.user_id ORDER BY l.start_month DESC,u.name'):
  r=dict(row);receipt=c.execute('SELECT body FROM family_payment_receipts WHERE invoice_key=?',(r['family_key']+':'+r['start_month'],)).fetchone();method=c.execute('SELECT method FROM family_payment_methods WHERE family_key=?',(r['family_key'],)).fetchone()
  r.update(method=r.get('receipt_method') or (json.loads(receipt[0])['method'] if receipt else method[0] if method else ''),demo_checkout=bool(receipt),status='入金確認済み' if r['confirmed'] else '金額未設定' if r['amount'] is None and not r['family_override'] else '未払い（入金未確認）');invoices.append(r)
 methods=[]
 for u in c.execute("SELECT id,name FROM users WHERE role='member'"):
  fk=family_payments.key(c,dict(u));m=c.execute('SELECT * FROM family_payment_methods WHERE family_key=?',(fk,)).fetchone()
  methods.append({'user_id':u['id'],'name':u['name'],'family_key':fk,'method':m['method'] if m else '未登録','updated':m['updated'] if m else '', 'history':[dict(r) for r in c.execute('SELECT * FROM payment_method_history WHERE family_key=? ORDER BY updated DESC,rowid DESC',(fk,))]})
 return {'invoices':invoices,'methods':methods}

def confirm(c,u,d):
 if u['role']!='admin':raise ValueError('入金確認は管理者のみ操作できます。')
 row=c.execute('SELECT * FROM fee_ledger WHERE user_id=? AND start_month=?',(d.get('user_id'),d.get('start_month'))).fetchone()
 if not row or type(d.get('confirmed')) is not bool:raise ValueError('請求を選択してください。')
 if d['confirmed'] and row['amount'] is None and not row['family_override']:raise ValueError('金額を設定してください。')
 method=d.get('method') or next((r['method'] for r in read(c)['invoices'] if r['user_id']==row['user_id'] and r['start_month']==row['start_month']),'')
 if method and not payment_methods.valid(method):raise ValueError('支払い方法を確認してください。')
 c.execute('UPDATE fee_ledger SET confirmed=?,confirmed_at=?,confirmed_by=?,receipt_method=? WHERE user_id=? AND start_month=?',(int(d['confirmed']),time.strftime('%Y-%m-%d %H:%M:%S'),u['id'],method if d['confirmed'] else '',row['user_id'],row['start_month']))
