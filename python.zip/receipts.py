"""Source-linked, immutable receipts and explicit member acknowledgments."""
import datetime,html,json,secrets
import admin_access,accounting
KINDS={'fees':'billing-settings','shop':'shop-admin','lunch':'survey-admin','accounting':'finance-admin','refund':'billing-settings'}
def init(c):c.execute('CREATE TABLE IF NOT EXISTS issued_receipts(id TEXT PRIMARY KEY,kind TEXT,source_id TEXT,user_id TEXT,body TEXT,received_at TEXT DEFAULT "",UNIQUE(kind,source_id))')
def stamp():return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9))).isoformat(timespec='seconds')
def can(c,u,kind,write=False,year=None):
 if not u:return False
 if kind=='accounting':
  try:accounting.access(c,u,year or accounting.fiscal_year(),write);return True
  except PermissionError:return False
 return admin_access.can(u,KINDS.get(kind,''),write)
def sources(c,u,kind):
 if not can(c,u,kind):return []
 result=[]
 def add(sid,uid,amount,label,year=None,direction='income'):
  name=c.execute('SELECT name FROM users WHERE id=?',(uid,)).fetchone() if uid else None
  result.append({'source_id':sid,'user_id':uid,'name':name[0] if name else '', 'amount':amount,'label':label,'year':year,'direction':direction})
 if kind=='fees':
  for r in c.execute('SELECT * FROM fee_ledger'):add(r['user_id']+':'+r['start_month'],r['user_id'],r['amount'],r['start_month']+'〜'+r['end_month']+' 会費')
 elif kind=='shop':
  for r in c.execute('SELECT * FROM shop_orders'):
   b=json.loads(r['body']);add(r['id'],r['user_id'],b.get('total'),'スクール内物販 '+r['created'])
 elif kind=='lunch':
  for r in c.execute('SELECT * FROM lunch_answers'):
   b=json.loads(r['body'])
   if b.get('total',0)>0:add(r['item_id']+':'+r['user_id'],r['user_id'],b['total'],b.get('title','お弁当代'))
 elif kind=='refund':
  for r in c.execute('SELECT * FROM withdrawals'):
   b=json.loads(r['body']);add(r['id'],r['user_id'],b['refund'],b['end_date']+' 退会に伴う返金',direction='refund')
 elif kind=='accounting':
  for r in c.execute('SELECT * FROM accounting_entries'):
   if can(c,u,kind,year=r['year']):add(r['id'],'',r['amount'],r['description'] or r['category'],r['year'],'income' if r['direction']=='収入' else 'expense')
 return result
def read(c,u):
 out=[]
 if not u:return {'rows':[],'sources':{}}
 for r in c.execute('SELECT * FROM issued_receipts ORDER BY rowid DESC'):
  b=json.loads(r['body'])
  if (u['role']=='member' and r['user_id']==u['id']) or can(c,u,r['kind'],year=b.get('year')):out.append({**dict(r),'body':b})
 return {'rows':out,'sources':{k:sources(c,u,k) for k in KINDS}}
def save(c,u,d):
 if not u:raise PermissionError('ログインしてください。')
 if d.get('action')=='receive':
  r=c.execute('SELECT * FROM issued_receipts WHERE id=?',(d.get('id'),)).fetchone()
  if not r or u['role']!='member' or r['user_id']!=u['id']:raise PermissionError('本人の書類のみ受け取り完了にできます。')
  c.execute('UPDATE issued_receipts SET received_at=? WHERE id=? AND received_at=""',(stamp(),r['id']));return
 kind=d.get('kind');source=next((s for s in sources(c,u,kind) if s['source_id']==d.get('source_id')),None)
 if not source or not can(c,u,kind,True,source.get('year')):raise PermissionError('発行する権限または対象の記録がありません。')
 if d.get('paid_confirmed') is not True:raise ValueError('実際の入金・返金を確認してから発行してください。')
 if c.execute('SELECT 1 FROM issued_receipts WHERE kind=? AND source_id=?',(kind,source['source_id'])).fetchone():raise ValueError('この記録の書類は発行済みです。')
 uid=source['user_id'] or d.get('user_id')
 if not c.execute("SELECT 1 FROM users WHERE id=? AND role='member'",(uid,)).fetchone():raise ValueError('書類を届ける会員を選択してください。')
 amount=d.get('amount')
 if isinstance(amount,bool) or not isinstance(amount,int) or not 0<=amount<=100000000:raise ValueError('金額は0〜1億円の整数で入力してください。')
 name=str(d.get('name','')).strip();purpose=str(d.get('purpose','')).strip();date=d.get('date','')
 datetime.date.fromisoformat(date)
 if not name or len(name)>120 or not purpose or len(purpose)>500:raise ValueError('宛名・但し書きを確認してください。')
 rid=secrets.token_hex(16);number='RC-'+datetime.date.today().strftime('%Y%m%d')+'-'+rid[:8].upper()
 issuer='三木 SHINING CHEETAHS'
 body={**source,'name':name,'amount':amount,'purpose':purpose,'date':date,'issuer':issuer,'number':number,'issued_at':stamp(),'issued_by':u['id'],'source_amount':source['amount']}
 c.execute('INSERT INTO issued_receipts(id,kind,source_id,user_id,body) VALUES(?,?,?,?,?)',(rid,kind,source['source_id'],uid,json.dumps(body,ensure_ascii=False)))
def document(c,u,rid):
 r=next((r for r in read(c,u)['rows'] if r['id']==rid),None)
 if not r:raise PermissionError('書類を閲覧する権限がありません。')
 b=r['body'];e=lambda x:html.escape(str(x));refund=b['direction'] in ('refund','expense');title='返金明細・受領確認書' if b['direction']=='refund' else '支払明細・受領確認書' if refund else '領収書'
 text='下記の金額をお支払いしました。' if refund else '下記の金額を領収しました。'
 return ('<!doctype html><html lang="ja"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>'+title+'</title><style>body{font:16px/1.8 sans-serif;color:#172033;max-width:760px;padding:28px;margin:auto}.amount{font-size:30px;border-bottom:2px solid;padding:16px 0}.seal{display:inline-flex;border:3px double #bb3540;color:#bb3540;padding:8px;text-align:center;font-weight:bold;line-height:1.3;font-size:12px;vertical-align:middle;margin:12px}h1{text-align:center;letter-spacing:.3em}button{padding:12px}@media print{button{display:none}}</style><h1>'+title+'</h1><p>発行番号：'+e(b['number'])+'<br>日付：'+e(b['date'])+'</p><h2>'+e(b['name'])+' 様</h2><p>'+text+'</p><p class="amount">金額 ¥'+f"{b['amount']:,}"+'</p><p>但し '+e(b['purpose'])+'</p><p>発行者：'+e(b['issuer'])+'<span class="seal" aria-label="チーム電子印">三木<br>SHINING<br>CHEETAHS<br>電子印</span></p><p>電子発行</p><button onclick="window.print()">印刷・PDFに保存</button></html>').encode()
