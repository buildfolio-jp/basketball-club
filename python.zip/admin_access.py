# coding: utf-8
"""Per-administrator menu grants, enforced on reads and writes."""
import json
KEYS=('staff-attendance','school-reports','basket-notes','worksheets','conditioning','finance-admin','payment-method-admin','board-admin','shop-admin','announcement-admin','survey-admin','staff-members','schedule','attendance-list','settings','members','billing-settings','staff-approvals','results','admin-guide')
def init(c):
    c.execute('CREATE TABLE IF NOT EXISTS admin_access(user_id TEXT PRIMARY KEY,rank INTEGER,permissions TEXT)')
    # Existing administrators keep full access once, never promote new administrators implicitly.
    if not c.execute("SELECT 1 FROM meta WHERE key='admin_access_migrated'").fetchone():
        c.execute("INSERT OR IGNORE INTO admin_access SELECT id,1,'{}' FROM users WHERE role='admin'")
        c.execute("INSERT INTO meta VALUES('admin_access_migrated','1')")
def profile(c,uid):
    r=c.execute('SELECT * FROM admin_access WHERE user_id=?',(uid,)).fetchone()
    return {'admin_rank':r['rank'] if r else 2,'admin_permissions':json.loads(r['permissions']) if r else {}}
def full(u):return u and u.get('role')=='admin' and u.get('admin_rank',2)==1
def can(u,key,write=False):
    return bool(full(u) or (u and u.get('role')=='admin' and u.get('admin_permissions',{}).get(key) in (('edit',) if write else ('view','edit'))))
def check(c,u,path,d=None):
    if path=='choice_masters' and d is None and u:return
    if path in ('member_workbook','member_record','equipment_master','choice_masters'):
        if not full(u):raise PermissionError('管理者のみ操作できます。')
        return
    if path in ('score_resource','score_resource_file','receipt','receipt_document','staff_attendance','school_report','withdrawal','withdrawal_document','private_message','sheet_sync'):return # Record and action permission checks in the respective modules.
    if path in ('logistics','logistics_export'):return # Dedicated family and manager checks.
    if path in ('trial_review_submit','trial_review_invite','review_photo'):return
    if path=='trial_review_admin':
        if not full(u):raise PermissionError('管理者のみ操作できます。')
        return
    if path in ('submission_file','worksheet_excel','attendance_rates','attendance_rates_export'):return # record-level authorization in server
    if path.startswith('finance_'):return # accounting module enforces year and role authorization
    if path in ('coach_access','note_templates','reset_credentials'):
        if not full(u):raise PermissionError('管理者のみコーチの権限を変更できます。')
        return
    if u and u.get('delegated_coach') and path in ('excel','sync'):return
    if u and u.get('delegated_coach') and path=='staff_activity':
        if d and (d.get('user_id')!=u['id'] or d.get('action')=='approval'):raise PermissionError('本人の勤怠登録のみ操作できます。')
        return
    publication_key=None
    if path=='portal' and d and d.get('action') in ('item','delete'):
        old=c.execute('SELECT kind FROM portal_items WHERE id=?',(d.get('id'),)).fetchone()
        kind=old['kind'] if old else d.get('kind')
        publication_key={'surveys':'survey-admin','announcements':'announcement-admin','shop':'shop-admin'}.get(kind)
        if publication_key and (not u or u.get('role')!='admin'):raise PermissionError('この掲載管理は管理者のみ操作できます。')
        if old and d.get('action')=='item' and old['kind']!=d.get('kind'):raise PermissionError('掲載種別は変更できません。')
    if path=='portal' and d and (d.get('action') in ('board_item','board_delete') or d.get('kind')=='board'):
        publication_key='board-admin'
        if not u or u.get('role')!='admin':raise PermissionError('掲示板の変更は管理者のみ操作できます。')
    if path in ('shop_product','shop_delivery'):
        publication_key='shop-admin'
        if not u or u.get('role')!='admin':raise PermissionError('物販の変更は管理者のみ操作できます。')
    if not u or u.get('role')!='admin':return
    if path=='admin_access':
        if not full(u):raise PermissionError('管理者1のみ権限を設定できます。')
        return
    if full(u):return
    if d is None:
        if path in ('me','data','public'):return
        if path=='excel' and any(can(u,k) for k in ('members','staff-members','billing-settings','staff-approvals','results','payment-method-admin')):return
        if path in ('schedule_pdf','event_attachment') and (can(u,'schedule') or can(u,'attendance-list')):return
        if path=='conditioning_export' and can(u,'conditioning'):return
        if path=='board_attachment' and can(u,'board-admin'):return
        if path=='announcement_attachment' and can(u,'announcement-admin'):return
        if path=='fee-unpaid-excel' and can(u,'billing-settings'):return
        raise PermissionError('この情報を閲覧する権限がありません。')
    if path in ('login','logout','account_profile','new_seen'):return
    mapping={'basket_note_status':'attendance-list','skill_video':'results','enrollment':'billing-settings','basket_note':'basket-notes','staff_intro':'staff-members','worksheet':'worksheets','event':'schedule','events_bulk':'schedule','schedule_document':'schedule','event_briefing':'attendance-list','roster':'attendance-list','actual':'attendance-list','attendance_review':'attendance-list','content':'settings','upload':'settings','user':'members','account_review':'members','member_approval':'members','member_remove':'members','guardian_remove':'members','guardian_update':'members','billing_plan':'billing-settings','billing_plan_import':'billing-settings','fee_receipt':'billing-settings','fee_adjustment':'billing-settings','result':'results','game_stats':'results','game_stats_import':'results'}
    key=publication_key or mapping.get(path)
    if path=='event_briefing':
        if d.get('schedule') is not None and not can(u,'schedule',True):raise PermissionError('日程の編集権限がありません。')
        if can(u,'schedule',True):key='schedule'
    if path=='user' and d.get('role')=='coach':key='staff-members'
    if path=='staff_activity':key='staff-approvals'
    if path=='portal' and d.get('action')=='billing_settings':key='billing-settings'
    if path=='portal' and d.get('action')=='review':
        entry=c.execute('SELECT kind FROM portal_entries WHERE id=?',(d.get('id'),)).fetchone()
        if entry and entry['kind']=='messages':key='members'
    if path=='sync' and any(can(u,k,True) for k in ('members','staff-members','billing-settings','staff-approvals','results','payment-method-admin')):return
    if not key or not can(u,key,True):raise PermissionError('この項目を編集する権限がありません。')
    if path=='user':
        old=c.execute('SELECT role FROM users WHERE id=?',(d.get('id'),)).fetchone()
        if old and old['role']=='accountant':raise PermissionError('会計担当者は専用画面で管理してください。')
        if d.get('role','member')=='admin' or (old and old['role']=='admin'):raise PermissionError('管理者の変更は管理者1のみ行えます。')
        if (d.get('role')=='coach' or (old and old['role']=='coach')) and not can(u,'staff-members',True):raise PermissionError('スタッフの編集権限がありません。')
def save(c,u,d,hash_password):
    if not full(u):raise ValueError('管理者1のみ設定できます。')
    uid=str(d.get('id','')).strip();name=str(d.get('name','')).strip();rank=d.get('rank');grants=d.get('permissions',{})
    import re
    if not re.fullmatch(r'[A-Za-z0-9_-]{3,40}',uid) or not name or len(name)>100 or type(rank)is not int or rank not in (1,2):raise ValueError('ID・氏名・ランクを確認してください。')
    if rank!=1:raise ValueError('コーチ別権限設定をご利用ください。')
    if not isinstance(grants,dict) or any(k not in KEYS or v not in ('none','view','edit') for k,v in grants.items()):raise ValueError('権限を確認してください。')
    old=c.execute('SELECT * FROM users WHERE id=?',(uid,)).fetchone()
    if old and old['role']!='admin':raise ValueError('このIDは別の会員・スタッフが使用しています。')
    if uid==u['id'] and rank!=1:raise ValueError('自分自身を管理者2へ変更することはできません。')
    pw=d.get('password','')
    if (not old or pw) and (not isinstance(pw,str) or not 8<=len(pw)<=128):raise ValueError('パスワードは8〜128文字で入力してください。')
    if not old and c.execute('SELECT 1 FROM guardian_accounts WHERE login_id=?',(uid,)).fetchone():raise ValueError('このIDは使用されています。')
    c.execute("INSERT INTO users VALUES(?,?,'運営','admin',?,1) ON CONFLICT(id) DO UPDATE SET name=excluded.name,hash=excluded.hash",(uid,name,hash_password(pw) if pw else old['hash']))
    c.execute('INSERT OR REPLACE INTO admin_access VALUES(?,?,?)',(uid,rank,json.dumps(grants)))
    c.execute('DELETE FROM login_sessions WHERE user_id=?',(uid,))
def listing(c):return [{**dict(r),**profile(c,r['id'])} for r in c.execute("SELECT id,name,active FROM users WHERE role='admin'")]
def filtered(d,u):
    if full(u):return d
    out={'events':[],'results':[],'reports':[],'users':[],'trials':[],'portal':{'items':[],'entries':[]},'game_stats':{'rows':[],'publications':[]},'scheduling':{},'shop':{},'surveys':{},'staff_activity':{},'new_seen':d.get('new_seen',[]),'account_self':d.get('account_self',{}),'edit_token':d.get('edit_token',''),'choice_masters':d.get('choice_masters',[])}
    sets={'basket-notes':['basket_notes'],'staff-members':['staff_intros'],'worksheets':['worksheets'],'conditioning':['events','reports','conditioning_status'],'schedule':['events','reports','scheduling','schedule_documents','event_briefings','equipment_master','venues','schedule_titles'],'attendance-list':['events','reports','scheduling','event_briefings','trials'],'members':['accounts','member_input_status','reports','events','scheduling'],'billing-settings':['fee_ledger','fee_collection','fee_input_status','fee_adjustments','billing_plan','fee_adjustment_periods'],'staff-approvals':['staff_activity'],'results':['results','game_stats','score_resources']}
    for key,fields in sets.items():
        if can(u,key):
            for field in fields:
                if field in d:out[field]=d[field]
    if can(u,'members'):out['users']=[r for r in d.get('users',[]) if r['role']=='member']
    elif any(can(u,k) for k in ('billing-settings','results','schedule','attendance-list','survey-admin','payment-method-admin','conditioning')):out['users']=[{k:r.get(k,'') for k in ('id','name','role','active','grade','categories','school','enrollment')} for r in d.get('users',[]) if r['role']=='member']
    if can(u,'staff-approvals') or can(u,'staff-members'):out['users']+= [{k:r.get(k,'') for k in ('id','name','role','active','grade','staff_kind')} for r in d.get('users',[]) if r['role']=='coach']
    if can(u,'members') and 'accounts' in out:
        out['accounts']={**out['accounts'],'items':[r for r in out['accounts']['items'] if r.get('role')=='member']}
    if can(u,'members'):out['portal']['entries'] += [r for r in d.get('portal',{}).get('entries',[]) if r['kind']=='messages']
    if can(u,'billing-settings'):out['portal']['billing_settings']=d.get('portal',{}).get('billing_settings',{})
    if can(u,'survey-admin'):
        out['surveys']=d.get('surveys',{})
        out['portal']['items']=[r for r in d.get('portal',{}).get('items',[]) if r['kind']=='surveys']
        out['portal']['entries'] += [r for r in d.get('portal',{}).get('entries',[]) if r['kind']=='surveys']
    if can(u,'announcement-admin'):
        out['portal']['items'] += [r for r in d.get('portal',{}).get('items',[]) if r['kind']=='announcements']
        out['portal']['announcement_files']=d.get('portal',{}).get('announcement_files',[])
        out['announcement_reads']=d.get('announcement_reads',[])
    if can(u,'shop-admin'):
        out['shop']=d.get('shop',{})
        out['portal']['items'] += [r for r in d.get('portal',{}).get('items',[]) if r['kind']=='shop']
    if can(u,'board-admin'):
        out['portal']['entries'] += [r for r in d.get('portal',{}).get('entries',[]) if r['kind']=='board']
        out['portal']['files']=d.get('portal',{}).get('files',[])
        out['board_reads']=d.get('board_reads',[])
    if can(u,'payment-method-admin') and not can(u,'billing-settings'):
        out['fee_ledger']={'methods':d.get('fee_ledger',{}).get('methods',[]),'invoices':[]}
    if can(u,'finance-admin'):out['finance']=d.get('finance',{})
    out['excel']=d.get('excel',{})
    return out

def export_payload(c,u):
    import billing_plan,fee_collection,fee_ledger,club_portal,staff_activity,game_stats
    d={'users':[],'reports':[],'events':[],'results':[],'trials':[]}
    if can(u,'members'):
        d['users']=[dict(r) for r in c.execute("SELECT id,name,grade,role,active FROM users WHERE role='member'")]
        d['reports']=[dict(r) for r in c.execute('SELECT * FROM reports')]
        d['events']=[dict(r) for r in c.execute('SELECT * FROM events')]
    if can(u,'staff-members'):d['users']+=[dict(r) for r in c.execute("SELECT id,name,grade,role,active FROM users WHERE role='coach'")]
    if can(u,'billing-settings'):
        d['billing_plan']=billing_plan.read(c);d['fee_collection']=fee_collection.read(c,club_portal.billing_settings(c));d['fee_ledger']=fee_ledger.read(c)
    if can(u,'payment-method-admin') and not can(u,'billing-settings'):d['fee_ledger']={'methods':fee_ledger.read(c)['methods'],'invoices':[]}
    if can(u,'staff-approvals'):d['staff_activity']=staff_activity.read(c)
    if can(u,'results'):
        d['results']=[dict(r) for r in c.execute('SELECT * FROM results')];d['game_stats']=game_stats.read(c,u)['rows']
    return d
