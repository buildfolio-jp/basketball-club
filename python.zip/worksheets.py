"""U15 worksheets and shared review state."""
import re, uuid, datetime, json
import admin_access,submission_files

def init(c):
    c.execute('CREATE TABLE IF NOT EXISTS worksheets(id TEXT PRIMARY KEY,user_id TEXT,title TEXT,body TEXT,updated TEXT,reviewed INTEGER,reviewed_by TEXT,reviewed_at TEXT,revision INTEGER)')

    if 'answers' not in [r[1] for r in c.execute('PRAGMA table_info(worksheets)')]:c.execute("ALTER TABLE worksheets ADD COLUMN answers TEXT DEFAULT '[]'")

def eligible(c,uid):
    r=c.execute("SELECT categories FROM member_categories JOIN users ON users.id=member_categories.user_id WHERE user_id=? AND role='member' AND active=1",(uid,)).fetchone()
    return bool(r and any(x.strip() in ('U15','U15A','U15B') for x in re.split('[、,]',r[0])))

def staff(u,write=False):
    return bool(u and (u['role']=='coach' or admin_access.can(u,'worksheets',write)))

def read(c,u):
    can_read=staff(u)
    own=u and u['role']=='member' and eligible(c,u['id'])
    if not can_read and not own:return {'available':False,'rows':[]}
    sql='SELECT w.*,u.name,u.grade FROM worksheets w JOIN users u ON u.id=w.user_id'
    rows=c.execute(sql+('' if can_read else ' WHERE w.user_id=?')+' ORDER BY w.updated DESC,w.id',() if can_read else (u['id'],))
    return {'available':True,'template':template(c),'rows':[{**dict(r),'files':submission_files.listing(c,'worksheet',r['id'])} for r in rows]}

def save(c,u,d):
    if not u:raise PermissionError('ログインしてください。')
    if d.get('action')=='template':save_template(c,u,d);return
    old=c.execute('SELECT * FROM worksheets WHERE id=?',(d.get('id',''),)).fetchone()
    if old and d.get('revision')!=old['revision']:raise ValueError('内容が更新されています。画面を再読み込みして確認してください。')
    now=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9))).isoformat(timespec='microseconds')
    if d.get('action')=='review':
        if not staff(u,True):raise PermissionError('確認する権限がありません。')
        if not old:raise ValueError('ワークシートが見つかりません。')
        if type(d.get('reviewed')) is not bool:raise ValueError('確認状態を指定してください。')
        yes=d['reviewed']
        c.execute('UPDATE worksheets SET reviewed=?,reviewed_by=?,reviewed_at=?,revision=revision+1 WHERE id=?',(int(yes),u['id'] if yes else '',now if yes else '',old['id']))
        return
    if u['role']!='member' or not eligible(c,u['id']) or (old and old['user_id']!=u['id']):raise PermissionError('本人のU15ワークシートのみ提出できます。')
    if d.get('delete'):
        if not old:raise ValueError('ワークシートがありません。')
        c.execute("DELETE FROM submission_files WHERE kind='worksheet' AND record_id=?",(old['id'],))
        c.execute('DELETE FROM worksheets WHERE id=?',(old['id'],));return
    questions=template(c);answers=d.get('answers',{})
    if d.get('template_revision')!=questions['revision']:raise ValueError('質問が変更されています。画面を開き直してください。')
    if not isinstance(answers,dict):raise ValueError('回答を確認してください。')
    snapshot=[]
    for q in questions['questions']:
        value=answers.get(q['id'],'')
        if value not in q['options']:raise ValueError(q['label']+'を選んでください。')
        snapshot.append({'id':q['id'],'label':q['label'],'value':value})
    answer_json=json.dumps(snapshot,ensure_ascii=False)
    title=str(d.get('title','')).strip();body=str(d.get('body','')).strip()
    if not 1<=len(title)<=150 or len(body)>10000 or (not body and not snapshot and not d.get('uploads') and not (old and submission_files.listing(c,'worksheet',old['id']))):raise ValueError('タイトルと内容を入力してください（タイトル150文字、内容10000文字以内）。')
    if old:
        if title==old['title'] and body==old['body'] and not d.get('uploads') and old['answers']==answer_json:return
        c.execute('UPDATE worksheets SET title=?,body=?,updated=?,reviewed=0,reviewed_by=\'\',reviewed_at=\'\',revision=revision+1 WHERE id=?',(title,body,now,old['id']))
    else:
        rid=uuid.uuid4().hex
        c.execute('INSERT INTO worksheets(id,user_id,title,body,updated,reviewed,reviewed_by,reviewed_at,revision) VALUES(?,?,?,?,?,0,\'\',\'\',1)',(rid,u['id'],title,body,now))
    c.execute('UPDATE worksheets SET answers=? WHERE id=?',(answer_json,old['id'] if old else rid))
    submission_files.add(c,'worksheet',old['id'] if old else rid,d.get('uploads',[]))

def template(c):
    import json
    r=c.execute("SELECT value FROM meta WHERE key='worksheet_template'").fetchone()
    return json.loads(r[0]) if r else {'revision':0,'questions':[{'id':str(i),'label':label,'options':['できた','少しできた','次の練習で挑戦する','今回は取り組んでいない']} for i,label in enumerate(['狙った場所にシュートを打つ','味方が受け取りやすいパスを出す','ボールを守りながらドリブルする','パスを受けるために動く','相手とゴールの間に戻って守る','仲間に声をかけて連携する'])]}

def save_template(c,u,d):
    import json
    if not admin_access.can(u,'worksheets',True):raise PermissionError('管理者のみ質問を変更できます。')
    old=template(c)
    if old['revision']!=d.get('revision'):raise ValueError('質問が更新されています。再読み込みしてください。')
    qs=d.get('questions')
    if not isinstance(qs,list) or len(qs)>30:raise ValueError('質問は30件までです。')
    seen=set()
    for q in qs:
        if not isinstance(q,dict) or not isinstance(q.get('id'),str) or not re.fullmatch('[A-Za-z0-9_-]{1,40}',q['id']) or q['id'] in seen:raise ValueError('質問IDが不正です。')
        seen.add(q['id'])
        if not isinstance(q.get('label'),str) or not 1<=len(q['label'].strip())<=150 or not isinstance(q.get('options'),list) or not 2<=len(q['options'])<=12 or any(not isinstance(v,str) or not 1<=len(v.strip())<=100 for v in q['options']):raise ValueError('質問と2〜12個の選択肢を入力してください。')
    c.execute('INSERT OR REPLACE INTO meta VALUES(?,?)',('worksheet_template',json.dumps({'revision':old['revision']+1,'questions':qs},ensure_ascii=False)))

def export_rows(c,u):
    import json
    return [[r['user_id'],r['name'],r['grade'],r['title'],r['body'],'\n'.join(a['label']+'：'+a['value'] for a in json.loads(r['answers'])),r['updated'],'確認済み' if r['reviewed'] else '未確認',r['reviewed_by'],r['reviewed_at'],'\n'.join(f['name'] for f in r['files'])] for r in read(c,u)['rows']]

def workbook(c,u,path):
    from excel_export import write_workbook
    write_workbook({'users':[],'events':[],'reports':[],'results':[],'trials':[],'only_extra_sheets':True,'extra_sheets':[('ワークシート',['会員ID','会員名','学年','タイトル','振り返り','選択式の回答','提出・更新日時','確認状態','確認者ID','確認日時','添付名'],export_rows(c,u))]},path)

def archive(c,root):
    from pathlib import Path
    path=Path(root)/'ワークシート.xlsx';tmp=path.with_suffix('.tmp.xlsx')
    workbook(c,{'id':'archive','role':'admin','admin_rank':1},tmp);tmp.replace(path)
