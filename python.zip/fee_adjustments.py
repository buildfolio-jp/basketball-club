"""Explicit current/next invoice amount overrides; no real charges."""
import time,re
import local_fees

def init(c):
    c.execute('CREATE TABLE IF NOT EXISTS fee_adjustments(kind TEXT,target TEXT,start_month TEXT,scope TEXT,amount INTEGER,note TEXT,updated TEXT,PRIMARY KEY(kind,target,start_month))')
def next_month(month):
    y,m=map(int,month.split('-'));n=y*12+m
    return f'{n//12:04d}-{n%12+1:02d}'
def rows(c):return [dict(r) for r in c.execute('SELECT * FROM fee_adjustments ORDER BY start_month DESC,kind,target')]
def save(c,u,d,settings):
    import family_payments
    if u['role']!='admin':raise ValueError('管理者のみ設定できます。')
    kind=d.get('kind');target=d.get('target');scope=d.get('scope');apply=d.get('apply')
    if kind not in ('会員','家庭') or scope not in ('once','ongoing') or apply not in ('current','next'):raise ValueError('対象・適用時期を選択してください。')
    current,end=family_payments.period(settings);start=current if apply=='current' else next_month(end)
    if d.get('expected_start')!=start:raise ValueError('対象期間が変更されています。画面を更新してください。')
    if kind=='会員':
        member=c.execute("SELECT * FROM users WHERE id=? AND role='member' AND active=1",(target,)).fetchone()
        if not member:raise ValueError('在籍中の会員を選択してください。')
        fk=family_payments.key(c,dict(member))
    else:
        if not c.execute('SELECT 1 FROM member_families f JOIN users u ON f.user_id=u.id WHERE family_id=? AND u.active=1',(target,)).fetchone():raise ValueError('家庭IDを選択してください。')
        fk='family:'+target
    if c.execute('SELECT 1 FROM family_payment_receipts WHERE invoice_key=?',(fk+':'+start,)).fetchone():raise ValueError('この期間は手続き済みです。保存済み記録は変更できません。次回を選択してください。')
    value=str(d.get('amount',''))
    if not re.fullmatch(r'\d{1,8}',value) or int(value)>10000000:raise ValueError('金額は0〜10000000円の整数で入力してください。')
    note=str(d.get('note','')).strip()
    if len(note)>300:raise ValueError('理由は300文字以内にしてください。')
    c.execute('INSERT OR REPLACE INTO fee_adjustments VALUES(?,?,?,?,?,?,?)',(kind,target,start,scope,int(value),note,time.strftime('%Y-%m-%d %H:%M:%S')))
def summary(c,u,cycle,start):
    base=local_fees.summary(c,u,cycle)
    def find(kind,target):
        r=c.execute("SELECT * FROM fee_adjustments WHERE kind=? AND target=? AND start_month<=? AND (scope='ongoing' OR start_month=?) ORDER BY start_month DESC LIMIT 1",(kind,target,start,start)).fetchone()
        return dict(r) if r else None
    for line in base['lines']:
        a=find('会員',line['id'])
        if a:line.update(amount=a['amount'],adjustment_note=a['note'],adjusted=True)
    family=c.execute('SELECT family_id FROM member_families WHERE user_id=?',(u['id'],)).fetchone()
    a=find('家庭',family[0]) if family else None
    if a:base.update(total=a['amount'],family_override=True,adjustment_note=a['note'])
    elif not base['family_override']:base['total']=sum(x['amount'] for x in base['lines']) if all(x['amount'] is not None for x in base['lines']) else None
    import enrollment
    suspended=False
    for line in base['lines']:
        if enrollment.paused(c,line['id']):
            saved=c.execute('SELECT amount FROM fee_ledger WHERE user_id=? AND start_month=?',(line['id'],start)).fetchone()
            line['amount']=saved[0] if saved else 0
            line['adjustment_note']='休会（新しい請求を停止）';suspended=True
    if suspended:
        base['family_override']=False
        base['total']=sum(x['amount'] for x in base['lines']) if all(x['amount'] is not None for x in base['lines']) else None
    return base
