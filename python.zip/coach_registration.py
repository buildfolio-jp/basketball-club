"""Invite-only coach credential enrollment; existing staff permissions are retained."""
import secrets,re,time
import accounts,credentials,admin_access

def init(c):
 c.execute('CREATE TABLE IF NOT EXISTS coach_registration(user_id TEXT PRIMARY KEY,code TEXT UNIQUE,status TEXT,login_id TEXT,email TEXT,hash TEXT,updated TEXT)')
def listing(c):return [dict(r) for r in c.execute('SELECT r.user_id,r.code,r.status,r.login_id,r.updated,u.name FROM coach_registration r JOIN users u ON u.id=r.user_id')]
def manage(c,u,d):
 if not admin_access.full(u) or u.get('delegated_coach'):raise PermissionError('管理者のみ操作できます。')
 uid=d.get('user_id');person=c.execute("SELECT * FROM users WHERE id=? AND role='coach' AND active=1",(uid,)).fetchone()
 if not person:raise ValueError('在籍コーチを選択してください。')
 r=c.execute('SELECT * FROM coach_registration WHERE user_id=?',(uid,)).fetchone()
 if d.get('action')=='invite':
  if r and r['status']=='pending':raise ValueError('申請内容を先に確認してください。')
  c.execute("INSERT OR REPLACE INTO coach_registration VALUES(?,?,'invited','','','',?)",(uid,secrets.token_urlsafe(24),accounts.now()));return
 if not r or r['status']!='pending':raise ValueError('承認待ちの申請を選択してください。')
 if d.get('action')=='reject':c.execute("UPDATE coach_registration SET status='rejected',hash='' WHERE user_id=?",(uid,));return
 if d.get('action')!='approve':raise ValueError('操作を確認してください。')
 check_id(c,r['login_id'],uid)
 c.execute('UPDATE users SET hash=? WHERE id=?',(r['hash'],uid))
 c.execute('INSERT OR REPLACE INTO login_names VALUES(?,?,?)',(uid,r['login_id'],secrets.token_hex(12)))
 c.execute("INSERT OR REPLACE INTO account_profiles VALUES(?,?,?,?, '')",(uid,person['name'],r['email'],accounts.now()))
 c.execute("UPDATE coach_registration SET status='approved',hash='',updated=? WHERE user_id=?",(accounts.now(),uid))
 c.execute('DELETE FROM login_sessions WHERE user_id=?',(uid,))
 accounts.queue_mail(c,r['email'],'CHEETAHS コーチ登録完了','管理者の承認が完了しました。設定したID・パスワードでログインできます。')
def check_id(c,login,uid):
 if not re.fullmatch(r'[A-Za-z0-9_-]{3,40}',login):raise ValueError('IDは3〜40文字の半角英数字・ハイフン・下線で入力してください。')
 if (login!=uid and c.execute('SELECT 1 FROM users WHERE id=?',(login,)).fetchone()) or c.execute('SELECT 1 FROM guardian_accounts WHERE login_id=?',(login,)).fetchone() or c.execute('SELECT 1 FROM login_names WHERE login_id=? AND account_id<>?',(login,uid)).fetchone():raise ValueError('このIDは使用できません。')
def register(c,d,hash_password):
 r=c.execute("SELECT r.*,u.name FROM coach_registration r JOIN users u ON u.id=r.user_id WHERE r.code=? AND u.role='coach' AND u.active=1",(d.get('code'),)).fetchone()
 if not r:raise ValueError('登録コードを確認してください。')
 if r['status'] in ('pending','approved'):raise ValueError('すでに登録済みです。')
 if ''.join(str(d.get('name','')).split())!=''.join(r['name'].split()):raise ValueError('氏名が登録内容と一致しません。')
 login=str(d.get('id','')).strip();check_id(c,login,r['user_id']);pw=d.get('password','')
 if not isinstance(pw,str) or not 8<=len(pw)<=128 or pw!=d.get('password_confirm'):raise ValueError('パスワードと確認用パスワードを確認してください。')
 address=accounts.email(d.get('email'))
 c.execute("UPDATE coach_registration SET status='pending',login_id=?,email=?,hash=?,updated=? WHERE user_id=?",(login,address,hash_password(pw),accounts.now(),r['user_id']))
 accounts.queue_mail(c,'','CHEETAHS コーチ登録申請','スタッフ一覧で新規登録の内容を確認してください。')
