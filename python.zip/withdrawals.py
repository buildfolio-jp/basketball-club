"""Month-end withdrawal, immutable refund quotes and private signed applications."""
import base64, calendar, datetime, hashlib, html, json, secrets
import admin_access, billing_plan, enrollment, submission_files, scheduling

def annual_refund_policy(c,uid):
 row=c.execute('SELECT categories FROM member_categories WHERE user_id=?',(uid,)).fetchone()
 cats=scheduling.categories(row[0] if row else '')
 is_u15=bool(cats & {'U15','U15アドバンス','U15ベーシック','U15アドバンス','U15ベーシック'})
 return {'annual_refund':0,'annual_nonrefundable':is_u15,'annual_refund_note':'U15の年会費は返金対象外です。' if is_u15 else ''}

def stamp():return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9))).isoformat(timespec='seconds')
def init(c):
 c.execute('CREATE TABLE IF NOT EXISTS withdrawals(id TEXT PRIMARY KEY,user_id TEXT,body TEXT,revision INTEGER NOT NULL DEFAULT 1)')
 c.execute('CREATE TABLE IF NOT EXISTS private_messages(id TEXT PRIMARY KEY,user_id TEXT,author_id TEXT,title TEXT,body TEXT,created TEXT,seen TEXT DEFAULT "")')
def manager(u,write=False):return admin_access.can(u,'billing-settings',write)
def clean(value,limit=2000):
 if not isinstance(value,str) or not value.strip() or len(value)>limit:raise ValueError('入力内容を確認してください。')
 return value.strip()
def quote(c,d):
 uid=d.get('user_id');month=d.get('month','');n=billing_plan.monthnum(month)
 member=c.execute("SELECT id,name FROM users WHERE id=? AND role='member' AND active=1",(uid,)).fetchone()
 if not member:raise ValueError('在籍中の選手を選択してください。')
 if month<enrollment.today()[:7]:raise ValueError('退会月は今月以降を指定してください。')
 plan=billing_plan.read(c);slot=next((s for s,p in plan['periods'].items() if billing_plan.monthnum(p['start'])<=n<=billing_plan.monthnum(p['end'])),None)
 if not plan['enabled'] or not slot:raise ValueError('退会月を含む半期の会費を先に設定してください。')
 line=billing_plan.line(plan,slot,uid,member['name']);start,end=line['period_start'],line['period_end']
 # Prefer the collected period's original tuition breakdown, if available.
 source='現在の会費設定';tuition=line['components'][0]['amount'];received_total=line['amount']
 for row in c.execute('SELECT body FROM family_payment_receipts'):
  paid=json.loads(row[0]);original=next((x for x in paid.get('lines',[]) if x['id']==uid),None)
  if paid.get('start_month')==plan['periods'][slot]['start'] and original and original.get('components'):
   tuition=original['components'][0]['amount'];received_total=original.get('amount');start=original.get('period_start',start);end=original.get('period_end',end);source='保存済みの支払い内訳';break
 months=billing_plan.monthnum(end)-billing_plan.monthnum(start)+1
 if months!=6 or start[-2:] not in ('04','10'):raise ValueError('返金の自動計算は4〜9月・10〜3月の半期会費が対象です。個別期間を確認してください。')
 if not billing_plan.monthnum(start)<=n<=billing_plan.monthnum(end):raise ValueError('退会月が会費の対象期間外です。')
 if tuition is None or isinstance(tuition,bool) or tuition<0:raise ValueError('対象の期間会費を設定してください。')
 if enrollment.paused(c,uid):raise ValueError('休会・退会中の選手は会費設定を確認してください。')
 remaining=billing_plan.monthnum(end)-n;gross=tuition*remaining//6
 y,m=map(int,month.split('-'));last=datetime.date(y,m,calendar.monthrange(y,m)[1]);stop=last+datetime.timedelta(days=1)
 result={'user_id':uid,'name':member['name'],'month':month,'end_date':last.isoformat(),'stop_date':stop.isoformat(),'period_start':start,'period_end':end,'tuition':tuition,'months':remaining,'gross':gross,'insurance':800,'sports21':200,'refund':max(0,gross-1000),'source':source,'plan_revision':plan['revision']}
 result.update(received_fee=tuition,received_total=received_total,used_fee=tuition-gross)
 result.update(annual_refund_policy(c,uid))
 result['token']=hashlib.sha256(json.dumps(result,sort_keys=True).encode()).hexdigest();return result
def listing(c,u):
 if not u:return {'rows':[],'templates':[]}
 rows=[]
 for r in c.execute('SELECT * FROM withdrawals ORDER BY rowid DESC'):
  if not manager(u) and not (u['role']=='member' and r['user_id']==u['id']):continue
  body=json.loads(r['body']);rows.append({**body,'id':r['id'],'revision':r['revision']})
 return {'rows':rows,'templates':submission_files.listing(c,'withdrawal_template','library') if manager(u) else []}
def load(c,u,rid,write=False):
 r=c.execute('SELECT * FROM withdrawals WHERE id=?',(rid,)).fetchone()
 if not r or not (manager(u,write) or (u and u['role']=='member' and u['id']==r['user_id'])):raise PermissionError('この退会手続きを開く権限がありません。')
 return r,json.loads(r['body'])
def mutate(c,u,d):
 if not u:raise PermissionError('ログインしてください。')
 action=d.get('action')
 if action in ('quote','create','templates'):
  if not manager(u,True):raise PermissionError('会費設定の編集権限が必要です。')
  if action=='templates':submission_files.add(c,'withdrawal_template','library',d.get('uploads',[]));return {'ok':True}
  q=quote(c,d)
  if action=='quote':return {'quote':q}
  if q['token']!=d.get('token'):raise ValueError('会費設定が変更されています。返金額を再確認してください。')
  if d.get('paid_confirmed') is not True:raise ValueError('対象の半期会費の入金済み確認が必要です。')
  if c.execute('SELECT 1 FROM withdrawals WHERE user_id=?',(q['user_id'],)).fetchone():raise ValueError('この選手の退会手続きは登録済みです。')
  doc=c.execute("SELECT id,name FROM submission_files WHERE id=? AND kind='withdrawal_template'",(d.get('template_id'),)).fetchone()
  if not doc:raise ValueError('保管した退会届を選択してください。')
  rid=secrets.token_hex(16);body={**q,'template_id':doc['id'],'template_name':doc['name'],'created':stamp(),'created_by':u['id'],'status':'会員確認待ち','acknowledged':'','submitted':'','issued':'','signature':'','signer':'','reason':'','receipt_number':''}
  c.execute('INSERT INTO withdrawals VALUES(?,?,?,1)',(rid,q['user_id'],json.dumps(body,ensure_ascii=False)))
  enrollment.save(c,q['user_id'],'指定日退会',pause_date=q['stop_date'])
  return {'ok':True,'id':rid}
 r,b=load(c,u,d.get('id'),True)
 if d.get('revision')!=r['revision']:raise ValueError('手続きが更新されています。画面を開き直してください。')
 if action in ('acknowledge','submit'):
  if u['role']!='member' or u['id']!=r['user_id']:raise PermissionError('対象の会員のみ操作できます。')
  if b['submitted']:raise ValueError('退会届は送信済みです。')
  if action=='acknowledge':b['acknowledged']=stamp();b['status']='退会届の入力待ち'
  else:
   if not b['acknowledged'] or d.get('consent') is not True:raise ValueError('返金額と署名内容を確認してください。')
   signer=clean(d.get('signer'),100);reason=clean(d.get('reason'),2000)
   try:signature=base64.b64decode(d.get('signature',''),validate=True)
   except Exception:raise ValueError('署名を入力してください。')
   if not signature.startswith(b'\x89PNG\r\n\x1a\n') or not 80<len(signature)<=300000:raise ValueError('署名を入力してください。')
   b.update(signature=base64.b64encode(signature).decode(),signer=signer,reason=reason,submitted=stamp(),submitted_by=u.get('login_id',u['id']),status='管理者確認待ち')
 elif action=='issue':
  if not manager(u,True):raise PermissionError('管理者のみ受領書を発行できます。')
  if not b['submitted']:raise ValueError('会員からの退会届が未送信です。')
  if b['issued']:raise ValueError('受領書は発行済みです。')
  if d.get('reviewed') is not True:raise ValueError('退会届と署名を確認してください。')
  b.update(issued=stamp(),issued_by=u['id'],receipt_number='WD-'+stamp()[:10].replace('-','')+'-'+r['id'][:8].upper(),status='受領書発行済み')
 else:raise ValueError('操作を確認してください。')
 c.execute('UPDATE withdrawals SET body=?,revision=revision+1 WHERE id=?',(json.dumps(b,ensure_ascii=False),r['id']));return {'ok':True}
def document(c,u,rid,kind):
 r,b=load(c,u,rid)
 if kind=='template':
  f=c.execute('SELECT * FROM submission_files WHERE id=?',(b['template_id'],)).fetchone();return f['mime'],f['content'],'withdrawal-form.'+{'application/pdf':'pdf','image/png':'png','image/jpeg':'jpg','image/webp':'webp'}[f['mime']]
 if kind=='receipt' and not b['issued']:raise ValueError('受領書は未発行です。')
 if kind not in ('receipt','signed') or not b['submitted']:raise ValueError('退会届は未送信です。')
 e=lambda v:html.escape(str(v));title='退会届受領書' if kind=='receipt' else '署名済み退会届'
 lines=[('選手名',b['name']),('会費対象期間',b['period_start']+'〜'+b['period_end']),('お預かりした会費額',f"{b['received_fee']:,}円"),('退会月までの会費',f"{b['used_fee']:,}円"),('退会日',b['end_date']),('未利用月分の会費',f"{b['months']}か月・{b['gross']:,}円"),('保険代の控除','800円'),('スポーツ21会費の控除','200円'),('返金予定額',f"{b['refund']:,}円"),('返金額確認日時',b['acknowledged']),('署名者',b['signer']),('退会理由',b['reason']),('提出日時',b['submitted']),('選択した退会届',b['template_name'])]
 if b.get('annual_nonrefundable'):lines += [('年会費の返金','0円（U15の年会費は返金対象外です。）')]
 if kind=='receipt':lines += [('受領書番号',b['receipt_number']),('管理者受領日時',b['issued'])]
 markup='<!doctype html><html lang="ja"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>'+title+'</title><style>body{font:16px sans-serif;max-width:760px;margin:40px auto;padding:20px;color:#172033}dt{font-weight:bold;margin-top:20px}dd{margin:6px 0;white-space:pre-wrap}img{max-width:100%;border:1px solid #ddd}</style><h1>'+title+'</h1><dl>'+''.join('<dt>'+e(k)+'</dt><dd>'+e(v)+'</dd>' for k,v in lines)+'</dl><h2>オンライン署名</h2><img alt="署名" src="data:image/png;base64,'+b['signature']+'"><p>この受領書は退会届の受領を証明するものです。返金の送金完了を示すものではありません。</p></html>'
 return 'text/html; charset=utf-8',markup.encode(),'withdrawal-'+kind+'.html'
def messages(c,u):
 if not u:return []
 staff=u['role']=='coach' or admin_access.can(u,'members') or admin_access.can(u,'messages')
 return [dict(r) for r in c.execute('SELECT m.*,u.name AS author_name FROM private_messages m JOIN users u ON u.id=m.author_id'+('' if staff else ' WHERE m.user_id=?')+' ORDER BY m.created DESC',() if staff else (u['id'],))]
def send_message(c,u,d):
 if not u or not (u['role']=='coach' or admin_access.can(u,'messages',True) or admin_access.can(u,'members',True)):raise PermissionError('個別連絡の権限がありません。')
 uid=d.get('user_id')
 if not c.execute("SELECT 1 FROM users WHERE id=? AND role='member'",(uid,)).fetchone():raise ValueError('選手を選択してください。')
 c.execute('INSERT INTO private_messages(id,user_id,author_id,title,body,created) VALUES(?,?,?,?,?,?)',(secrets.token_hex(16),uid,u['id'],clean(d.get('title'),120),clean(d.get('body'),4000),stamp()));return {'ok':True}
