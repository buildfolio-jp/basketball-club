import payment_methods
"""Family-wide demo preferences and idempotent demo checkout. No processor."""
import json,hashlib,time,re,secrets
import local_fees
import fee_adjustments
import billing_plan

def init(c):
    fee_adjustments.init(c)
    c.execute('CREATE TABLE IF NOT EXISTS family_payment_methods(family_key TEXT PRIMARY KEY,method TEXT,updated TEXT)')
    c.execute('CREATE TABLE IF NOT EXISTS family_payment_receipts(invoice_key TEXT PRIMARY KEY,family_key TEXT,body TEXT,updated TEXT)')
def key(c,u):
    r=c.execute('SELECT family_id FROM member_families WHERE user_id=?',(u['id'],)).fetchone()
    return 'family:'+r[0] if r and r[0] else 'member:'+u['id']
def period(settings):
    start=settings.get('start_month') or time.strftime('%Y-%m')
    if not re.fullmatch(r'\d{4}-(0[1-9]|1[0-2])',start):raise ValueError('対象期間の開始月を確認してください。')
    year,month=map(int,start.split('-'));n={'毎月払い':1,'半年払い':6,'年払い':12}[settings['cycle']];end=year*12+month-1+n-1
    return start,f'{end//12:04d}-{end%12+1:02d}'
def read(c,u,settings,include_next=True):
    start,end=period(settings);summary=billing_plan.summary(c,u,start) if billing_plan.load(c)['enabled'] else fee_adjustments.summary(c,u,settings['cycle'],start)
    if summary is None:raise ValueError('この徴収期間の会費設定がありません。')
    fk=key(c,u);invoice=fk+':'+start
    method=c.execute('SELECT method FROM family_payment_methods WHERE family_key=?',(fk,)).fetchone()
    receipt=c.execute('SELECT body FROM family_payment_receipts WHERE invoice_key=?',(invoice,)).fetchone()
    value={**summary,'start_month':start,'end_month':end,'method':method[0] if method and payment_methods.valid(method[0]) else '', 'receipt':json.loads(receipt[0]) if receipt else None}
    value['revision']=hashlib.sha256(json.dumps({'invoice':invoice,'summary':summary,'end':end},sort_keys=True,ensure_ascii=False).encode()).hexdigest()
    if include_next:
        value['history']=[{**json.loads(r['body']),'updated':r['updated']} for r in c.execute('SELECT body,updated FROM family_payment_receipts WHERE family_key=? ORDER BY updated DESC,invoice_key DESC',(fk,))]
    if include_next:value['next']=read(c,u,{**settings,'start_month':fee_adjustments.next_month(end)},False)
    return value

def set_method(c,u,d):
    method=d.get('method')
    if not payment_methods.valid(method):raise ValueError('支払い方法を選択してください。')
    old=c.execute('SELECT method FROM family_payment_methods WHERE family_key=?',(key(c,u),)).fetchone()
    c.execute('INSERT OR REPLACE INTO family_payment_methods VALUES(?,?,?)',(key(c,u),method,time.strftime('%Y-%m-%d %H:%M:%S')))
    if not old or old[0]!=method:c.execute('INSERT INTO payment_method_history VALUES(?,?,?,?,?)',(secrets.token_hex(12),key(c,u),method,time.strftime('%Y-%m-%d %H:%M:%S'),u['id']))

def checkout(c,u,d,settings):
    if u['role']!='member':raise ValueError('会員用の手続きです。')
    state=read(c,u,settings)
    if state['receipt']:return
    if d.get('revision')!=state['revision']:raise ValueError('請求内容が更新されています。再確認してください。')
    if state['total'] is None or not state['method']:raise ValueError('金額の設定・支払い方法の登録が必要です。')
    body={k:state[k] for k in ('lines','total','start_month','end_month','method')};body['status']='デモ手続き済み（実決済なし）'
    c.execute('INSERT INTO family_payment_receipts VALUES(?,?,?,?)',(key(c,u)+':'+state['start_month'],key(c,u),json.dumps(body,ensure_ascii=False),time.strftime('%Y-%m-%d %H:%M:%S')))
