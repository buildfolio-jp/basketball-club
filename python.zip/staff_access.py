"""Coach-specific delegation using the existing restricted permission evaluator."""
import json,admin_access

def init(c):
 c.execute('CREATE TABLE IF NOT EXISTS coach_access(user_id TEXT PRIMARY KEY,kind TEXT,permissions TEXT,revision INTEGER)')
 # Preserve existing restricted grants when retiring administrator rank 2.
 for r in list(c.execute("SELECT a.* FROM admin_access a JOIN users u ON u.id=a.user_id WHERE a.rank=2 AND u.role='admin'")):
  c.execute('INSERT OR IGNORE INTO coach_access VALUES(?,?,?,1)',(r['user_id'],'個別設定',r['permissions']))
  c.execute("UPDATE users SET role='coach' WHERE id=?",(r['user_id'],))
  c.execute('DELETE FROM admin_access WHERE user_id=?',(r['user_id'],))

def effective(c,u):
 r=c.execute('SELECT * FROM coach_access WHERE user_id=?',(u['id'],)).fetchone()
 if not r:return u
 grants=json.loads(r['permissions']);baseline={k:'view' for k in ('schedule','attendance-list','conditioning','results','members','staff-members','worksheets','basket-notes','announcement-admin','survey-admin','shop-admin','board-admin')}
 return {**u,'role':'admin','delegated_coach':True,'staff_kind':r['kind'],'admin_rank':2,'assigned_permissions':grants,'admin_permissions':{**{k:v for k,v in grants.items() if v!='none'},**{k:('edit' if grants.get(k)=='edit' else v) for k,v in baseline.items()}}}

def listing(c):
 configs={r['user_id']:dict(r) for r in c.execute('SELECT * FROM coach_access')}
 return [{**dict(u),**({'kind':'標準コーチ','revision':0,'permissions':{}} if u['id'] not in configs else {**configs[u['id']],'permissions':json.loads(configs[u['id']]['permissions'])})} for u in c.execute("SELECT id,name FROM users WHERE role='coach' AND active=1")]

def save(c,u,d):
 if not admin_access.full(u):raise PermissionError('管理者のみコーチの権限を変更できます。')
 uid=d.get('id');kind=d.get('kind');grants=d.get('permissions')
 if not c.execute("SELECT 1 FROM users WHERE id=? AND role='coach'",(uid,)).fetchone():raise ValueError('コーチを選択してください。')
 if kind not in ('閲覧中心','運営コーチ','個別設定') or not isinstance(grants,dict) or any(k not in admin_access.KEYS or v not in ('none','view','edit') for k,v in grants.items()):raise ValueError('種類と権限を確認してください。')
 old=c.execute('SELECT revision FROM coach_access WHERE user_id=?',(uid,)).fetchone();rev=old[0] if old else 0
 if d.get('revision')!=rev:raise ValueError('権限が更新されています。開き直してください。')
 c.execute('INSERT OR REPLACE INTO coach_access VALUES(?,?,?,?)',(uid,kind,json.dumps(grants),rev+1))
 c.execute('INSERT OR REPLACE INTO staff_profiles VALUES(?,?)',(uid,kind))

def init_officers(c):c.execute('CREATE TABLE IF NOT EXISTS officer_access(assignment_id TEXT PRIMARY KEY,permissions TEXT,revision INTEGER)')
def officer_listing(c):
 return [{**dict(r),'permissions':json.loads(r['permissions'] or '{}'),'revision':r['access_revision'] or 0} for r in c.execute("SELECT a.*,p.permissions,p.revision AS access_revision FROM accounting_assignments a LEFT JOIN officer_access p ON p.assignment_id=a.id WHERE a.active=1")]
def officer_save(c,u,d):
 if not admin_access.full(u) or u.get('delegated_coach') or u.get('delegated_officer'):raise PermissionError('管理者のみ設定できます。')
 aid=d.get('id');grants=d.get('permissions')
 if not c.execute('SELECT 1 FROM accounting_assignments WHERE id=? AND active=1',(aid,)).fetchone():raise ValueError('役員を選択してください。')
 if not isinstance(grants,dict) or any(k not in admin_access.KEYS or v not in ('none','view','edit') for k,v in grants.items()):raise ValueError('権限を確認してください。')
 old=c.execute('SELECT revision FROM officer_access WHERE assignment_id=?',(aid,)).fetchone();rev=old[0] if old else 0
 if d.get('revision')!=rev:raise ValueError('設定を開き直してください。')
 c.execute('INSERT OR REPLACE INTO officer_access VALUES(?,?,?)',(aid,json.dumps(grants),rev+1))
def officer_effective(c,u):
 import accounting
 row=c.execute('SELECT p.permissions FROM accounting_assignments a LEFT JOIN officer_access p ON p.assignment_id=a.id WHERE a.login_id=? AND a.year=? AND a.active=1',(u['id'],accounting.fiscal_year())).fetchone()
 grants=json.loads(row[0]) if row and row[0] else {}
 return {**u,'role':'admin','delegated_officer':True,'admin_rank':2,'assigned_permissions':grants,'admin_permissions':{**grants,'finance-admin':'edit'}}
