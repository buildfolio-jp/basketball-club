import base64,json,re,secrets,time
import scheduling
def init(c):
    c.execute('CREATE TABLE IF NOT EXISTS schedule_documents(id TEXT PRIMARY KEY,title TEXT,month TEXT,members TEXT,content BLOB,updated TEXT)')
    if 'categories' not in {r[1] for r in c.execute('PRAGMA table_info(schedule_documents)')}:c.execute("ALTER TABLE schedule_documents ADD COLUMN categories TEXT DEFAULT '[]'")
def can_read(c,u,row):
    groups=json.loads(row['categories'] or '[]')
    if u['role']!='member':return True
    if not groups:return u['id'] in json.loads(row['members'])
    r=c.execute('SELECT categories FROM member_categories WHERE user_id=?',(u['id'],)).fetchone()
    return bool(r and scheduling.categories(r[0])&set(groups))
def read(c,u):
    rows=[]
    for row in c.execute('SELECT id,title,month,members,categories,updated FROM schedule_documents ORDER BY month DESC,updated DESC'):
        r=dict(row);ids=json.loads(r.pop('members'))
        r['categories']=json.loads(r['categories'] or '[]')
        if can_read(c,u,row):
            if u['role']!='member':r['member_ids']=ids
            rows.append(r)
    return rows
def save(c,d):
    if d.get('delete'):
        c.execute('DELETE FROM schedule_documents WHERE id=?',(d.get('id'),));return
    title=str(d.get('title','')).strip();month=str(d.get('month',''));ids=d.get('member_ids')
    if not title or len(title)>100 or not re.fullmatch(r'\d{4}-(0[1-9]|1[0-2])',month):raise ValueError('タイトル・対象月を確認してください。')
    groups=d.get('categories',[])
    if not isinstance(groups,list) or any(g not in ('男子A','男子B','女子A','女子B','U15A','U15B') for g in groups):raise ValueError('カテゴリを確認してください。')
    if 'categories' in d and not groups:raise ValueError('閲覧できるカテゴリを選択してください。')
    if groups:ids=[r['user_id'] for r in c.execute("SELECT m.* FROM member_categories m JOIN users u ON u.id=m.user_id WHERE u.role='member' AND u.active=1") if scheduling.categories(r['categories'])&set(groups)]
    valid={r[0] for r in c.execute("SELECT id FROM users WHERE role='member' AND active=1")}
    if not isinstance(ids,list) or (not ids and not groups) or any(not isinstance(uid,str) or uid not in valid for uid in ids):raise ValueError('対象会員を選択してください。')
    try:content=base64.b64decode(d.get('content',''),validate=True)
    except Exception:raise ValueError('PDFファイルを確認してください。')
    if not content.startswith(b'%PDF-') or b'%%EOF' not in content[-2048:] or not 0<len(content)<=5*1024*1024:raise ValueError('5MB以下のPDFを選択してください。')
    c.execute('INSERT INTO schedule_documents VALUES(?,?,?,?,?,?,?)',(secrets.token_hex(12),title,month,json.dumps(list(dict.fromkeys(ids))),content,time.strftime('%Y-%m-%d %H:%M:%S'),json.dumps(groups)))
