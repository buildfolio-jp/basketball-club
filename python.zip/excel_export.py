"""Dependency-free runtime XLSX export, supported by Excel on Windows and macOS.
Writes user text as inline strings; only code-defined formulas are executable.
"""
from zipfile import ZipFile, ZIP_DEFLATED
from xml.sax.saxutils import escape
from pathlib import Path
import re
import attendance_excel
import billing_plan

def clean(v):
    return escape(re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f]', '', str(v)))

def col(n):
    s=''
    while n:
        n,r=divmod(n-1,26);s=chr(65+r)+s
    return s

def sheet_xml(headers, rows, roster=False, staff=False, member_view=False):
    out=['<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols>']
    for i,h in enumerate(headers,1):
        width=42 if h in ('メモ','連絡事項','会場','連絡先','動画URL','練習・試合名','カテゴリー') else 23
        if roster: width=[14,18,23,23,23,16,36,32,36,23,23,23,36,28][i-1]
        if member_view: width=[32,64,20,20,42,28][i-1]
        out.append(f'<col min="{i}" max="{i}" width="{width}" customWidth="1"/>')
    out.append('</cols><sheetData>')
    for ri, row in enumerate([headers]+rows,1):
        out.append(f'<row r="{ri}" ht="30" customHeight="1">')
        for ci,v in enumerate(row,1):
            ref=f'{col(ci)}{ri}';style=1 if ri==1 else (2 if ri%2==0 else 0)
            if roster and ri>1: style=2 if ((ri-2)//2)%2==0 else 0
            if member_view and ri==14:style=1
            if isinstance(v,dict) and 'formula' in v:
                cached=v['cached'];typ='' if isinstance(cached,(int,float)) else ' t="str"'
                if v.get('percent'):style=3
                out.append(f'<c r="{ref}" s="{style}"{typ}><f>{clean(v["formula"])}</f><v>{clean(cached)}</v></c>')
            elif isinstance(v,(int,float)):
                out.append(f'<c r="{ref}" s="{style}"><v>{v}</v></c>')
            else:
                out.append(f'<c r="{ref}" s="{style}" t="inlineStr"><is><t xml:space="preserve">{clean(v if v is not None else "")}</t></is></c>')
        out.append('</row>')
    out.append('</sheetData>')
    if roster:
        merges=[f'{c}{r}:{c}{r+1}' for r in range(2,len(rows)+2,2) for c in 'ABCFGHIJKLMN']
        if merges: out.append(f'<mergeCells count="{len(merges)}">'+''.join(f'<mergeCell ref="{ref}"/>' for ref in merges)+'</mergeCells>')
    elif not member_view:
        out.append(f'<autoFilter ref="A1:{col(len(headers))}{max(1,len(rows)+1)}"/>')
    if staff:
        out.append('<dataValidations count="1"><dataValidation type="list" allowBlank="1" showErrorMessage="1" errorStyle="stop" errorTitle="スタッフ区分" error="コーチまたはスタッフを選択してください。" sqref="E2:E1048576"><formula1>"コーチ,スタッフ"</formula1></dataValidation></dataValidations>')
    if member_view:
        out.append('<dataValidations count="1"><dataValidation type="list" allowBlank="1" showErrorMessage="1" errorStyle="stop" sqref="B2"><formula1>AttendanceMembers</formula1></dataValidation></dataValidations>')
    validations=[]
    if headers==billing_plan.HEADERS['会員別会費設定']:
        validations=[('A2:A10000','今回,次回'),('D2:D10000',','.join(billing_plan.CATEGORIES)),('F2:H10000','有,無')]
    elif headers==billing_plan.HEADERS['徴収期間']:validations=[('A2:A3','今回,次回')]
    if validations:out.append('<dataValidations count="'+str(len(validations))+'">'+''.join('<dataValidation type="list" allowBlank="0" showErrorMessage="1" errorStyle="stop" sqref="'+ref+'"><formula1>"'+clean(values)+'"</formula1></dataValidation>' for ref,values in validations)+'</dataValidations>')
    out.append('</worksheet>')
    return ''.join(out)

def write_workbook(d,path):
    roles={'member':'会員','coach':'コーチ','admin':'管理者'}
    events={e['id']:e for e in d['events']}
    roster=[]
    for u in d['users']:
        if u['role']=='member':
            roster.extend([[u.get('enrollment',{}).get('status','在籍' if u['active'] else '退会'),u['id'],'',u['name'],'',u['grade'],'','','','','',''],['']*12])
    for r in d['trials']:
        roster.extend([['体験申込','','',r['name'],r.get('parent_name',''),r['grade'],'',' / '.join(filter(None,[r.get('phone',''),('LINE ID: ' if r.get('contact_type')=='line' else '')+r['contact']])),r['note'],'','',''],['']*12])
    for row in roster:row.extend(['',''])
    offset=2*sum(u['role']=='member' for u in d['users'])
    for i,r in enumerate(d['trials']):
        roster[offset+2*i][7]=r.get('phone','')
        roster[offset+2*i][12:14]=[r.get('email',''),r.get('line_id','')]
    sheets=[('生徒・体験者一覧',['区分','会員ID','会員パスワード','子供の氏名','親の氏名','学年','住所','連絡先（電話番号）','備考','入会日時','退会日時','会費決済有無','メールアドレス','LINE ID'],roster),
      ('スタッフ一覧',['会員ID','会員パスワード','氏名','担当学年','スタッフ区分','権限'],[[u['id'],'',u['name'],u['grade'] if u['grade'] not in ('スタッフ','運営') else '', u.get('staff_kind','コーチ' if u['role']=='coach' else 'スタッフ'),roles[u['role']]] for u in d['users'] if u['role'] in ('coach','admin')]),
      ('出席簿',['日付','練習・試合名','ID','氏名','出欠予定','実際の出欠','更新日時'],[[r['date'],r['title'],r['user_id'],r['name'],r['attendance'],r['actual'],r['updated']] for r in d['reports']]),
      ('コンディション',['日付','練習・試合名','ID','氏名','体の調子','心の調子','朝ご飯','調子の悪いところ','その他の連絡事項','旧体調（1〜5）','旧睡眠時間','更新日時'],[[r['date'],r['title'],r['user_id'],r['name'],r.get('body_condition',''),r.get('mind_condition',''),r.get('breakfast',''),r.get('unwell_area',''),r['note'],r['condition'],r['sleep'],r['updated']] for r in d['reports']]),
      ('活動日程',['日付','練習・試合名','時間','会場','種別','対象','メモ','地図URL'],[[e.get(k,'') for k in ['date','title','time','place','kind','group_name','note','map_url']] for e in d['events']]),
      ('試合結果',['日付','対戦相手','得点','失点','対象','メモ','動画URL'],[[r[k] for k in ['date','opponent','ours','theirs','group_name','note','video']] for r in d['results']]),
      ('体験申込',['申込日時','体験会','体験日','開始時間','氏名','学年','保護者名','電話番号','メールアドレス','LINE ID','連絡事項','確認状況','確認者','確認日時'],[[r['created'],events.get(r['event_id'],{}).get('title',''),events.get(r['event_id'],{}).get('date',''),events.get(r['event_id'],{}).get('time',''),r['name'],r['grade'],r.get('parent_name',''),r.get('phone',''),r.get('email',''),r.get('line_id',''),r['note'],'確認済み' if r.get('reviewed_at') else '未確認',r.get('reviewer_name',''),r.get('reviewed_at','')] for r in d['trials']])]
    for u in d['users']:
        if u['role']=='member':
            sheets.append(('個人_'+u['id'][:25],['氏名','日付','練習・試合名','出欠予定','実際の出欠','体の調子','心の調子','朝ご飯','調子の悪いところ','その他の連絡事項','旧体調（1〜5）','旧睡眠時間'],[[r['name'],r['date'],r['title'],r['attendance'],r['actual'],r.get('body_condition',''),r.get('mind_condition',''),r.get('breakfast',''),r.get('unwell_area',''),r['note'],r['condition'],r['sleep']] for r in d['reports'] if r['user_id']==u['id']]))
    billing=d.get('billing',{})
    settings=billing.get('settings',{'cycle':'半年払い'})
    prefs=billing.get('preferences',{})
    sheets.append(('会費設定',['支払い期間','適用範囲','更新日時','更新者ID','決済連携'],[[settings['cycle'],'全会員',settings.get('updated',''),settings.get('updated_by',''),'未接続（デモ）']]))
    sheets.append(('会費管理',['会員ID','氏名','学年','在籍状況','支払い期間','支払方法（希望）','方法登録日時','期間設定更新日時','決済状況'],[[u['id'],u['name'],u['grade'],u.get('enrollment',{}).get('status','在籍' if u['active'] else '退会'),settings['cycle'],prefs.get(u['id'],{}).get('method','未登録'),prefs.get(u['id'],{}).get('registered',''),settings.get('updated',''),'実決済未連携'] for u in d['users'] if u['role']=='member']))
    sheets.append(('会費設定履歴',['変更日時','支払い期間','変更者ID','変更者氏名'],[[h['updated'],h['cycle'],h['updated_by'],h.get('updater_name','')] for h in billing.get('history',[])]))
    sheets.append(('会費金額設定',['区分','対象ID','支払い期間','金額（円）'],[[r['kind'],r['target'],r['cycle'],r['amount']] for r in d.get('fee_amounts',[])]))
    sheets.append(('お知らせ既読一覧',['お知らせID','タイトル','会員ID','選手名','確認状況','確認した会員','確認日時'],[[r['item_id'],r['title'],r['user_id'],r['name'],r['status'],r['reader_name'],r['read_at']] for r in d.get('announcement_reads',[])]))
    collection=d.get('fee_collection',{})
    sheets.append(('会費徴収サマリー',['集計開始月','集計終了月','区分','徴収予定額','徴収済み額','未納額','金額未設定人数'],[[p['start'],p['end'],'合計',p['due'],p['collected'],p['unpaid'],p['unknown']] for p in collection.get('periods',[])]))
    sheets.append(('会費支払方法別内訳',['集計開始月','集計終了月','支払方法','徴収予定額','徴収済み額','未納額','金額未設定人数'],[[p['start'],p['end'],m['method'],m['due'],m['collected'],m['unpaid'],m['unknown']] for p in collection.get('periods',[]) for m in p['methods']]))
    sheets.append(('会費納入状況一覧',['集計開始月','集計終了月','会員ID','氏名','対象開始月','対象終了月','納入状態','支払方法','徴収予定額','徴収済み額','未納額','確認日時','確認者','備考'],[[r['start_month'],r['end_month'],r['user_id'],r['name'],r.get('period_start') or r['start_month'],r.get('period_end') or r['end_month'],r['collection_status'],r['method'],r['due'],r['collected'],r['unpaid'] if r['due'] is not None else None,r['confirmed_at'],r['confirmed_by'],r.get('note','')] for r in collection.get('rows',[])]))
    ledger=d.get('fee_ledger',{})
    sheets.append(('会員別会費履歴',['会員ID','氏名','開始月','終了月','会員金額','家庭合計','家庭一括金額設定','支払方法','入金状態','確認日時','確認者','デモ手続き'],[[r['user_id'],r['name'],r.get('period_start') or r['start_month'],r.get('period_end') or r['end_month'],r['amount'],r['family_total'],'有' if r['family_override'] else '無',r['method'],r['status'],r['confirmed_at'],r['confirmed_by'],'済' if r['demo_checkout'] else '未'] for r in ledger.get('invoices',[])]))
    sheets.append(('会員別支払方法',['会員ID','氏名','家庭キー','支払方法','更新日時'],[[r['user_id'],r['name'],r['family_key'],r['method'],r['updated']] for r in ledger.get('methods',[])]))
    sheets.append(('支払方法変更履歴',['会員ID','氏名','支払方法','変更日時','変更者'],[[r['user_id'],r['name'],h['method'],h['updated'],h['changed_by']] for r in ledger.get('methods',[]) for h in r['history']]))
    sheets.append(('家庭別支払方法',['家庭キー','支払い方法','更新日時'],[[r['family_key'],r['method'],r['updated']] for r in d.get('family_payment_methods',[])]))
    sheets.append(('家庭別支払記録',['請求キー','家庭キー','対象開始月','対象終了月','対象会員','合計金額','支払い方法','状態','記録日時'],[[r['invoice_key'],r['family_key'],r['body']['start_month'],r['body']['end_month'],'・'.join(v['name'] for v in r['body']['lines']),r['body']['total'],r['body']['method'],r['body']['status'],r['updated']] for r in d.get('family_payment_receipts',[])]))
    sheets.append(('会費適用設定',['区分','対象ID','適用開始月','適用範囲','設定金額','理由','更新日時'],[[r['kind'],r['target'],r['start_month'],'この期間だけ' if r['scope']=='once' else '以降も適用',r['amount'],r['note'],r['updated']] for r in d.get('fee_adjustments',[])]))
    lunch=d.get('lunch_answers',[])
    sheets.append(('お弁当回答',['アンケートID','タイトル','会員ID','氏名','注文','対象','個数','合計金額','回答日時'],[[a['item_id'],a['title'],a['user_id'],a['name'],a['order'],a['who'],len(a['meals']),a['total'],a['updated']] for a in lunch]))
    sheets.append(('お弁当内訳',['アンケートID','会員ID','氏名','子供・保護者','メニュー','金額'],[[a['item_id'],a['user_id'],a['name'],m['group'],m['name'],m['price']] for a in lunch for m in a['meals']]))
    gs=d.get('game_stats',[])
    results={r['id']:r for r in d['results']}
    sheets.append(('個人試合記録',['試合ID','日付','対戦相手','会員ID','氏名','背番号','出場状況','得点','ファウル','リバウンド','アシスト','スティール','ブロック','ターンオーバー'],[[r['result_id'],results.get(r['result_id'],{}).get('date',''),results.get(r['result_id'],{}).get('opponent',''),r['user_id'],r['name'],r['number'],r['participation']]+[r.get(k) for k in ('points','fouls','rebounds','assists','steals','blocks','turnovers')] for r in gs]))
    sheets.append(('日程詳細',['日程ID','状態','参加対象','選出メンバー','注意事項','地図URL','添付ファイル','更新日時'],[[b['event_id'],label,'全員' if v['mode']=='all' else '指定メンバー',' ／ '.join(n['name'] for n in v['names']),v['note'],v['map_url'],' ／ '.join(f['name'] for f in v['files']),v['updated']] for b in d.get('event_briefings',[]) for key,label in [('draft','下書き'),('published','公開中')] for v in [b.get(key)] if v]))
    if d.get('billing_plan'):sheets.extend(billing_plan.sheets(d['billing_plan']))
    sheets.extend(attendance_excel.sheets(d))
    sheets.append(('家族設定',['家族ID','会員ID','氏名','在籍状況'],[[u.get('family_id',''),u['id'],u['name'],u.get('enrollment',{}).get('status','在籍' if u['active'] else '退会')] for u in d['users'] if u['role']=='member']))
    temp=Path(str(path)+'.tmp')
    sheets.append(('物販注文',['注文番号','会員ID','会員名','商品名','サイズ・種類','数量','税込単価','商品小計','送料（注文単位）','注文合計（先頭行のみ）','支払方法','状態','連絡事項','注文日時','受け渡し状況','受け渡し日時'],[[o['id'],o['user_id'],o['name'],i['title'],i['size'],i['quantity'],i['unit_price'],i['subtotal'],o['body']['shipping'] if n==0 else '',o['body']['total'] if n==0 else '',o['method'],o['status'],i['note'],o['created'],'受け渡し完了' if o.get('delivered_at') else '未受け渡し',o.get('delivered_at') or ''] for o in d.get('shop_orders',[]) for n,i in enumerate(o['body'].get('items',[o['body']]))]))
    sheets.append(('物販受け渡し明細',['注文番号','会員名','商品名','サイズ・種類','注文数量','受け渡し済み数量','未受け渡し数量','コメント','現金徴収額','現金受け取り'],[[o['id'],o['name'],i['title'],i['size'],i['quantity'],o['deliveries'][n]['quantity'],i['quantity']-o['deliveries'][n]['quantity'],o['deliveries'][n]['note'],i['subtotal'],'受け取り済み' if o['deliveries'][n].get('cash_received') else '未受け取り'] for o in d.get('shop_orders',[]) for n,i in enumerate(o['body'].get('items',[o['body']]))]))
    activity=d.get('staff_activity',{});names={u['id']:u['name'] for u in d['users']}
    approvals={(r['user_id'],r['week']):r for r in activity.get('approvals',[])}
    sheets.append(('スタッフ活動実績',['スタッフID','氏名','日付','開始','終了','休憩（分）','活動時間（分）','内容','更新日時'],[[r['user_id'],names.get(r['user_id'],''),r['date'],r['start'],r['end'],r['break_minutes'],r['minutes'],r['note'],r['updated']] for r in activity.get('logs',[])]))
    sheets.append(('スタッフ週別サマリー',['スタッフID','氏名','週開始（月曜）','活動日数','活動時間（時間）','承認状態','承認操作者','更新日時'],[[r['user_id'],names.get(r['user_id'],''),r['week'],r['days'],round(r['minutes']/60,2),'承認済み' if a.get('approved') else '未承認',names.get(a.get('approved_by'),''),a.get('updated','')] for r in activity.get('weeks',[]) for a in [approvals.get((r['user_id'],r['week']),{})]]))
    if d.get('only_extra_sheets'):sheets=[]
    if not d.get('only_extra_sheets'):sheets.append(('在籍・休会設定',['会員ID','氏名','在籍状況','停止理由','その他の理由','指定日区分','指定日'],[[u['id'],u['name'],u.get('enrollment',{}).get('status','在籍' if u['active'] else '退会'),u.get('enrollment',{}).get('reason',''),u.get('enrollment',{}).get('note',''),u.get('enrollment',{}).get('scheduled_status','') if u.get('enrollment',{}).get('pause_mode')=='scheduled' else '',u.get('enrollment',{}).get('pause_date','')] for u in d['users'] if u['role']=='member']))
    if not d.get('only_extra_sheets'):sheets.append(('会員学校一覧',['会員ID','氏名','学年','学校名'],[[u['id'],u['name'],u['grade'],u.get('school','')] for u in d['users'] if u['role']=='member']))
    sheets.extend(d.get('extra_sheets',[]))
    if d.get('unpaid_only'):sheets=[s for s in sheets if s[0]=='会費納入状況一覧']
    with ZipFile(temp,'w',ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml','<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'+''.join(f'<Override PartName="/xl/worksheets/sheet{i}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' for i in range(1,len(sheets)+1))+'</Types>')
        z.writestr('_rels/.rels','<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
        z.writestr('xl/workbook.xml','<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>'+''.join(f'<sheet name="{clean(s[0])}" sheetId="{i}" r:id="rId{i}"/>' for i,s in enumerate(sheets,1))+'</sheets>'+('' if d.get('unpaid_only') or d.get('only_extra_sheets') else '<definedNames><definedName name="AttendanceMembers">&apos;会員選択リスト&apos;!$A$2:$A$'+str(max(2,1+sum(u['role']=='member' for u in d['users'])))+'</definedName></definedNames>')+'<calcPr calcId="191029" fullCalcOnLoad="1" forceFullCalc="1" calcMode="auto"/></workbook>')
        z.writestr('xl/_rels/workbook.xml.rels','<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'+''.join(f'<Relationship Id="rId{i}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{i}.xml"/>' for i in range(1,len(sheets)+1))+f'<Relationship Id="rId{len(sheets)+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>')
        z.writestr('xl/styles.xml','''<?xml version="1.0"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font></fonts><fills count="4"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF182B25"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFF0F4E7"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="4"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="center"/></xf><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment vertical="center"/></xf><xf numFmtId="0" fontId="0" fillId="3" borderId="0" xfId="0" applyFill="1" applyAlignment="1"><alignment vertical="center"/></xf><xf numFmtId="10" fontId="0" fillId="3" borderId="0" xfId="0" applyNumberFormat="1" applyFill="1"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>''')
        for i,(name,headers,rs) in enumerate(sheets,1): z.writestr(f'xl/worksheets/sheet{i}.xml',sheet_xml(headers,rs,roster=name=='生徒・体験者一覧',staff=name=='スタッフ一覧',member_view=name=='会員別出席'))
    temp.replace(path)
