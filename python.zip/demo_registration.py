"""Optional enrollment fixtures for authenticated demo accounts only."""
import os,secrets
import accounts,accounting

def allowed(user):
 return os.environ.get('CHEETAHS_DEMO_REGISTRATION')=='1' and bool(user) and user.get('login_id',user.get('id')) in ('member01','coach01','admin01')

def prepare(c,user,kind,data,hash_password):
 key='invite_code' if kind=='member' else 'code'
 if str(data.get(key,'')).strip() or not allowed(user):return data
 d=dict(data);uid='demo_'+secrets.token_hex(10);code=secrets.token_urlsafe(24)
 if kind=='member':
  c.execute("INSERT INTO users VALUES(?,?,?,'member',?,1)",(uid,str(d.get('player_name','')).strip(),d.get('grade',''),hash_password(secrets.token_urlsafe(32))))
  c.execute('INSERT INTO student_only VALUES(?)',(uid,))
  c.execute('INSERT INTO member_invites VALUES(?,?)',(uid,code))
 elif kind=='coach':
  c.execute("INSERT INTO users VALUES(?,?,'スタッフ','coach',?,1)",(uid,str(d.get('name','')).strip(),hash_password(secrets.token_urlsafe(32))))
  c.execute("INSERT INTO coach_registration VALUES(?,?,'invited','','','',?)",(uid,code,accounts.now()))
 else:
  c.execute('INSERT INTO accounting_assignments VALUES(?,?,?,?,?,?,?)',(uid,'デモ役員 '+str(d.get('id','')),accounting.fiscal_year(),'',code,1,secrets.token_hex(12)))
 d[key]=code
 return d
