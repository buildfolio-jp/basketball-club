"""Confirmed attendance rates and a fixed local Excel input."""
import io,csv,json,hashlib,time,datetime,zipfile,re
from pathlib import Path
import xml.etree.ElementTree as ET
import scheduling,admin_access,local_fees,accounting
HEADERS=['会員ID','会員名','日程ID','日付','日程名','実際の出欠']
PRESENT=('出席','遅刻','早退','遅刻・早退')
def init(c):c.execute('CREATE TABLE IF NOT EXISTS attendance_import_rows(user_id TEXT,event_id TEXT,digest TEXT,PRIMARY KEY(user_id,event_id))')
def allowed(u):return u and (u['role']=='coach' or admin_access.can(u,'attendance-list'))
def records(c,uid='',month=''):
 months=set(month.split(',')) if month else set()
 if any(not re.fullmatch(r'\d{4}-(0[1-9]|1[0-2])',m) for m in months):raise ValueError('対象月をYYYY-MM形式で選択してください。')
 today=accounting.today().isoformat();events=[dict(e) for e in c.execute("SELECT * FROM events WHERE kind<>'体験会' AND date<=? ORDER BY date",(today,)) if not months or e['date'][:7] in months]
 reports={(r['user_id'],r['event_id']):dict(r) for r in c.execute('SELECT * FROM reports')};result=[]
 for u in c.execute("SELECT id,name,grade FROM users WHERE role='member'"+(' AND id=?' if uid else ''),(uid,) if uid else ()):
  for e in events:
   r=reports.get((u['id'],e['id']))
   if r or scheduling.eligible(c,u['id'],e):result.append([u['id'],u['name'],e['id'],e['date'],e['title'],r.get('actual') or '未確認' if r else '未確認'])
 return result
def read(c,uid='',month=''):
 rs=records(c,uid,month);out=[]
 for u in c.execute("SELECT id,name,grade FROM users WHERE role='member'"+(' AND id=?' if uid else ''),(uid,) if uid else ()):
  own=[r for r in rs if r[0]==u['id']];present=sum(r[5] in PRESENT for r in own);absent=sum(r[5]=='欠席' for r in own);confirmed=present+absent
  out.append({**dict(u),'present':present,'absent':absent,'unconfirmed':len(own)-confirmed,'confirmed':confirmed,'rate':round(100*present/confirmed,1) if confirmed else None})
 return out
def csv_bytes(rows):
 out=io.StringIO();w=csv.writer(out);w.writerow(['会員ID','会員名','学年','出席数（遅刻・早退含む）','欠席数','確認済み件数','未確認件数','出席率（%）'])
 for r in rows:w.writerow([("'"+str(v)) if str(v).lstrip().startswith(('=','+','-','@')) else v for v in [r[k] if r[k] is not None else '' for k in ('id','name','grade','present','absent','confirmed','unconfirmed','rate')]])
 return ('\ufeff'+out.getvalue()).encode()
def pdf_bytes(rows,month):
 lines=['出席率レポート',month.replace(',', '・') or '全期間（本日まで）','出席率＝出席数（遅刻・早退を含む）÷確認済み件数。未確認と未来の予定は除外。','']
 for r in rows:lines += [r['name']+' ／ '+r['grade'],'出席率：'+(str(r['rate'])+'%' if r['rate'] is not None else '未集計'),f"出席 {r['present']}回 ／ 欠席 {r['absent']}回 ／ 未確認 {r['unconfirmed']}回",'']
 return accounting.pdf_bytes({},lines)
def workbook(path,rs):
 from excel_export import write_workbook
 write_workbook({'users':[],'events':[],'reports':[],'results':[],'trials':[],'only_extra_sheets':True,'extra_sheets':[('出欠入力',HEADERS,rs)]},path)
def status(c):
 r=c.execute("SELECT value FROM meta WHERE key='attendance_input'").fetchone();return json.loads(r[0]) if r else {'ok':True,'message':'入力待ち'}
def sync(c,path):
 path=Path(path)
 if not path.exists():workbook(path,records(c))
 raw=path.read_bytes();digest=hashlib.sha256(raw).hexdigest()
 if status(c).get('digest')==digest:return False
 state={'digest':digest,'updated':time.strftime('%Y-%m-%d %H:%M:%S')};changes=[]
 try:
  values=local_fees.parse(raw,'出欠入力',HEADERS);seen=set()
  if len(values)>10000:raise ValueError('10000行以内にしてください。')
  for uid,name,eid,day,title,actual in values:
   if not any((uid,name,eid,day,title,actual)):continue
   if (uid,eid) in seen:raise ValueError('会員・日程が重複しています。')
   seen.add((uid,eid))
   if not c.execute("SELECT 1 FROM users WHERE id=? AND role='member'",(uid,)).fetchone() or not c.execute('SELECT 1 FROM events WHERE id=?',(eid,)).fetchone():raise ValueError('会員ID・日程IDを確認してください。')
   if actual not in (*PRESENT,'欠席','未確認',''):raise ValueError('実際の出欠は出席・欠席・遅刻・早退・遅刻・早退・未確認から指定してください。')
   actual='' if actual=='未確認' else actual;d=hashlib.sha256(actual.encode()).hexdigest();old=c.execute('SELECT digest FROM attendance_import_rows WHERE user_id=? AND event_id=?',(uid,eid)).fetchone()
   if not old or old[0]!=d:changes.append((uid,eid,actual,d))
  for uid,eid,actual,d in changes:
   c.execute('INSERT INTO reports(user_id,event_id,actual,updated) VALUES(?,?,?,?) ON CONFLICT(user_id,event_id) DO UPDATE SET actual=excluded.actual,updated=excluded.updated',(uid,eid,actual,state['updated']))
   c.execute('INSERT OR REPLACE INTO attendance_import_rows VALUES(?,?,?)',(uid,eid,d))
  state.update(ok=True,message=f'{len(changes)}件を反映しました。')
 except (ValueError,KeyError,StopIteration,ET.ParseError,zipfile.BadZipFile,IndexError) as e:state.update(ok=False,message=str(e));changes=[]
 c.execute("INSERT OR REPLACE INTO meta VALUES('attendance_input',?)",(json.dumps(state,ensure_ascii=False),));return bool(changes)
