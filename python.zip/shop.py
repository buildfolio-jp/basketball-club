"""Demo merchandise catalogue and idempotent simulated checkout. No payment provider."""
import base64,hashlib,json,secrets,time,re,admin_access

def init(c):
    c.execute('CREATE TABLE IF NOT EXISTS shop_line_deliveries(order_id TEXT,line_index INTEGER,quantity INTEGER,note TEXT,updated TEXT,revision INTEGER,PRIMARY KEY(order_id,line_index))')
    if 'cash_received' not in {r[1] for r in c.execute('PRAGMA table_info(shop_line_deliveries)')}:c.execute('ALTER TABLE shop_line_deliveries ADD COLUMN cash_received INTEGER NOT NULL DEFAULT 0')
    c.execute('CREATE TABLE IF NOT EXISTS shop_deliveries(order_id TEXT PRIMARY KEY,delivered_at TEXT,delivered_by TEXT)')
    c.execute('CREATE TABLE IF NOT EXISTS shop_products(item_id TEXT PRIMARY KEY,sizes TEXT,images TEXT)')
    c.execute('CREATE TABLE IF NOT EXISTS shop_images(id TEXT PRIMARY KEY,mime TEXT,content BLOB)')
    c.execute('CREATE TABLE IF NOT EXISTS shop_orders(id TEXT PRIMARY KEY,user_id TEXT,token TEXT,body TEXT,status TEXT,method TEXT,created TEXT,UNIQUE(user_id,token))')
    if not c.execute("SELECT 1 FROM meta WHERE key='shop_catalog_seed'").fetchone():
        items=[('shirt-demo','チームウェア',2500,['130','140','150','160','S','M','L','XL'],101),('shorts-demo','バスケットパンツ',3000,['130','140','150','160','S','M','L','XL'],102),('ball-demo','バスケットボール',4500,['5号','6号','7号'],103),('shoes-demo','バスケットシューズ',7800,['21.0cm','22.0cm','23.0cm','24.0cm','25.0cm','26.0cm','27.0cm'],104)]
        for rid,title,price,sizes,image in items:
            c.execute("INSERT INTO portal_items VALUES(?,'shop',?,?,?) ON CONFLICT(id) DO UPDATE SET title=excluded.title,body=excluded.body,amount=excluded.amount",(rid,title+'（デモ）','チームカラーのサンプル商品です。写真はAI生成のイメージです。',price))
            c.execute('INSERT OR IGNORE INTO shop_products VALUES(?,?,?)',(rid,json.dumps(sizes),json.dumps(['/uploads/'+format(image,'032x')+'.png'])))
        c.execute("INSERT INTO meta VALUES('shop_catalog_seed','1')")

    if not c.execute("SELECT 1 FROM meta WHERE key='shop_socks_protein_seed'").fetchone():
        for rid,title,price,sizes,body in [('socks-demo','バスケット用靴下',1000,['23〜25cm','25〜27cm'],'動作確認用の仮商品です。価格とサイズは後から変更できます。'),('protein-demo','プロテイン',3000,['チョコレート 500g','バニラ 500g'],'動作確認用の仮商品です。価格と種類は後から変更できます。')]:
            c.execute("INSERT OR IGNORE INTO portal_items VALUES(?,'shop',?,?,?)",(rid,title,body,price))
            c.execute('INSERT OR IGNORE INTO shop_products VALUES(?,?,?)',(rid,json.dumps(sizes,ensure_ascii=False),'[]'))
        c.execute("INSERT INTO meta VALUES('shop_socks_protein_seed','1')")

    if not c.execute("SELECT 1 FROM meta WHERE key='shop_socks_protein_photos'").fetchone():
        for rid,i in [('socks-demo',105),('protein-demo',106)]:
            c.execute("UPDATE shop_products SET images=? WHERE item_id=? AND images='[]'",(json.dumps(['/uploads/'+format(i,'032x')+'.png']),rid))
        c.execute("INSERT INTO meta VALUES('shop_socks_protein_photos','1')")

def products(c):
    result=[]
    for row in c.execute("SELECT i.*,p.sizes,p.images FROM portal_items i LEFT JOIN shop_products p ON p.item_id=i.id WHERE i.kind='shop' ORDER BY i.rowid"):
        r=dict(row);r['sizes']=json.loads(r['sizes'] or '["フリー"]');r['images']=json.loads(r['images'] or '[]')
        r['revision']=hashlib.sha256(json.dumps(r,sort_keys=True).encode()).hexdigest();result.append(r)
    return result

def orders(c,u):
    result=[{**dict(r),'body':json.loads(r['body'])} for r in c.execute('SELECT o.*,u.name,u.grade,d.delivered_at,d.delivered_by FROM shop_orders o JOIN users u ON u.id=o.user_id LEFT JOIN shop_deliveries d ON d.order_id=o.id'+(' WHERE o.user_id=?' if u['role']=='member' else '')+' ORDER BY o.rowid DESC',(u['id'],) if u['role']=='member' else ())]
    for order in result:
        items=order['body'].get('items') or [order['body']]
        order['deliveries']=[]
        for i,item in enumerate(items):
            row=c.execute('SELECT * FROM shop_line_deliveries WHERE order_id=? AND line_index=?',(order['id'],i)).fetchone()
            order['deliveries'].append(dict(row) if row else {'line_index':i,'quantity':item['quantity'] if order['delivered_at'] else 0,'note':'','updated':order['delivered_at'] or '', 'revision':0,'cash_received':0})
    return result

def read(c,u):return {'products':products(c),'orders':orders(c,u)}

def save(c,d):
    rid=d.get('id') or secrets.token_hex(16)
    existing=c.execute('SELECT kind FROM portal_items WHERE id=?',(rid,)).fetchone()
    if existing and existing[0]!='shop':raise ValueError('物販の商品を選択してください。')
    title=str(d.get('title','')).strip();body=str(d.get('body','')).strip();price=d.get('amount')
    sizes=d.get('sizes');keep=d.get('keep',[]);uploads=d.get('uploads',[])
    if not title or len(title)>120 or len(body)>4000 or type(price)!=int or not 0<=price<=1000000:raise ValueError('商品名・税込金額を確認してください。')
    if not isinstance(sizes,list) or not 1<=len(sizes)<=30 or any(not isinstance(s,str) or not s.strip() or len(s)>40 for s in sizes):raise ValueError('サイズ・種類を1〜30件登録してください。')
    old=c.execute('SELECT images FROM shop_products WHERE item_id=?',(rid,)).fetchone();old=json.loads(old[0]) if old else []
    if not isinstance(keep,list) or not isinstance(uploads,list) or len(keep)+len(uploads)>30 or any(x not in old for x in keep):raise ValueError('写真は合計30枚まで登録できます。')
    images=list(dict.fromkeys(keep))
    for f in uploads:
        try:raw=base64.b64decode(f['content'],validate=True)
        except Exception:raise ValueError('写真を読み込めません。')
        if not 0<len(raw)<=5*1024*1024:raise ValueError('写真は1枚5MB以下にしてください。')
        mime='image/jpeg' if raw.startswith(b'\xff\xd8\xff') else 'image/png' if raw.startswith(b'\x89PNG\r\n\x1a\n') else 'image/webp' if raw.startswith(b'RIFF') and raw[8:12]==b'WEBP' else None
        if not mime:raise ValueError('JPEG・PNG・WebPの写真を選択してください。')
        iid=secrets.token_hex(16);c.execute('INSERT INTO shop_images VALUES(?,?,?)',(iid,mime,raw));images.append('/api/shop_image?id='+iid)
    c.execute("INSERT INTO portal_items VALUES(?,'shop',?,?,?) ON CONFLICT(id) DO UPDATE SET title=excluded.title,body=excluded.body,amount=excluded.amount",(rid,title,body,price))
    c.execute('INSERT OR REPLACE INTO shop_products VALUES(?,?,?)',(rid,json.dumps(list(dict.fromkeys(sizes))),json.dumps(images)))

def create_order(c,u,d):
    if u['role']!='member':raise ValueError('会員のみ注文できます。')
    token=d.get('token','')
    if not isinstance(token,str) or not re.fullmatch('[a-zA-Z0-9-]{16,80}',token):raise ValueError('注文画面を開き直してください。')
    old=c.execute('SELECT id FROM shop_orders WHERE user_id=? AND token=?',(u['id'],token)).fetchone()
    if old:return old[0]
    requested=d.get('items',[d])
    if not isinstance(requested,list) or not 1<=len(requested)<=30:raise ValueError('カートには1〜30種類の商品を入れてください。')
    catalog={p['id']:p for p in products(c)};items=[]
    for entry in requested:
        if not isinstance(entry,dict):raise ValueError('カートの内容を確認してください。')
        p=catalog.get(entry.get('item_id'))
        if not p or p['revision']!=entry.get('revision'):raise ValueError('商品内容が変更されました。カートから該当商品を削除し、一覧を更新して追加し直してください。')
        qty=entry.get('quantity');size=entry.get('size');note=str(entry.get('note',''))
        if type(qty)!=int or not 1<=qty<=20 or size not in p['sizes'] or len(note)>1000:raise ValueError('サイズ・数量・連絡事項を確認してください。')
        items.append({'item_id':p['id'],'title':p['title'],'size':size,'quantity':qty,'unit_price':p['amount'],'subtotal':p['amount']*qty,'note':note})
    total=sum(i['subtotal'] for i in items)
    body={**items[0],'items':items,'shipping':0,'total':total,'subtotal':total}
    if len(items)>1:body.update(title='カートまとめ注文（'+str(len(items))+'種類）',size='商品別明細を参照',quantity=sum(i['quantity'] for i in items),note='')
    oid=secrets.token_hex(12);c.execute('INSERT INTO shop_orders VALUES(?,?,?,?,?,?,?)',(oid,u['id'],token,json.dumps(body,ensure_ascii=False),'注文受付（現金払い）','現金',time.strftime('%Y-%m-%d %H:%M:%S')));return oid

def checkout(c,u,d):
    order=c.execute('SELECT * FROM shop_orders WHERE id=? AND user_id=?',(d.get('id'),u['id'])).fetchone()
    if u['role']!='member' or not order:raise ValueError('注文が見つかりません。')
    if order['status']!='手続き待ち':return
    method='現金'
    status='注文受付（現金払い）'
    c.execute('UPDATE shop_orders SET status=?,method=? WHERE id=?',(status,method,order['id']))

def delivery(c,u,d):
    if not admin_access.can(u,'shop-admin',True):raise PermissionError('物販の編集権限が必要です。')
    order=next((r for r in orders(c,u) if r['id']==d.get('id')),None)
    if not order:raise ValueError('注文が見つかりません。')
    items=order['body'].get('items') or [order['body']];index=d.get('line_index');quantity=d.get('quantity');note=str(d.get('note',''))
    if type(index)!=int or not 0<=index<len(items):raise ValueError('商品を選択してください。')
    if type(quantity)!=int or not 0<=quantity<=items[index]['quantity']:raise ValueError('受け渡し数量は注文数量以内で入力してください。')
    if len(note)>2000:raise ValueError('コメントは2000文字以内で入力してください。')
    old=order['deliveries'][index]
    if d.get('revision')!=old['revision']:raise ValueError('受け渡し状況が更新されています。画面を読み直してください。')
    cash=d.get('cash_received',bool(old.get('cash_received',0)))
    if type(cash)!=bool:raise ValueError('現金の受け取り状況を確認してください。')
    for line in order['deliveries']:
        c.execute('INSERT OR IGNORE INTO shop_line_deliveries(order_id,line_index,quantity,note,updated,revision) VALUES(?,?,?,?,?,?)',(order['id'],line['line_index'],line['quantity'],line['note'],line['updated'],line['revision']))
    now=time.strftime('%Y-%m-%d %H:%M:%S')
    c.execute('UPDATE shop_line_deliveries SET quantity=?,note=?,updated=?,cash_received=?,revision=revision+1 WHERE order_id=? AND line_index=?',(quantity,note,now,int(cash),order['id'],index))
    quantities={r['line_index']:r['quantity'] for r in c.execute('SELECT * FROM shop_line_deliveries WHERE order_id=?',(order['id'],))}
    if all(quantities[i]==item['quantity'] for i,item in enumerate(items)):
        c.execute('INSERT OR REPLACE INTO shop_deliveries VALUES(?,?,?)',(order['id'],now,u['id']))
    else:c.execute('DELETE FROM shop_deliveries WHERE order_id=?',(order['id'],))
