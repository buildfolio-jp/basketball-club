"""Attendance-based basketball notebook submission tracking."""
import datetime,uuid,admin_access,accounting,json,note_templates
from attendance_rates import PRESENT

def init(c):
 c.execute('CREATE TABLE IF NOT EXISTS basket_note_states(user_id TEXT,event_id TEXT,status TEXT,PRIMARY KEY(user_id,event_id))')
 c.execute('CREATE TABLE IF NOT EXISTS basket_notes(user_id TEXT,event_id TEXT,body TEXT,submitted INTEGER,updated TEXT,checked_by TEXT,revision TEXT,PRIMARY KEY(user_id,event_id))')
 if 'feedback' not in [r[1] for r in c.execute('PRAGMA table_info(basket_notes)')]:c.execute("ALTER TABLE basket_notes ADD COLUMN feedback TEXT DEFAULT ''")

def group(grade):
 if grade in ('小学1年','小学2年','小学3年','小学1年生','小学2年生','小学3年生'):return '低学年'
 if grade in ('小学4年','小学5年','小学6年','小学4年生','小学5年生','小学6年生'):return '高学年'
 return ''
def staff(u,write=False):return u and (u['role']=='coach' or admin_access.can(u,'basket-notes',write))
def read(c,u):
 own=u and u['role']=='member';available=bool(staff(u) or (own and group(u.get('grade',''))))
 if not available:return {'available':False,'rows':[],'members':[]}
 users=[dict(r) for r in c.execute("SELECT id,name,grade FROM users WHERE role='member'"+(' AND id=?' if own else ''),(u['id'],) if own else ()) if group(r['grade'])]
 rows=[];members=[]
 for m in users:
  rs=[dict(r) for r in c.execute("SELECT r.user_id,r.event_id,e.date,e.title,e.kind,n.body,n.feedback,COALESCE(n.submitted,0) AS submitted,n.revision,n.updated,n.checked_by FROM reports r JOIN events e ON e.id=r.event_id LEFT JOIN basket_notes n ON n.user_id=r.user_id AND n.event_id=r.event_id WHERE r.user_id=? AND e.kind<>'体験会' AND e.date<=? AND r.actual IN ('出席','遅刻','早退','遅刻・早退') ORDER BY e.date DESC",(m['id'],accounting.today().isoformat()))]
  rows += [{**r,'name':m['name'],'group':group(m['grade'])} for r in rs];count=len({r['date'] for r in rs if r['submitted']});days=len({r['date'] for r in rs})
  members.append({**m,'group':group(m['grade']),'attended':days,'submitted':count,'rate':round(count*100/days,1) if days else None})
 states={(r['user_id'],r['event_id']):r['status'] for r in status_rows(c)}
 for row in rows:row['submission_status']=states.get((row['user_id'],row['event_id']),'未提出')
 return {'available':True,'templates':note_templates.read(c),'rows':rows,'members':members}
def save(c,u,d):
 if not u:raise PermissionError('ログインしてください。')
 uid=d.get('user_id');eid=d.get('event_id');own=u['role']=='member'
 if own and uid!=u['id'] or not own and not staff(u,True):raise PermissionError('操作する権限がありません。')
 if not any(r['user_id']==uid and r['event_id']==eid for r in read(c,u)['rows']):raise ValueError('対象の出席記録がありません。')
 old=c.execute('SELECT * FROM basket_notes WHERE user_id=? AND event_id=?',(uid,eid)).fetchone()
 if (old['revision'] if old else None)!=d.get('revision'):raise ValueError('ノートが更新されています。再読み込みしてください。')
 if own:
  level=group(u.get('grade',''));kind=c.execute('SELECT kind FROM events WHERE id=?',(eid,)).fetchone()[0]
  key=('low' if level=='低学年' else 'high')+('-match' if '試合' in kind else '-practice');template=note_templates.read(c)[key]
  if d.get('template_revision')!=template['revision']:raise ValueError('項目が変更されています。開き直してください。')
  answers=d.get('answers')
  if not isinstance(answers,dict):raise ValueError('回答を入力してください。')
  clean={}
  for f in template['fields']:
   value=answers.get(f['id'],'')
   if not isinstance(value,str) or len(value)>3000 or (f['type']=='select' and value and value not in f['options']):raise ValueError(f['label']+'の入力を確認してください。')
   clean[f['id']]=value.strip()
  if not any(clean.values()):raise ValueError('ノートの内容を入力してください。')
  body=json.dumps({'answers':clean,'template':template,'_group':level,'_match':'試合' in kind},ensure_ascii=False)
  c.execute('INSERT OR REPLACE INTO basket_notes VALUES(?,?,?,?,?,?,?,?)',(uid,eid,body,0,accounting.now(),'',uuid.uuid4().hex,old['feedback'] if old else ''))
  c.execute('INSERT OR REPLACE INTO basket_note_states VALUES(?,?,?)',(uid,eid,'未提出'))
  return
 if d.get('action')=='feedback':
  feedback=str(d.get('feedback','')).strip()
  if len(feedback)>3000:raise ValueError('コメントは3000文字以内にしてください。')
  c.execute('INSERT OR REPLACE INTO basket_notes VALUES(?,?,?,?,?,?,?,?)',(uid,eid,old['body'] if old else '',old['submitted'] if old else 0,accounting.now(),u['id'],uuid.uuid4().hex,feedback));return
 if type(d.get('submitted'))is not bool:raise ValueError('提出状態を選択してください。')
 c.execute('INSERT OR REPLACE INTO basket_note_states VALUES(?,?,?)',(uid,eid,'提出' if d['submitted'] else '未提出'))
 c.execute('INSERT OR REPLACE INTO basket_notes VALUES(?,?,?,?,?,?,?,?)',(uid,eid,old['body'] if old else '',int(d['submitted']),accounting.now(),u['id'],uuid.uuid4().hex,old['feedback'] if old else ''))

STATUSES=('提出','未提出','報告有忘','報告無忘','提出未記入')
def status_rows(c):
 return [dict(r) for r in c.execute("SELECT n.user_id,n.event_id,n.revision,COALESCE(s.status,CASE WHEN n.submitted=1 THEN '提出' ELSE '未提出' END) AS status FROM basket_notes n LEFT JOIN basket_note_states s ON s.user_id=n.user_id AND s.event_id=n.event_id")]
def save_status(c,u,d):
 if not u or not (u['role']=='coach' or admin_access.can(u,'attendance-list',True)):raise PermissionError('操作する権限がありません。')
 uid=d.get('user_id');eid=d.get('event_id');status=d.get('status')
 if status not in STATUSES:raise ValueError('提出状況を選択してください。')
 member=c.execute("SELECT * FROM users WHERE id=? AND role='member'",(uid,)).fetchone()
 event=c.execute("SELECT * FROM events WHERE id=? AND kind<>'体験会'",(eid,)).fetchone()
 if not member or not event:raise ValueError('対象の会員・日程がありません。')
 old=c.execute('SELECT * FROM basket_notes WHERE user_id=? AND event_id=?',(uid,eid)).fetchone()
 if (old['revision'] if old else None)!=d.get('revision'):raise ValueError('提出状況が更新されています。最新の状態で選び直してください。')
 c.execute('INSERT OR REPLACE INTO basket_notes VALUES(?,?,?,?,?,?,?,?)',(uid,eid,old['body'] if old else '',int(status in ('提出','提出未記入')),accounting.now(),u['id'],uuid.uuid4().hex,old['feedback'] if old else ''))
 c.execute('INSERT OR REPLACE INTO basket_note_states VALUES(?,?,?)',(uid,eid,status))
