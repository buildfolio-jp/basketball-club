import credentials
"""Approved guardian logins, initial profiles and one-use email password resets."""
import hashlib,json,os,re,secrets,smtplib,ssl,time
from email.message import EmailMessage
from urllib.parse import urlparse
import school_year
GRADES=['年長']+[f'小学{i}年' for i in range(1,7)]+[f'中学{i}年' for i in range(1,4)]

def init(c):
    credentials.init(c)
    c.executescript('''
    CREATE TABLE IF NOT EXISTS guardian_accounts(login_id TEXT PRIMARY KEY,student_id TEXT,player_name TEXT,parent_name TEXT,grade TEXT,email TEXT,hash TEXT,status TEXT,created TEXT,approved_at TEXT,approved_by TEXT);
    CREATE TABLE IF NOT EXISTS account_phones(login_id TEXT PRIMARY KEY,phone TEXT);
    CREATE TABLE IF NOT EXISTS account_profiles(login_id TEXT PRIMARY KEY,parent_name TEXT,email TEXT,setup_at TEXT,reset_at TEXT DEFAULT '');
    CREATE TABLE IF NOT EXISTS account_notifications(login_id TEXT PRIMARY KEY,method TEXT,line_id TEXT,status TEXT DEFAULT 'pending');
    CREATE TABLE IF NOT EXISTS student_only(user_id TEXT PRIMARY KEY);
    CREATE TABLE IF NOT EXISTS member_invites(user_id TEXT PRIMARY KEY,code TEXT UNIQUE);
    CREATE TABLE IF NOT EXISTS member_access(user_id TEXT PRIMARY KEY,approved INTEGER DEFAULT 0);
    CREATE TABLE IF NOT EXISTS deleted_members(user_id TEXT PRIMARY KEY,deleted_at TEXT,deleted_by TEXT);
    CREATE TABLE IF NOT EXISTS account_reset_tokens(token_hash TEXT PRIMARY KEY,login_id TEXT,expires REAL,used INTEGER DEFAULT 0);
    CREATE TABLE IF NOT EXISTS account_rate_limits(scope TEXT,key_hash TEXT,created REAL);
    CREATE TABLE IF NOT EXISTS account_mail_queue(id TEXT PRIMARY KEY,recipient TEXT,subject TEXT,body TEXT,status TEXT,created REAL);
    ''')
def now():return time.strftime('%Y-%m-%d %H:%M:%S')
def email(value):
    value=str(value or '').strip().lower()
    if len(value)>254 or not re.fullmatch(r'[^\s@<>\r\n]+@[^\s@<>\r\n]+\.[^\s@<>\r\n]+',value):raise ValueError('メールアドレスを確認してください。')
    return value

def throttle(c,scope,key,limit,seconds):
    t=time.time();digest=hashlib.sha256(str(key).encode()).hexdigest()
    c.execute('DELETE FROM account_rate_limits WHERE created<?',(t-86400,))
    count=c.execute('SELECT COUNT(*) FROM account_rate_limits WHERE scope=? AND key_hash=? AND created>?',(scope,digest,t-seconds)).fetchone()[0]
    if count>=limit:raise ValueError('時間をおいてから、もう一度お試しください。')
    c.execute('INSERT INTO account_rate_limits VALUES(?,?,?)',(scope,digest,t))

def registration(c,d,hash_password):
    invite=c.execute("SELECT u.* FROM users u JOIN member_invites i ON i.user_id=u.id WHERE i.code=? AND u.role='member' AND u.active=1 AND NOT EXISTS(SELECT 1 FROM deleted_members x WHERE x.user_id=u.id)",(str(d.get('invite_code','')).strip(),)).fetchone()
    if not invite:raise ValueError('登録コードを確認してください。先に管理者による選手登録が必要です。')
    player_key=''.join(str(d.get('player_name') or '').split())
    parent_key=''.join(str(d.get('parent_name') or '').split())
    if player_key and parent_key:
        for existing in c.execute("SELECT player_name,parent_name FROM guardian_accounts WHERE student_id=? AND status IN ('pending','approved')",(invite['id'],)):
            if player_key==''.join(existing['player_name'].split()) and parent_key==''.join(existing['parent_name'].split()):
                raise ValueError('すでに登録済みです。')
    if guardian_count(c,invite['id'])+c.execute("SELECT COUNT(*) FROM guardian_accounts WHERE student_id=? AND status='pending'",(invite['id'],)).fetchone()[0]>=3:raise ValueError('この選手の保護者ログインは申請中を含めて3件までです。')
    notification=d.get('notification','email');line_id=str(d.get('line_id') or '').strip()
    if notification not in ('email','line'):raise ValueError('お知らせ方法を選択してください。')
    if notification=='line' and (not line_id or len(line_id)>100 or any(ch.isspace() for ch in line_id)):raise ValueError('LINE IDを空白なし・100文字以内で入力してください。')
    uid=str(d.get('id','')).strip();name=str(d.get('player_name','')).strip();parent=str(d.get('parent_name','')).strip();grade=d.get('grade');pw=d.get('password','')
    if not re.fullmatch(r'[A-Za-z0-9_-]{3,40}',uid):raise ValueError('IDは3〜40文字の半角英数字・ハイフン・下線にしてください。')
    if not name or not parent or len(name)>100 or len(parent)>100 or grade not in GRADES:raise ValueError('選手名・保護者名・学年を確認してください。')
    if not isinstance(pw,str) or not 8<=len(pw)<=128:raise ValueError('パスワードは8〜128文字にしてください。')
    if pw!=d.get('password_confirm'):raise ValueError('確認用パスワードが一致しません。')
    if credentials.taken(c,uid) or c.execute('SELECT 1 FROM users WHERE id=?',(uid,)).fetchone() or c.execute('SELECT 1 FROM guardian_accounts WHERE login_id=?',(uid,)).fetchone():raise ValueError('このIDは使用できません。別のIDにしてください。')
    if ''.join(name.split())!=''.join(invite['name'].split()):raise ValueError('選手名が登録内容と一致しません。管理者に確認してください。')
    c.execute('INSERT INTO guardian_accounts VALUES(?,?,?,?,?,?,?,?,?,?,?)',(uid,invite['id'],name,parent,grade,email(d.get('email')),hash_password(pw),'pending',now(),'',''))
    save_phone(c,uid,d)
    c.execute('INSERT INTO account_notifications(login_id,method,line_id) VALUES(?,?,?)',(uid,notification,line_id if notification=='line' else ''))
    queue_mail(c,'','CHEETAHS 新規登録申請',f'選手：{name}\n保護者：{parent}\nID：{uid}\n会員一覧で登録内容を確認し、承認してください。')

def direct_login_allowed(c,uid):return not c.execute('SELECT 1 FROM student_only WHERE user_id=?',(uid,)).fetchone()
def identity(c,uid):
    uid=credentials.resolve(c,uid)
    row=c.execute("SELECT student_id FROM guardian_accounts WHERE login_id=? AND status='approved'",(uid,)).fetchone()
    if row:return row[0] if access_allowed(c,row[0]) else None
    return uid if direct_login_allowed(c,uid) and access_allowed(c,uid) else None

def authenticate(c,uid,pw,hash_password):
    requested=uid;uid=credentials.resolve(c,uid)
    if credentials.display(c,uid)!=requested:return False
    row=c.execute("SELECT a.hash,u.id FROM guardian_accounts a JOIN users u ON u.id=a.student_id WHERE a.login_id=? AND a.status='approved' AND u.active=1 AND u.role='member'",(uid,)).fetchone()
    if not row and direct_login_allowed(c,uid):row=c.execute('SELECT hash,id FROM users WHERE id=? AND active=1',(uid,)).fetchone()
    return bool(row and access_allowed(c,row['id']) and secrets.compare_digest(row['hash'],hash_password(pw,row['hash'].split(':')[0])))

def guardian_count(c,student):
    return c.execute("SELECT COUNT(*) FROM guardian_accounts WHERE student_id=? AND status='approved'",(student,)).fetchone()[0]+int(direct_login_allowed(c,student))

def review(c,admin,d,hash_password):
    if admin['role']!='admin':raise ValueError('管理者のみ承認できます。')
    a=c.execute("SELECT * FROM guardian_accounts WHERE login_id=? AND status='pending'",(d.get('login_id'),)).fetchone()
    if not a:raise ValueError('承認待ちの申請を選択してください。')
    if d.get('action')=='reject':c.execute("UPDATE guardian_accounts SET status='rejected',approved_at=?,approved_by=? WHERE login_id=?",(now(),admin['id'],a['login_id']));return
    target=a['student_id']
    student=c.execute("SELECT * FROM users WHERE id=? AND role='member' AND active=1",(target,)).fetchone()
    if not student:raise ValueError('事前登録された在籍選手が見つかりません。')
    if guardian_count(c,target)>=3:raise ValueError('この選手の保護者ログインは既に3件あります。')
    c.execute('INSERT INTO member_access VALUES(?,1) ON CONFLICT(user_id) DO UPDATE SET approved=1',(target,))
    c.execute("UPDATE guardian_accounts SET student_id=?,status='approved',approved_at=?,approved_by=? WHERE login_id=?",(target,now(),admin['id'],a['login_id']))
    c.execute('INSERT OR REPLACE INTO account_profiles VALUES(?,?,?,?,?)',(a['login_id'],a['parent_name'],a['email'],now(),''))
    if notification_info(c,a['login_id'])['notification']=='email':queue_mail(c,a['email'],'CHEETAHS 登録完了',f"{a['parent_name']} 様\n管理者による登録の承認が完了しました。設定したID・パスワードでログインできます。\nID：{a['login_id']}")

def profile(c,uid):
    p=c.execute('SELECT * FROM account_profiles WHERE login_id=?',(uid,)).fetchone()
    phone=c.execute('SELECT phone FROM account_phones WHERE login_id=?',(uid,)).fetchone()
    return {**(dict(p) if p else {'login_id':uid,'parent_name':'','email':'','setup_at':'','reset_at':''}),'phone':phone[0] if phone else ''}

def save_profile(c,uid,d,hash_password):
    if not authenticate(c,credentials.display(c,uid),str(d.get('current_password','')),hash_password):raise ValueError('現在のパスワードを確認してください。')
    address=email(d.get('email'));parent=str(d.get('parent_name','')).strip()
    subject=identity(c,uid);u=c.execute('SELECT role FROM users WHERE id=?',(subject,)).fetchone()
    if u['role']=='member' and not parent:raise ValueError('保護者名を入力してください。')
    if len(parent)>100:raise ValueError('氏名は100文字以内で入力してください。')
    c.execute("INSERT INTO account_profiles VALUES(?,?,?,?,?) ON CONFLICT(login_id) DO UPDATE SET parent_name=excluded.parent_name,email=excluded.email,setup_at=excluded.setup_at",(uid,parent,address,now(),''))
    save_phone(c,uid,d)
    c.execute('UPDATE guardian_accounts SET parent_name=?,email=? WHERE login_id=?',(parent,address,uid))

def notification_info(c,uid):
    r=c.execute('SELECT method,line_id FROM account_notifications WHERE login_id=?',(uid,)).fetchone()
    return {'notification':r['method'] if r else 'email','line_id':r['line_id'] if r else ''}

def admin_read(c):
    pending=[dict(r) for r in c.execute("SELECT login_id,student_id,player_name,parent_name,grade,email,status,created,approved_at FROM guardian_accounts WHERE status='pending' ORDER BY created DESC,login_id")]
    items=[]
    for u in c.execute('SELECT id,name,role FROM users'):
        if direct_login_allowed(c,u['id']):items.append({'student_id':u['id'],'player_name':u['name'],'role':u['role'],'status':'approved',**profile(c,u['id'])})
    for a in c.execute("SELECT login_id,student_id,player_name,parent_name,email,status FROM guardian_accounts WHERE status='approved'"):
        items.append({**dict(a),'role':'member',**profile(c,a['login_id']),'parent_name':profile(c,a['login_id'])['parent_name'] or a['parent_name']})
    for item in pending+items:item.update(notification_info(c,item['login_id']));item['login_display']=credentials.display(c,item['login_id'])
    return {'pending':pending,'items':items,'mail_ready':mail_ready(),'admin_mail_ready':bool(mail_ready() and os.environ.get('CHEETAHS_ADMIN_MAIL')),'queued_notifications':c.execute("SELECT COUNT(*) FROM account_mail_queue WHERE status='pending'").fetchone()[0],'invites':{r['user_id']:r['code'] for r in c.execute('SELECT * FROM member_invites')},'access':{r['user_id']:bool(r['approved']) for r in c.execute('SELECT * FROM member_access')}}

def mail_ready():
    origin=os.environ.get('CHEETAHS_PUBLIC_ORIGIN','')
    return bool(os.environ.get('CHEETAHS_SMTP_HOST') and os.environ.get('CHEETAHS_MAIL_FROM') and origin.startswith('https://'))

def send_mail(recipient,subject,body):
    if not mail_ready():raise ValueError('メール送信の準備中です。管理者へお問い合わせください。')
    msg=EmailMessage();msg['From']=os.environ['CHEETAHS_MAIL_FROM'];msg['To']=recipient;msg['Subject']=subject;msg.set_content(body)
    host=os.environ['CHEETAHS_SMTP_HOST'];port=int(os.environ.get('CHEETAHS_SMTP_PORT','465'));context=ssl.create_default_context()
    cls=smtplib.SMTP_SSL if port==465 else smtplib.SMTP
    kwargs={'context':context} if port==465 else {}
    with cls(host,port,timeout=15,**kwargs) as smtp:
        if port!=465:smtp.starttls(context=context)
        if os.environ.get('CHEETAHS_SMTP_USER'):smtp.login(os.environ['CHEETAHS_SMTP_USER'],os.environ.get('CHEETAHS_SMTP_PASSWORD',''))
        smtp.send_message(msg)

def request_reset(c,d):
    if not mail_ready():raise ValueError('メール送信の準備中です。管理者へお問い合わせください。')
    uid=credentials.resolve(c,str(d.get('id','')).strip());address=email(d.get('email'))
    throttle(c,'reset-id',uid,3,900)
    p=c.execute('SELECT email FROM account_profiles WHERE login_id=?',(uid,)).fetchone();subject=identity(c,uid)
    if not p or p['email']!=address or not c.execute('SELECT 1 FROM users WHERE id=? AND active=1',(subject,)).fetchone():return
    token=secrets.token_urlsafe(32)
    c.execute('DELETE FROM account_reset_tokens WHERE login_id=? OR expires<?',(uid,time.time()))
    c.execute('INSERT INTO account_reset_tokens VALUES(?,?,?,0)',(hashlib.sha256(token.encode()).hexdigest(),uid,time.time()+1800))
    link=os.environ['CHEETAHS_PUBLIC_ORIGIN'].rstrip('/')+'/#password-reset?token='+token
    send_mail(address,'CHEETAHS パスワード再設定',f'次のリンクから新しいパスワードを設定してください。30分間有効です。\n{link}\n\n心当たりがない場合は、このメールを破棄してください。')

def reset_password(c,d,hash_password):
    token=str(d.get('token',''));digest=hashlib.sha256(token.encode()).hexdigest()
    r=c.execute('SELECT * FROM account_reset_tokens WHERE token_hash=? AND used=0 AND expires>?',(digest,time.time())).fetchone()
    if not r:raise ValueError('リンクが無効か、有効期限が切れています。再設定メールをもう一度申請してください。')
    pw=d.get('password','')
    if not isinstance(pw,str) or not 8<=len(pw)<=128 or pw!=d.get('password_confirm'):raise ValueError('8〜128文字で同じパスワードを2回入力してください。')
    uid=r['login_id'];subject=identity(c,uid)
    if not c.execute('SELECT 1 FROM users WHERE id=? AND active=1',(subject,)).fetchone():raise ValueError('このアカウントは利用できません。')
    guardian=c.execute("SELECT 1 FROM guardian_accounts WHERE login_id=? AND status='approved'",(uid,)).fetchone()
    c.execute('UPDATE '+('guardian_accounts SET hash=? WHERE login_id=?' if guardian else 'users SET hash=? WHERE id=?'),(hash_password(pw),uid))
    c.execute('UPDATE account_reset_tokens SET used=1 WHERE login_id=?',(uid,));c.execute('DELETE FROM login_sessions WHERE user_id=?',(uid,))
    c.execute('UPDATE account_profiles SET reset_at=? WHERE login_id=?',(now(),uid))
    address=profile(c,uid)['email']
    c.execute('INSERT INTO account_mail_queue VALUES(?,?,?,?,?,?)',(secrets.token_hex(16),address,'CHEETAHS パスワード再設定完了','パスワードの再設定が完了しました。\n心当たりがない場合は、クラブ管理者へご連絡ください。','pending',time.time()))
    return uid

def flush_mail(c):
    if not mail_ready():return
    for r in c.execute("SELECT * FROM account_mail_queue WHERE status='pending' ORDER BY created LIMIT 5").fetchall():
        recipient=r['recipient'] or os.environ.get('CHEETAHS_ADMIN_MAIL','')
        if not recipient:continue
        try:send_mail(recipient,r['subject'],r['body'])
        except Exception:continue
        c.execute("UPDATE account_mail_queue SET status='sent',body='' WHERE id=?",(r['id'],))

def access_allowed(c,uid):
    import enrollment
    if enrollment.read(c,uid)['status']=='退会':return False
    if c.execute('SELECT 1 FROM deleted_members WHERE user_id=?',(uid,)).fetchone():return False
    row=c.execute('SELECT approved FROM member_access WHERE user_id=?',(uid,)).fetchone()
    return not row or bool(row[0])

def ensure_invites(c):
    for r in c.execute("SELECT id FROM users WHERE role='member' AND active=1 AND NOT EXISTS(SELECT 1 FROM deleted_members d WHERE d.user_id=users.id)").fetchall():
        if not c.execute('SELECT 1 FROM member_invites WHERE user_id=?',(r['id'],)).fetchone():c.execute('INSERT INTO member_invites VALUES(?,?)',(r['id'],secrets.token_urlsafe(18)))

def queue_mail(c,recipient,subject,body):
    c.execute('INSERT INTO account_mail_queue VALUES(?,?,?,?,?,?)',(secrets.token_hex(16),recipient,subject,body,'pending',time.time()))

def member_approval(c,actor,d,hash_password):
    if actor['role']!='admin':raise ValueError('管理者のみ操作できます。')
    uid=d.get('user_id');member=c.execute("SELECT * FROM users WHERE id=? AND role='member' AND active=1",(uid,)).fetchone()
    if not member or type(d.get('approved')) is not bool:raise ValueError('在籍会員を選択してください。')
    if d['approved']:
        for r in c.execute("SELECT login_id FROM guardian_accounts WHERE student_id=? AND status='pending'",(uid,)).fetchall():review(c,actor,{'login_id':r['login_id'],'action':'approve'},hash_password)
    c.execute('INSERT INTO member_access VALUES(?,?) ON CONFLICT(user_id) DO UPDATE SET approved=excluded.approved',(uid,int(d['approved'])))
    if not d['approved']:
        c.execute('DELETE FROM login_sessions WHERE user_id=? OR user_id IN (SELECT login_id FROM guardian_accounts WHERE student_id=?)',(uid,uid))

def remove_member(c,actor,d):
    if actor['role']!='admin':raise ValueError('管理者のみ操作できます。')
    uid=d.get('user_id');member=c.execute("SELECT * FROM users WHERE id=? AND role='member'",(uid,)).fetchone()
    if not member:raise ValueError('会員を選択してください。')
    c.execute('UPDATE users SET active=0 WHERE id=?',(uid,))
    c.execute('INSERT OR REPLACE INTO deleted_members VALUES(?,?,?)',(uid,now(),actor['id']))
    c.execute('DELETE FROM member_invites WHERE user_id=?',(uid,))
    c.execute('DELETE FROM login_sessions WHERE user_id=? OR user_id IN (SELECT login_id FROM guardian_accounts WHERE student_id=?)',(uid,uid))

def remove_guardian(c,actor,d):
    if actor['role']!='admin':raise ValueError('管理者のみ操作できます。')
    uid=d.get('login_id');student=d.get('user_id')
    member=c.execute("SELECT id FROM users WHERE id=? AND role='member'",(student,)).fetchone()
    if not member:raise ValueError('対象の会員を確認してください。')
    guardian=c.execute('SELECT login_id FROM guardian_accounts WHERE login_id=? AND student_id=?',(uid,student)).fetchone()
    if guardian:
        c.execute('DELETE FROM guardian_accounts WHERE login_id=?',(uid,))
    elif uid==student and direct_login_allowed(c,uid):
        c.execute('INSERT INTO student_only VALUES(?)',(uid,))
    else:raise ValueError('対象の保護者が見つかりません。')
    c.execute('DELETE FROM account_profiles WHERE login_id=?',(uid,))
    c.execute('DELETE FROM account_notifications WHERE login_id=?',(uid,))
    c.execute('DELETE FROM account_reset_tokens WHERE login_id=?',(uid,))
    c.execute('DELETE FROM login_sessions WHERE user_id=?',(uid,))

def update_guardian(c,actor,d):
    if actor['role']!='admin':raise ValueError('管理者のみ操作できます。')
    uid=d.get('login_id');student=d.get('user_id')
    member=c.execute("SELECT id FROM users WHERE id=? AND role='member'",(student,)).fetchone()
    guardian=c.execute("SELECT login_id FROM guardian_accounts WHERE login_id=? AND student_id=? AND status IN ('pending','approved')",(uid,student)).fetchone()
    if not member or not (guardian or (uid==student and direct_login_allowed(c,uid))):raise ValueError('対象の保護者が見つかりません。')
    parent=str(d.get('parent_name') or '').strip();address=email(d.get('email'))
    if not parent or len(parent)>100:raise ValueError('保護者名を100文字以内で入力してください。')
    for r in c.execute("SELECT parent_name FROM guardian_accounts WHERE student_id=? AND login_id!=? AND status IN ('pending','approved')",(student,uid)):
        if ''.join(parent.split())==''.join(r['parent_name'].split()):raise ValueError('同じ保護者名がすでに登録されています。')
    c.execute("INSERT INTO account_profiles VALUES(?,?,?,?,?) ON CONFLICT(login_id) DO UPDATE SET parent_name=excluded.parent_name,email=excluded.email,setup_at=excluded.setup_at",(uid,parent,address,now(),''))
    save_phone(c,uid,d)
    c.execute('UPDATE guardian_accounts SET parent_name=?,email=? WHERE login_id=?',(parent,address,uid))

def remove_staff(c,actor,d):
    import admin_access
    if not admin_access.full(actor):raise PermissionError('管理者のみ削除できます。')
    uid=d.get('user_id')
    if uid in ('admin01',actor['id']):raise ValueError('この管理者は削除できません。')
    if not c.execute("SELECT 1 FROM users WHERE id=? AND role IN ('coach','admin')",(uid,)).fetchone():raise ValueError('スタッフを選択してください。')
    c.execute('UPDATE users SET active=0 WHERE id=?',(uid,))
    c.execute('INSERT OR REPLACE INTO deleted_members VALUES(?,?,?)',(uid,now(),actor['id']))
    c.execute('DELETE FROM login_sessions WHERE user_id=?',(uid,))
    c.execute('DELETE FROM coach_registration WHERE user_id=?',(uid,))
    c.execute('UPDATE staff_intros SET published=0 WHERE staff_id=?',(uid,))
    c.execute('DELETE FROM account_reset_tokens WHERE login_id=?',(uid,))


def save_phone(c,uid,d):
    if 'phone' not in d:return
    import unicodedata
    value=re.sub(r'[\s()（）-]','',unicodedata.normalize('NFKC',str(d.get('phone') or '')))
    if value and not re.fullmatch(r'(?:0[0-9]{9,10}|\+[1-9][0-9]{7,14})',value):raise ValueError('電話番号は市外局番から入力してください。')
    c.execute('INSERT OR REPLACE INTO account_phones VALUES(?,?)',(uid,value))

def guardian_contacts(c,students):
    result={}
    for student in students:
        if student['role']!='member':continue
        uid=student['id'];items=[]
        if direct_login_allowed(c,uid):
            p=profile(c,uid);items.append({'name':p['parent_name'] or '保護者','phone':p['phone']})
        for g in c.execute("SELECT login_id,parent_name FROM guardian_accounts WHERE student_id=? AND status='approved' ORDER BY created,login_id",(uid,)):
            p=profile(c,g['login_id']);items.append({'name':p['parent_name'] or g['parent_name'] or '保護者','phone':p['phone']})
        result[uid]=items
    return result
