"""Run the existing request handlers entirely inside the browser worker."""
import io,json,base64,os
from email.message import Message
from pathlib import Path
import server
os.environ['CHEETAHS_PUBLIC_ORIGIN']='https://browser-demo.invalid'
os.environ['CHEETAHS_DEMO_REGISTRATION']='1'
# Never configure real mail/LINE credentials in this static demo.
for key in list(os.environ):
 if 'TOKEN' in key or 'SMTP' in key or 'MAIL' in key:os.environ.pop(key,None)
server.init()
server.export_excel()
_cookie=''
def set_cookie(value):
 global _cookie
 _cookie=value
def get_cookie():return _cookie
def request(raw):
 global _cookie
 req=json.loads(raw);h=server.Handler.__new__(server.Handler)
 h.command=req.get('method','GET');h.path=req['path'];h.request_version='HTTP/1.1';h.client_address=('127.0.0.1',0)
 h.headers=Message()
 for k,v in req.get('headers',{}).items():
  if k.lower() not in ('host','origin','cookie','content-length'):h.headers[k]=v
 h.headers['Host']='browser-demo.invalid';h.headers['Origin']='https://browser-demo.invalid';h.headers['Cookie']=_cookie
 body=req.get('body','').replace('/basketball-club/uploads/','/uploads/').replace('/basketball-club/staff-photo','/staff-photo').encode();h.headers['Content-Length']=str(len(body));h.rfile=io.BytesIO(body);h.wfile=io.BytesIO()
 response={'status':200,'headers':{}}
 h.send_response=lambda code,message=None:response.update(status=code)
 h.send_header=lambda k,v:response['headers'].update({k:v})
 h.end_headers=lambda:None
 h.log_message=lambda *args:None
 try:
  if h.command=='GET':h.do_GET()
  elif h.command=='POST':h.do_POST()
  else:h.send({'error':'対応していない操作です。'},405)
 except Exception as e:
  import traceback
  traceback.print_exc()
  h.wfile=io.BytesIO();h.send({'error':'デモ処理に失敗しました：'+str(e)},500)
 if 'Set-Cookie' in response['headers']:
  _cookie=response['headers'].pop('Set-Cookie').split(';')[0]
 payload=h.wfile.getvalue()
 if 'application/json' in response['headers'].get('Content-Type',''):
  def urls(value):
   if isinstance(value,dict):return {k:urls(v) for k,v in value.items()}
   if isinstance(value,list):return [urls(v) for v in value]
   if isinstance(value,str) and value.startswith(('/uploads/','/staff-photo','/api/')):return '/basketball-club'+value
   return value
  payload=json.dumps(urls(json.loads(payload)),ensure_ascii=False).encode()
 response['body']=base64.b64encode(payload).decode()
 return json.dumps(response)
