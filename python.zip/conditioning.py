# coding: utf-8
import csv,io,json,hashlib,time
from pathlib import Path
import accounting,admin_access,report_templates
HEADERS=['会員ID','会員名','日程ID','日付','日程','学年','体の調子','心の調子','朝ご飯','調子の悪いところ','当日の連絡事項']
FIELDS=['body_condition','mind_condition','breakfast','unwell_area','note']
def init(c):c.execute('CREATE TABLE IF NOT EXISTS conditioning_import_rows(user_id TEXT,event_id TEXT,digest TEXT,PRIMARY KEY(user_id,event_id))')
def allowed(u):return u and (u['role']=='coach' or (admin_access.can(u,'conditioning') or admin_access.can(u,'attendance-list')))
def read(c,uid='',day=''):
 rows=[dict(r) for r in c.execute("SELECT r.*,u.name,u.grade,e.date,e.title FROM reports r JOIN users u ON u.id=r.user_id JOIN events e ON e.id=r.event_id WHERE u.role='member' AND (COALESCE(r.body_condition,'')<>'' OR r.condition IS NOT NULL) ORDER BY e.date DESC,r.updated DESC,u.name")]
 return [r for r in rows if (not uid or r['user_id']==uid) and (not day or r['date']==day)]
def csv_bytes(rows):
 out=io.StringIO();w=csv.writer(out);w.writerow(HEADERS)
 for r in rows:
  cells=[r['user_id'],r['name'],r['event_id'],r['date'],r['title'],r['grade']]+[r.get(k) or '' for k in FIELDS]
  w.writerow([("'"+str(x)) if str(x).lstrip().startswith(('=','+','-','@')) else x for x in cells])
 return ('\ufeff'+out.getvalue()).encode('utf-8')
def pdf_bytes(rows):
 lines=['SHINING CHEETAHS コンディショニングシート',f'体調報告 {len(rows)}件','']
 for r in rows:lines += [f"{r['date']}　{r['name']} ／ {r['grade']}　{r['title']}",f"体：{r['body_condition'] or '旧形式'}　心：{r['mind_condition'] or '未報告'}　朝食：{r['breakfast'] or '未報告'}",'調子の悪いところ：'+(r['unwell_area'] or '—'),'連絡事項：'+(r['note'] or '—'),'']
 return accounting.pdf_bytes({},lines)
def ensure_template(path):
 path=Path(path)
 if not path.exists():path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(csv_bytes([]))
def status(c):
 r=c.execute("SELECT value FROM meta WHERE key='conditioning_import'").fetchone();return json.loads(r[0]) if r else {'message':'入力待ち','ok':True}
def sync(c,path):
 ensure_template(path);raw=Path(path).read_bytes();digest=hashlib.sha256(raw).hexdigest();previous=status(c)
 if previous.get('digest')==digest:return False
 result={'digest':digest,'updated':time.strftime('%Y-%m-%d %H:%M:%S')}
 try:
  if len(raw)>5*1024*1024:raise ValueError('入力CSVは5MB以下にしてください。')
  try:text=raw.decode('utf-8-sig')
  except UnicodeDecodeError:text=raw.decode('shift_jis')
  rows=list(csv.DictReader(io.StringIO(text)));changes=[];seen=set()
  if len(rows)>10000:raise ValueError('入力CSVは10000件以下にしてください。')
  for i,row in enumerate(rows,2):
   if not any(row.values()):continue
   uid=row.get('会員ID','').strip();eid=row.get('日程ID','').strip()
   if not uid or not eid:raise ValueError(f'{i}行目：会員IDと日程IDを入力してください。')
   if (uid,eid) in seen:raise ValueError(f'{i}行目：同じ会員・日程が重複しています。')
   seen.add((uid,eid))
   if not c.execute("SELECT 1 FROM users WHERE id=? AND role='member'",(uid,)).fetchone() or not c.execute('SELECT 1 FROM events WHERE id=?',(eid,)).fetchone():raise ValueError(f'{i}行目：会員IDまたは日程IDが見つかりません。')
   values=[str(row.get(k) or '').strip() for k in HEADERS[6:]]
   if any(values[j] not in q['options'] for j,q in enumerate(report_templates.read(c,'condition')['questions'][:3])):raise ValueError(f'{i}行目：体・心・朝ご飯の選択肢を確認してください。')
   if len(values[3])>2000 or len(values[4])>2000:raise ValueError(f'{i}行目：連絡事項は2000文字以内にしてください。')
   d=hashlib.sha256(json.dumps(values,ensure_ascii=False).encode()).hexdigest();last=c.execute('SELECT digest FROM conditioning_import_rows WHERE user_id=? AND event_id=?',(uid,eid)).fetchone()
   if not last or last[0]!=d:changes.append((uid,eid,values,d))
  for uid,eid,values,d in changes:
   c.execute('INSERT INTO reports(user_id,event_id,body_condition,mind_condition,breakfast,unwell_area,note,updated) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(user_id,event_id) DO UPDATE SET body_condition=excluded.body_condition,mind_condition=excluded.mind_condition,breakfast=excluded.breakfast,unwell_area=excluded.unwell_area,note=excluded.note,updated=excluded.updated',[uid,eid]+values+[result['updated']])
   c.execute('UPDATE reports SET condition_updated=? WHERE user_id=? AND event_id=?',(result['updated'],uid,eid))
   c.execute('INSERT OR REPLACE INTO conditioning_import_rows VALUES(?,?,?)',(uid,eid,d))
  result.update(ok=True,message=f'{len(changes)}件を反映しました。');changed=bool(changes)
 except (ValueError,UnicodeError,csv.Error) as e:result.update(ok=False,message=str(e));changed=False
 c.execute("INSERT OR REPLACE INTO meta VALUES('conditioning_import',?)",(json.dumps(result,ensure_ascii=False),));return changed
