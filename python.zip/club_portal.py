import payment_methods
"""Persistent demo member services. No real payments are processed."""
import json,base64
import surveys
import family_payments
import secrets
import time

KINDS=('announcements','surveys','payments','shop','documents')

def init(c):
    family_payments.init(c)
    c.execute("CREATE TABLE IF NOT EXISTS announcement_files(id TEXT PRIMARY KEY,entry_id TEXT,name TEXT,mime TEXT,content BLOB)")
    c.execute("CREATE TABLE IF NOT EXISTS board_files(id TEXT PRIMARY KEY,entry_id TEXT,name TEXT,mime TEXT,content BLOB)")
    c.execute('CREATE TABLE IF NOT EXISTS portal_items(id TEXT PRIMARY KEY,kind TEXT,title TEXT,body TEXT,amount INTEGER)')
    c.execute('CREATE TABLE IF NOT EXISTS portal_entries(id TEXT PRIMARY KEY,kind TEXT,user_id TEXT,item_id TEXT,body TEXT,status TEXT,created TEXT)')
    c.execute('CREATE TABLE IF NOT EXISTS billing_setting_history(id TEXT PRIMARY KEY,cycle TEXT,updated_by TEXT,updated TEXT)')
    if not c.execute("SELECT 1 FROM meta WHERE key='board_policy_topics_v1'").fetchone():
        author=c.execute("SELECT id FROM users WHERE role='admin' AND active=1 ORDER BY id LIMIT 1").fetchone()
        if author:
            for rid,title in [('board-youtube-policy','YouTubeの運用規定'),('board-closure-policy','閉鎖措置の対応'),('board-weather-policy','警報対応')]:
                c.execute('INSERT OR IGNORE INTO portal_entries VALUES(?,?,?,?,?,?,?)',(rid,'board',author[0],'',title+'\n\n内容準備中。クラブからの正式な案内をお待ちください。','公開中',time.strftime('%Y-%m-%d %H:%M:%S')))
            c.execute("INSERT INTO meta VALUES('board_policy_topics_v1','1')")
    c.execute('INSERT OR IGNORE INTO meta VALUES(?,?)',('billing_settings',json.dumps({'cycle':'半年払い','updated_by':'','updated':''},ensure_ascii=False)))
    if not c.execute("SELECT 1 FROM meta WHERE key='portal_seed'").fetchone():
        for row in [('notice-demo','announcements','9月からのチーム編成について','9月から、チーム編成を変更します。\n\nAチーム・Bチームの2つのグループに分かれて活動します。それぞれの選手に必要な練習を行い、一人ひとりの成長につなげるためのグループ分けです。\n\nこれに伴い、カレンダー上のカテゴリー表記は「男子A」「男子B」に変更となります。練習・試合日程を確認する際は、お子さまが所属するカテゴリーをご確認ください。',0),('fee-demo','payments','デモ月謝','操作確認用のサンプル金額です。実際の月謝ではありません。',5000),('shirt-demo','shop','チームTシャツ（デモ）','サイズと希望数量を入力して注文を試せます。実際の注文・決済は発生しません。',2500),('document-demo','documents','提出書類の連絡（デモ）','書類の提出状況や確認事項を文章で連絡できます。ファイル添付は未対応です。',0)]:
            c.execute('INSERT INTO portal_items VALUES(?,?,?,?,?)',row)
        c.execute("INSERT INTO meta VALUES('portal_seed','1')")
    c.execute("INSERT OR IGNORE INTO portal_entries VALUES(?,?,?,?,?,?,?)",('board-guide-demo','board','coach01','','【サンプル】練習時の持ち物・送迎について\n\nいつもチーム活動へのご協力ありがとうございます。\n練習に参加する前に、次の内容をご確認ください。\n\n■ 持ち物\nバスケットシューズ、飲み物、タオル、着替えをご準備ください。持ち物には名前を書き、練習後は忘れ物がないか確認しましょう。\n\n■ 送迎について\n体育館の入口付近では、車や自転車に十分注意してください。送迎時は通路をふさがず、会場ごとの駐車ルールに従ってください。\n\n■ 練習前のお願い\n出欠予定と体調報告の入力をお願いします。遅刻・早退や個別のご相談は、出欠報告または「諸連絡」からお知らせください。\n\n※これは掲示板の表示確認用のサンプルです。実際の活動案内ではありません。','公開中',time.strftime('%Y-%m-%d %H:%M:%S')))

def billing_settings(c):
    return json.loads(c.execute("SELECT value FROM meta WHERE key='billing_settings'").fetchone()[0])

def billing_export(c):
    prefs={}
    for r in c.execute("SELECT * FROM portal_entries WHERE kind='payment_preferences' ORDER BY created,rowid"):
        value=json.loads(r['body']);prefs[r['user_id']]={'method':value.get('method',''),'registered':r['created']}
    return {'settings':billing_settings(c),'preferences':prefs,'history':[dict(r) for r in c.execute('SELECT h.*,u.name AS updater_name FROM billing_setting_history h LEFT JOIN users u ON h.updated_by=u.id ORDER BY h.rowid')]}

def read(c,u):
    staff=u['role']!='member'
    return {'announcement_files':[dict(r) for r in c.execute("SELECT f.id,f.entry_id,f.name,f.mime FROM announcement_files f JOIN portal_items p ON p.id=f.entry_id WHERE p.kind='announcements'")],'files':[dict(r) for r in c.execute("SELECT f.id,f.entry_id,f.name,f.mime FROM board_files f JOIN portal_entries e ON e.id=f.entry_id JOIN users u ON u.id=e.user_id WHERE e.kind='board' AND u.role IN ('coach','admin')")],'billing_settings':billing_settings(c),'items':[dict(r) for r in c.execute('SELECT * FROM portal_items ORDER BY rowid DESC')],
            'entries':[dict(r) for r in c.execute('SELECT e.*,u.name,u.role AS author_role FROM portal_entries e JOIN users u ON u.id=e.user_id'+('' if staff else " WHERE e.user_id=? OR e.kind='board'")+' ORDER BY e.created DESC,e.rowid DESC',() if staff else (u['id'],)) if r['kind']!='board' or r['author_role'] in ('coach','admin')]}

def mutate(c,u,d):
    staff=u['role']!='member'
    action=d.get('action','submit')
    if action=='billing_settings':
        if u['role']!='admin': raise ValueError('管理者権限が必要です。')
        cycle=d.get('cycle')
        if cycle not in ('毎月払い','半年払い','年払い'): raise ValueError('支払い期間を選んでください。')
        now=time.strftime('%Y-%m-%d %H:%M:%S')
        start=d.get('start_month') or billing_settings(c).get('start_month') or time.strftime('%Y-%m')
        family_payments.period({'cycle':cycle,'start_month':start})
        c.execute('UPDATE meta SET value=? WHERE key=?',(json.dumps({'cycle':cycle,'start_month':start,'updated_by':u['id'],'updated':now},ensure_ascii=False),'billing_settings'))
        c.execute('INSERT INTO billing_setting_history VALUES(?,?,?,?)',(secrets.token_hex(8),cycle,u['id'],now))
    elif action=='payment_preferences':
        family_payments.set_method(c,u,d)
        if 'cycle' in d: raise ValueError('支払い期間は管理者が設定します。画面を再読み込みしてください。')
        method=d.get('method')
        if not payment_methods.valid(method): raise ValueError('支払い方法を選んでください。')
        c.execute("DELETE FROM portal_entries WHERE user_id=? AND kind='payment_preferences'",(u['id'],))
        c.execute('INSERT INTO portal_entries VALUES(?,?,?,?,?,?,?)',(secrets.token_hex(8),'payment_preferences',u['id'],'',json.dumps({'method':method},ensure_ascii=False),'希望保存済み',time.strftime('%Y-%m-%d %H:%M:%S')))
    elif action in ('board_item','board_delete'):
        if not staff:raise ValueError('スタッフ権限が必要です。')
        rid=d.get('id') or secrets.token_hex(8)
        old=c.execute("SELECT * FROM portal_entries WHERE id=? AND kind='board'",(rid,)).fetchone()
        if d.get('id') and not old:raise ValueError('投稿が見つかりません。')
        if action=='board_delete':
            c.execute('DELETE FROM board_files WHERE entry_id=?',(rid,))
            c.execute("DELETE FROM portal_entries WHERE id=? AND kind='board'",(rid,))
            return
        body=str(d.get('body','')).strip()
        if kind=='surveys' and any(f['item_id']==item_id and f['kind']=='camp' for f in surveys.forms(c)):
            body=surveys.camp_body(c,u,item_id,d)
        if not body or len(body)>4000:raise ValueError('本文は1〜4000文字で入力してください。')
        keep=d.get('keep_files',[]);uploads=d.get('uploads',[])
        valid={r[0] for r in c.execute('SELECT id FROM board_files WHERE entry_id=?',(rid,))}
        if not isinstance(keep,list) or not isinstance(uploads,list) or any(k not in valid for k in keep) or len(keep)+len(uploads)>30:raise ValueError('添付は合計30件までです。')
        for fid in valid-set(keep):c.execute('DELETE FROM board_files WHERE id=?',(fid,))
        save_board_files(c,rid,uploads)
        c.execute('DELETE FROM announcement_reads WHERE item_id=?',('board:'+rid,))
        c.execute('INSERT INTO portal_entries VALUES(?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET body=excluded.body,created=excluded.created',(rid,'board',u['id'],'',body,'公開中',time.strftime('%Y-%m-%d %H:%M:%S')))
    elif action=='item':
        if not staff: raise ValueError('スタッフ権限が必要です。')
        kind=d.get('kind');title=str(d.get('title','')).strip();amount=int(d.get('amount') or 0)
        if kind not in KINDS or not title or not 0<=amount<=1000000: raise ValueError('掲載内容を確認してください。')
        rid=d.get('id') or secrets.token_hex(8)
        if kind=='surveys' and 'survey_type' in d:surveys.configure(c,rid,d)
        if kind=='announcements' and ('uploads' in d or 'keep_files' in d):
            keep=d.get('keep_files',[]);uploads=d.get('uploads',[])
            valid={r[0] for r in c.execute('SELECT id FROM announcement_files WHERE entry_id=?',(rid,))}
            if not isinstance(keep,list) or not isinstance(uploads,list) or any(k not in valid for k in keep) or len(keep)+len(uploads)>30:raise ValueError('添付は合計30件までです。')
            for fid in valid-set(keep):c.execute('DELETE FROM announcement_files WHERE id=?',(fid,))
            save_board_files(c,rid,uploads,'announcement_files')
        c.execute('INSERT INTO portal_items VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET title=excluded.title,body=excluded.body,amount=excluded.amount',(rid,kind,title[:120],str(d.get('body',''))[:4000],amount))
    elif action=='delete':
        if not staff: raise ValueError('スタッフ権限が必要です。')
        c.execute('DELETE FROM announcement_files WHERE entry_id=?',(d.get('id'),))
        c.execute('DELETE FROM portal_items WHERE id=?',(d.get('id'),))
    elif action=='review':
        if not staff: raise ValueError('スタッフ権限が必要です。')
        reviewed=d.get('reviewed',True)
        if type(reviewed) is not bool:raise ValueError('確認状況を選択してください。')
        c.execute("UPDATE portal_entries SET status=? WHERE id=?",('確認済み' if reviewed else '未確認',d.get('id')))
    else:
        kind=d.get('kind');body=str(d.get('body','')).strip();item_id=d.get('item_id','')
        if kind not in ('surveys','payments','shop','documents','messages','board','injuries'): raise ValueError('項目が不正です。')
        if kind=='board' and not staff:raise ValueError('掲示板は管理者・コーチのみ投稿できます。')
        if kind=='messages' and u['role']=='member':
            message_type=d.get('message_type')
            if message_type not in ('欠席連絡','早退連絡','遅刻連絡'):raise ValueError('連絡の種類を選択してください。')
            if not body:raise ValueError('連絡内容を入力してください。')
            body='【'+message_type+'】\n'+body
        if kind=='surveys' and any(f['item_id']==item_id and f['kind']=='camp' for f in surveys.forms(c)):
            body=surveys.camp_body(c,u,item_id,d)
        if not body or len(body)>4000: raise ValueError('内容を1〜4000文字で入力してください。')
        if kind in ('surveys','payments','shop','documents'):
            item=c.execute('SELECT * FROM portal_items WHERE id=? AND kind=?',(item_id,kind)).fetchone()
            if not item: raise ValueError('掲載内容が見つかりません。')
            if kind=='surveys':surveys.check_deadline(c,item_id)
            if kind=='surveys' and any(f['item_id']==item_id and f['kind']=='lunch' for f in surveys.forms(c)):raise ValueError('お弁当専用の回答フォームを使用してください。')
            body=item['title']+'\n'+body
            if kind in ('payments','shop'): body+='\nサンプル単価：'+str(item['amount'])+'円（実決済なし）'
        if kind in ('payments','surveys'):
            c.execute('DELETE FROM portal_entries WHERE user_id=? AND kind=? AND item_id=?',(u['id'],kind,item_id))
        entry_id=secrets.token_hex(8)
        if kind=='board':save_board_files(c,entry_id,d.get('uploads',[]))
        c.execute('INSERT INTO portal_entries VALUES(?,?,?,?,?,?,?)',(entry_id,kind,u['id'],item_id,body,'デモ支払済み' if kind=='payments' else '公開中' if kind=='board' else '未確認',time.strftime('%Y-%m-%d %H:%M:%S')))


def save_board_files(c,entry_id,uploads,table="board_files"):
    if table not in ("board_files","announcement_files"):raise ValueError("Invalid attachment table")
    if not isinstance(uploads,list) or len(uploads)>30:raise ValueError('添付は30件までです。')
    for upload in uploads:
        if not isinstance(upload,dict):raise ValueError('添付を確認してください。')
        try:raw=base64.b64decode(upload.get('content',''),validate=True)
        except Exception:raise ValueError('添付を読み込めません。')
        if not 0<len(raw)<=5*1024*1024:raise ValueError('添付は1件5MB以下にしてください。')
        name=str(upload.get('name','添付ファイル'))[:150]
        if raw.startswith(b'%PDF-') and b'%%EOF' in raw[-2048:]:mime='application/pdf'
        elif raw.startswith(bytes.fromhex('ffd8ff')):mime='image/jpeg'
        elif raw.startswith(bytes.fromhex('89504e470d0a1a0a')):mime='image/png'
        elif raw.startswith(b'RIFF') and raw[8:12]==b'WEBP':mime='image/webp'
        elif name.lower().endswith('.csv') and b'\x00' not in raw:
            try:raw.decode('utf-8-sig')
            except UnicodeDecodeError:
                try:raw.decode('cp932')
                except UnicodeDecodeError:raise ValueError('CSVはUTF-8またはShift-JISで保存してください。')
            mime='text/csv'
        else:raise ValueError('写真（JPG・PNG・WebP）・PDF・CSVを選択してください。')
        c.execute('INSERT INTO '+table+' VALUES(?,?,?,?,?)',(secrets.token_hex(16),entry_id,name,mime,raw))
