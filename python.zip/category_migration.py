"""Rename legacy girls categories once while preserving record IDs and relationships."""
import json
OLD={'女子A':'女子U９','女子B':'女子U12','女子U9':'女子U９','U15A':'U15アドバンス','U15B':'U15ベーシック'}
def rename(value):
 for a,b in OLD.items():value=value.replace(a,b)
 return value
def init(c):
 if c.execute("SELECT 1 FROM meta WHERE key='category_names_oct2026_v2'").fetchone():return
 # Only labels and structured content, never IDs, passwords, files or sessions.
 fields={'categories','group_name','title','draft','published','body','value','classes','category','grade'}
 for table, in c.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall():
  if not table.replace('_','').isalnum():continue
  for col in c.execute('PRAGMA table_info("'+table+'")').fetchall():
   name=col[1]
   if name not in fields or 'TEXT' not in col[2].upper():continue
   for a,b in OLD.items():
    c.execute(f'UPDATE "{table}" SET "{name}"=replace("{name}",?,?) WHERE instr("{name}",?)>0',(a,b,a))
 c.execute("INSERT INTO meta VALUES('category_names_oct2026_v2','1')")
