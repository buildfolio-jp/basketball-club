"""Available membership payment methods. Historical receipts retain original labels."""
METHODS=('クレジットカード','コンビニ決済')
def valid(method):return method in METHODS
