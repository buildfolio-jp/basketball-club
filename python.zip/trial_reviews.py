"""Single-use review invitations with administrator publication approval."""
import secrets,time,datetime
import admin_access,submission_files

def init(c):
 c.execute('CREATE TABLE IF NOT EXISTS public_reviews(id TEXT PRIMARY KEY,token TEXT UNIQUE,label TEXT,name TEXT,age INTEGER,body TEXT,status TEXT,expires REAL,created TEXT,revision INTEGER DEFAULT 0)')
 for name,definition in [('kind',"TEXT DEFAULT 'trial'"),('experience',"TEXT DEFAULT ''"),('photo',"TEXT DEFAULT ''")]:
  if name not in {r[1] for r in c.execute('PRAGMA table_info(public_reviews)')}:c.execute('ALTER TABLE public_reviews ADD COLUMN '+name+' '+definition)
def public(c):return [dict(r) for r in c.execute("SELECT id,name,age,body,kind,experience,photo FROM public_reviews WHERE status='published' ORDER BY created DESC")]
def listing(c):return [dict(r) for r in c.execute('SELECT * FROM public_reviews ORDER BY created DESC,rowid DESC')]
def invitation(c,token):
 r=c.execute('SELECT * FROM public_reviews WHERE token=?',(token,)).fetchone()
 if not r or r['status']!='invited' or r['expires']<time.time():raise ValueError('この投稿URLは期限切れ、使用済み、または無効です。')
 return r

def submit(c,d):
 r=invitation(c,str(d.get('token','')));name=str(d.get('name','')).strip();body=str(d.get('body','')).strip()
 if not name or len(name)>50 or not body or len(body)>2000:raise ValueError('表示名は50文字以内、口コミは2000文字以内で入力してください。')
 try:age=int(d.get('age',''))
 except (ValueError,TypeError):raise ValueError('体験した方の年齢を入力してください。')
 if not 3<=age<=100:raise ValueError('年齢を確認してください。')
 if d.get('consent') is not True:raise ValueError('表示名・年齢・口コミの掲載への同意を確認してください。')
 experience=str(d.get('experience','')).strip()
 if len(experience)>100:raise ValueError('バスケ歴は100文字以内にしてください。')
 photo=''
 if r['kind']=='member' and d.get('photo'):
  submission_files.add(c,'review',r['id'],[d['photo']])
  file=submission_files.listing(c,'review',r['id'])[0]
  if not file['mime'].startswith('image/'):raise ValueError('写真はJPEG・PNG・WebPで送信してください。')
  photo=file['id']
 c.execute('UPDATE public_reviews SET experience=?,photo=? WHERE id=?',(experience,photo,r['id']))
 c.execute("UPDATE public_reviews SET name=?,age=?,body=?,status='pending',revision=revision+1 WHERE id=?",(name,age,body,r['id']))
def manage(c,u,d):
 if not admin_access.full(u):raise PermissionError('管理者のみ操作できます。')
 if d.get('action') in ('add','edit'):
  return edit_review(c,d)
 if d.get('action')=='create':
  label=str(d.get('label','')).strip()
  if len(label)>100:raise ValueError('管理用メモは100文字以内で入力してください。')
  if d.get('kind','trial') not in ('trial','member'):raise ValueError('口コミの種類を選択してください。')
  c.execute('INSERT INTO public_reviews(id,token,label,name,age,body,status,expires,created,revision) VALUES(?,?,?,?,?,?,?,?,?,0)',(secrets.token_hex(12),secrets.token_urlsafe(32),label,'',None,'','invited',time.time()+30*86400,time.strftime('%Y-%m-%d %H:%M:%S')))
  c.execute('UPDATE public_reviews SET kind=? WHERE rowid=last_insert_rowid()',(d.get('kind','trial'),))
  return
 r=c.execute('SELECT * FROM public_reviews WHERE id=?',(d.get('id'),)).fetchone()
 if not r or d.get('revision')!=r['revision']:raise ValueError('情報が更新されています。画面を読み直してください。')
 action=d.get('action')
 if action=='delete':
  c.execute("DELETE FROM submission_files WHERE kind='review' AND record_id=?",(r['id'],))
  c.execute('DELETE FROM public_reviews WHERE id=?',(r['id'],));return
 if action=='publish' and r['status'] in ('pending','hidden'):status='published'
 elif action=='hide' and r['status']=='published':status='hidden'
 elif action=='revoke' and r['status']=='invited':status='revoked'
 else:raise ValueError('この操作はできません。')
 c.execute('UPDATE public_reviews SET status=?,revision=revision+1 WHERE id=?',(status,r['id']))

def edit_review(c,d):
 name=str(d.get('name','')).strip();body=str(d.get('body','')).strip();experience=str(d.get('experience','')).strip()
 if not name or len(name)>50 or not body or len(body)>2000:raise ValueError('表示名は50文字以内、口コミは2000文字以内で入力してください。')
 try:age=int(d.get('age',''))
 except (ValueError,TypeError):raise ValueError('年齢を入力してください。')
 if not 3<=age<=100:raise ValueError('年齢を確認してください。')
 if len(experience)>100:raise ValueError('バスケ歴は100文字以内にしてください。')
 if d['action']=='add':
  rid=secrets.token_hex(12)
  c.execute("INSERT INTO public_reviews(id,token,label,name,age,body,status,expires,created,revision,kind,experience,photo) VALUES(?,?,?,?,?,?,'hidden',0,?,0,'member',?,'')",(rid,secrets.token_urlsafe(32),'管理者登録',name,age,body,time.strftime('%Y-%m-%d %H:%M:%S'),experience))
 r=c.execute('SELECT * FROM public_reviews WHERE id=?',(rid if d['action']=='add' else d.get('id'),)).fetchone()
 if not r or (d['action']=='edit' and d.get('revision')!=r['revision']):raise ValueError('情報が更新されています。画面を読み直してください。')
 if r['status'] not in ('hidden','pending','published'):raise ValueError('投稿済みの口コミを選択してください。')
 photo=r['photo']
 if d.get('remove_photo') or d.get('photo'):
  c.execute("DELETE FROM submission_files WHERE kind='review' AND record_id=?",(r['id'],));photo=''
 if r['kind']=='member' and d.get('photo'):
  submission_files.add(c,'review',r['id'],[d['photo']]);file=submission_files.listing(c,'review',r['id'])[0]
  if not file['mime'].startswith('image/'):raise ValueError('写真はJPEG・PNG・WebPで送信してください。')
  photo=file['id']
 c.execute('UPDATE public_reviews SET name=?,age=?,body=?,experience=?,photo=?,revision=revision+1 WHERE id=?',(name,age,body,experience,photo,r['id']))
