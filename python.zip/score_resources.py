"""Shared score-sheet links and private PDF attachments for match results."""
import base64,secrets
from urllib.parse import urlsplit
import admin_access,coach_scope

def init(c):
 c.execute('CREATE TABLE IF NOT EXISTS score_resources(result_id TEXT PRIMARY KEY,url TEXT,revision INTEGER)')
 c.execute('CREATE TABLE IF NOT EXISTS score_resource_files(id TEXT PRIMARY KEY,result_id TEXT,name TEXT,content BLOB)')
def allowed(c,u,rid,write=False):
 if not u or u['role'] not in ('admin','coach','member'):return False
 if write and not admin_access.can(u,'results',True):return False
 if u['role']=='admin' and not admin_access.can(u,'results'):return False
 r=c.execute('SELECT * FROM results WHERE id=?',(rid,)).fetchone()
 if not r:return False
 return not coach_scope.applies(u) or bool(coach_scope.categories(r['group_name']) & coach_scope.assigned(c,u))
def read(c,u):
 return [{**dict(r),'files':[dict(f) for f in c.execute('SELECT id,name FROM score_resource_files WHERE result_id=?',(r['result_id'],))]} for r in c.execute('SELECT * FROM score_resources') if allowed(c,u,r['result_id'])]
def save(c,u,d):
 rid=d.get('result_id')
 if not allowed(c,u,rid,True):raise PermissionError('このスコアシートの編集権限がありません。')
 old=c.execute('SELECT * FROM score_resources WHERE result_id=?',(rid,)).fetchone()
 rev=old['revision'] if old else 0
 if d.get('revision')!=rev:raise ValueError('更新されています。編集画面を開き直してください。')
 url=str(d.get('url','')).strip();parts=urlsplit(url)
 if url and (len(url)>4000 or parts.scheme not in ('https','http') or not parts.hostname or parts.username or parts.password):raise ValueError('共有URLはhttps://またはhttp://で入力してください。')
 files=list(c.execute('SELECT id FROM score_resource_files WHERE result_id=?',(rid,)));ids={f['id'] for f in files};keep=d.get('keep',[]);uploads=d.get('uploads',[])
 if not isinstance(keep,list) or any(x not in ids for x in keep) or not isinstance(uploads,list) or len(set(keep))+len(uploads)>30:raise ValueError('PDFは合計30件までです。')
 parsed=[]
 for f in uploads:
  try:raw=base64.b64decode(f['content'],validate=True)
  except Exception:raise ValueError('PDFを読み込めません。')
  if not 0<len(raw)<=5*1024*1024 or not raw.startswith(b'%PDF-') or b'%%EOF' not in raw[-2048:]:raise ValueError('1件5MB以下のPDFを選択してください。')
  parsed.append((secrets.token_hex(16),rid,str(f.get('name','スコアシート.pdf'))[:200],raw))
 for fid in ids-set(keep):c.execute('DELETE FROM score_resource_files WHERE id=?',(fid,))
 c.executemany('INSERT INTO score_resource_files VALUES(?,?,?,?)',parsed)
 c.execute('INSERT OR REPLACE INTO score_resources VALUES(?,?,?)',(rid,url,rev+1))
def file(c,u,fid):
 r=c.execute('SELECT * FROM score_resource_files WHERE id=?',(fid,)).fetchone()
 return r if r and allowed(c,u,r['result_id']) else None
