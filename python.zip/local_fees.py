"""Local Excel inputs, independent of the generated management workbook. No charges."""
import hashlib, io, json, time, zipfile
import xml.etree.ElementTree as ET
from decimal import Decimal, InvalidOperation

NS={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
CYCLES=('毎月払い','半年払い','年払い')
def init(c):
    c.execute('CREATE TABLE IF NOT EXISTS fee_amounts(kind TEXT,target TEXT,cycle TEXT,amount INTEGER,PRIMARY KEY(kind,target,cycle))')

def parse(content,sheet_name='会費入力',headers=None):
    headers=headers or ['区分','対象ID','氏名・家庭名',*CYCLES]
    columns='ABCDEFGHIJKLMNOPQRSTUVWXYZ'[:len(headers)]
    with zipfile.ZipFile(io.BytesIO(content)) as z:
        if sum(i.file_size for i in z.infolist())>10000000:raise ValueError('Excelのサイズが大きすぎます。')
        book=ET.fromstring(z.read('xl/workbook.xml'))
        sheet=next((s for s in book.findall('s:sheets/s:sheet',NS) if s.get('name')==sheet_name),None)
        if sheet is None:raise ValueError('「'+sheet_name+'」シートが必要です。')
        rid=sheet.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id')
        rel=next(r for r in ET.fromstring(z.read('xl/_rels/workbook.xml.rels')) if r.get('Id')==rid)
        target=rel.get('Target');path=target.lstrip('/') if target.startswith('/') else 'xl/'+target
        strings=[]
        if 'xl/sharedStrings.xml' in z.namelist():strings=[''.join(n.itertext()) for n in ET.fromstring(z.read('xl/sharedStrings.xml'))]
        values=[]
        for row in ET.fromstring(z.read(path)).findall('s:sheetData/s:row',NS):
            cells={}
            for cell in row.findall('s:c',NS):
                ref=cell.get('r');column=''.join(ch for ch in ref if ch.isalpha())
                if column not in columns or len(column)!=1:continue
                if cell.find('s:f',NS) is not None:raise ValueError('金額は数式ではなく確定した整数を入力してください。')
                value=cell.findtext('s:v','',NS)
                if cell.get('t')=='s':value=strings[int(value)]
                elif cell.get('t')=='inlineStr':value=''.join(cell.find('s:is',NS).itertext())
                cells[column]=value.strip()
            values.append([cells.get(k,'') for k in columns])
        if not values or values[0]!=headers:raise ValueError(sheet_name+'シートの見出しを変更しないでください。')
        return values[1:]

def sync(c,path):
    if not path.exists():return False
    content=path.read_bytes();digest=hashlib.sha256(content).hexdigest()
    old=c.execute("SELECT value FROM meta WHERE key='fee_input_status'").fetchone()
    if old and json.loads(old[0]).get('digest')==digest:return False
    status={'digest':digest,'updated':time.strftime('%Y-%m-%d %H:%M:%S'),'ok':False}
    try:
        users={r[0] for r in c.execute("SELECT id FROM users WHERE role='member'")}
        families={r[0] for r in c.execute('SELECT DISTINCT family_id FROM member_families')}
        records=[];seen=set()
        for kind,target,label,*amounts in parse(content):
            if not any((kind,target,label,*amounts)):continue
            if kind not in ('会員','家庭') or target not in (users if kind=='会員' else families):raise ValueError('区分・対象IDを確認してください。家庭IDは管理画面で先に登録します。')
            if (kind,target) in seen:raise ValueError('同じ対象IDの行が重複しています。')
            seen.add((kind,target))
            for cycle,value in zip(CYCLES,amounts):
                if not value:continue
                try:amount=Decimal(value)
                except InvalidOperation:raise ValueError('金額は0以上の整数で入力してください。')
                if not amount.is_finite() or amount!=amount.to_integral_value() or not 0<=amount<=10000000:raise ValueError('金額は0〜10000000円の整数で入力してください。')
                records.append((kind,target,cycle,int(amount)))
        c.execute('DELETE FROM fee_amounts')
        c.executemany('INSERT INTO fee_amounts VALUES(?,?,?,?)',records)
        status.update(ok=True,message='Excelの会費金額を反映しました。')
    except (ValueError,KeyError,StopIteration,ET.ParseError,zipfile.BadZipFile,IndexError) as e:
        status['message']=str(e) or 'Excelの形式を確認してください。'
    c.execute('INSERT OR REPLACE INTO meta VALUES(?,?)',('fee_input_status',json.dumps(status,ensure_ascii=False)))
    return True

def summary(c,u,cycle):
    children=u.get('family_members') or [u]
    family=c.execute('SELECT family_id FROM member_families WHERE user_id=?',(u['id'],)).fetchone()
    def amount(kind,target):
        r=c.execute('SELECT amount FROM fee_amounts WHERE kind=? AND target=? AND cycle=?',(kind,target,cycle)).fetchone()
        return r[0] if r else None
    lines=[{'id':ch['id'],'name':ch['name'],'amount':amount('会員',ch['id'])} for ch in children]
    override=amount('家庭',family[0]) if family else None
    total=override if override is not None else sum(v['amount'] for v in lines) if all(v['amount'] is not None for v in lines) else None
    return {'lines':lines,'total':total,'family_override':override is not None,'cycle':cycle}

def status(c):
    row=c.execute("SELECT value FROM meta WHERE key='fee_input_status'").fetchone()
    return json.loads(row[0]) if row else {'ok':False,'message':'会費金額は未取り込みです。'}
