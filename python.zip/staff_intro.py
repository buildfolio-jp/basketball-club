"""Explicitly published public staff introductions."""
import secrets,admin_access,submission_files,json
GROUPS=['男子A','男子B','女子A','女子B','U15A','U15B']
def init(c):
 c.execute('CREATE TABLE IF NOT EXISTS staff_intros(id TEXT PRIMARY KEY,name TEXT,comment TEXT,classes TEXT,published INTEGER,position INTEGER,revision TEXT)')
 for name,definition in [('staff_id',"TEXT DEFAULT ''"),('referee',"TEXT DEFAULT ''")]:
  if name not in [r[1] for r in c.execute('PRAGMA table_info(staff_intros)')]:c.execute('ALTER TABLE staff_intros ADD COLUMN '+name+' '+definition)

def read(c,public=False):
 return [{**dict(r),'classes':json.loads(r['classes']),'photo':next((f['id'] for f in submission_files.listing(c,'staff-intro',r['id'])), '')} for r in c.execute('SELECT * FROM staff_intros'+(' WHERE published=1' if public else '')+' ORDER BY position,name')]
def save(c,u,d):
 if not admin_access.can(u,'staff-members',True):raise PermissionError('コーチ・スタッフ一覧の編集権限が必要です。')
 rid=d.get('id') or secrets.token_hex(16);old=c.execute('SELECT * FROM staff_intros WHERE id=?',(rid,)).fetchone()
 if old and old['revision']!=d.get('revision'):raise ValueError('紹介が更新されています。開き直してください。')
 if d.get('delete'):
  c.execute("DELETE FROM submission_files WHERE kind='staff-intro' AND record_id=?",(rid,));c.execute('DELETE FROM staff_intros WHERE id=?',(rid,));return
 staff_id=str(d.get('staff_id',''));referee=d.get('referee','')
 if referee not in ('あり','なし'):raise ValueError('審判資格の有無を選択してください。')
 if staff_id and not c.execute("SELECT 1 FROM users WHERE id=? AND role IN ('coach','admin')",(staff_id,)).fetchone():raise ValueError('スタッフを選択してください。')
 if staff_id and c.execute('SELECT 1 FROM staff_intros WHERE staff_id=? AND id<>?',(staff_id,rid)).fetchone():raise ValueError('このスタッフの紹介は登録済みです。開き直してください。')
 name=str(d.get('name','')).strip();comment=str(d.get('comment','')).strip();classes=d.get('classes');position=d.get('position',0)
 if not name or len(name)>100 or len(comment)>2000 or not isinstance(classes,list) or any(x not in GROUPS for x in classes) or type(position)is not int or not 0<=position<=999:raise ValueError('氏名・担当クラス・コメント・表示順を確認してください。')
 if type(d.get('published'))is not bool:raise ValueError('掲載状態を選択してください。')
 if d.get('photo'):
  c.execute("DELETE FROM submission_files WHERE kind='staff-intro' AND record_id=?",(rid,));submission_files.add(c,'staff-intro',rid,[d['photo']])
  f=c.execute("SELECT mime FROM submission_files WHERE kind='staff-intro' AND record_id=?",(rid,)).fetchone()
  if not f['mime'].startswith('image/'):raise ValueError('写真はJPEG・PNG・WebPを指定してください。')
 if d['published'] and (not comment or not classes or not submission_files.listing(c,'staff-intro',rid)):raise ValueError('公開前に写真・担当クラス・コメントを入力してください。')
 c.execute('INSERT OR REPLACE INTO staff_intros VALUES(?,?,?,?,?,?,?,?,?)',(rid,name,comment,json.dumps(classes),int(d['published']),position,secrets.token_hex(12),staff_id,referee))
