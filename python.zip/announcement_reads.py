import hashlib,json,time,re,zipfile
import xml.etree.ElementTree as ET
import local_fees
def init(c):
    c.execute('CREATE TABLE IF NOT EXISTS announcement_reads(item_id TEXT,revision TEXT,user_id TEXT,reader_id TEXT,read_at TEXT,PRIMARY KEY(item_id,revision,user_id))')
def revision(item,c=None):
    text=item['title']+'\n'+item['body']
    if c is not None:
        files=list(c.execute('SELECT id,name FROM announcement_files WHERE entry_id=? ORDER BY id',(item['id'],)))
        if files:text+='\n'+json.dumps([list(r) for r in files],ensure_ascii=False)
    return hashlib.sha256(text.encode()).hexdigest()
def board_items(c):
    return [{'id':r['id'],'title':r['body'].split('\n',1)[0],'body':r['body']} for r in c.execute("SELECT e.* FROM portal_entries e JOIN users u ON u.id=e.user_id WHERE e.kind='board' AND u.role IN ('coach','admin')")]
def read(c,u,board=False):
    staff=u['role']!='member';out=[]
    members=[dict(r) for r in c.execute("SELECT id,name FROM users WHERE role='member' AND active=1")]
    for item in (board_items(c) if board else c.execute("SELECT * FROM portal_items WHERE kind='announcements'")):
        rev=revision(item,c)
        for member in members if staff else [{'id':u['id'],'name':u['name']}]:
            receipt=c.execute('SELECT r.*,u.name AS reader_name FROM announcement_reads r LEFT JOIN users u ON u.id=r.reader_id WHERE item_id=? AND revision=? AND user_id=?',(('board:'+item['id'] if board else item['id']),rev,member['id'])).fetchone()
            out.append({'item_id':item['id'],'title':item['title'],'revision':rev,'user_id':member['id'],'name':member['name'],'status':'既読' if receipt and receipt['reader_id']==member['id'] else '家族が確認済み' if receipt else '未読','reader_name':receipt['reader_name'] if receipt else '', 'read_at':receipt['read_at'] if receipt else ''})
    return out
def acknowledge(c,u,d,board=False):
    if u['role']!='member':raise ValueError('会員の画面から確認してください。')
    item=next((i for i in board_items(c) if i['id']==d.get('id')),None) if board else c.execute("SELECT * FROM portal_items WHERE id=? AND kind='announcements'",(d.get('id'),)).fetchone()
    if not item or d.get('revision')!=revision(item,c):raise ValueError('お知らせが更新されました。画面を更新して内容を確認してください。')
    # Snapshot the currently authorized siblings; future household changes do not inherit reads.
    for member in u.get('family_members',[u]):
        c.execute('INSERT OR IGNORE INTO announcement_reads VALUES(?,?,?,?,?)',(('board:'+item['id'] if board else item['id']),revision(item,c),member['id'],u['id'],time.strftime('%Y-%m-%d %H:%M:%S')))
def sync(c,path):
    if not path.exists():return False
    content=path.read_bytes();digest=hashlib.sha256(content).hexdigest();key='announcement_input_status'
    prev=c.execute('SELECT value FROM meta WHERE key=?',(key,)).fetchone()
    if prev and json.loads(prev[0]).get('digest')==digest:return False
    status={'digest':digest,'updated':time.strftime('%Y-%m-%d %H:%M:%S'),'ok':False}
    try:
        entries=local_fees.parse(content,'お知らせ入力',['お知らせID','タイトル','本文','公開状態']);records=[];seen=set()
        for uid,title,body,state in entries:
            if not any((uid,title,body,state)):continue
            if not re.fullmatch(r'[A-Za-z0-9_-]{1,40}',uid) or uid in seen or not title or len(title)>120 or not body or len(body)>4000 or state not in ('公開','非公開'):raise ValueError('IDの重複、タイトル・本文、公開／非公開を確認してください。')
            seen.add(uid)
            if state=='公開':records.append(('excel-notice-'+uid,'announcements',title,body,0))
        c.execute("DELETE FROM portal_items WHERE kind='announcements' AND id LIKE 'excel-notice-%'")
        c.executemany('INSERT INTO portal_items VALUES(?,?,?,?,?)',records)
        status.update(ok=True,message='お知らせExcelを反映しました。')
    except (ValueError,KeyError,StopIteration,ET.ParseError,zipfile.BadZipFile,IndexError) as e:status['message']=str(e) or 'Excelを確認してください。'
    c.execute('INSERT OR REPLACE INTO meta VALUES(?,?)',(key,json.dumps(status,ensure_ascii=False)))
    return True
