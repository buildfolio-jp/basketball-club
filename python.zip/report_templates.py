"""Editable labels and choices for existing reports; saved answers remain unchanged."""
import json
import admin_access
DEFAULTS={
 'condition':[
  {'id':'body_condition','label':'体の調子','type':'select','options':['とても良い','普通','良くない','ダメ']},
  {'id':'mind_condition','label':'心の調子','type':'select','options':['とても良い','普通','良くない','ダメ']},
  {'id':'breakfast','label':'朝ご飯','type':'select','options':['食べた','あんまり食べてない','食べてない']},
  {'id':'unwell_area','label':'調子の悪いところ','type':'text','options':[]},
  {'id':'note','label':'その他の連絡事項','type':'textarea','options':[]}],
 'injuries':[
  {'id':'injury_date','label':'怪我をした日','type':'date','options':[]},
  {'id':'part','label':'怪我の部位','type':'text','options':[]},
  {'id':'participation','label':'練習への参加','type':'select','options':['見学','一部参加を希望','欠席','コーチに相談']},
  {'id':'body','label':'状況・受診状況・コーチへの連絡','type':'textarea','options':[]}]}
def read(c,kind):
 if kind not in DEFAULTS:raise ValueError('報告の種類を確認してください。')
 r=c.execute('SELECT value FROM meta WHERE key=?',('report_template_'+kind,)).fetchone()
 return json.loads(r[0]) if r else {'revision':0,'questions':DEFAULTS[kind]}
def save(c,u,d):
 if not admin_access.full(u) or u.get('delegated_coach'):raise PermissionError('管理者のみ設定できます。')
 kind=d.get('kind');old=read(c,kind)
 if d.get('revision')!=old['revision']:raise ValueError('設定が更新されています。開き直してください。')
 qs=d.get('questions')
 if not isinstance(qs,list) or len(qs)!=len(DEFAULTS[kind]):raise ValueError('質問を確認してください。')
 prepared=[]
 for base,q in zip(DEFAULTS[kind],qs):
  if not isinstance(q,dict) or q.get('id')!=base['id']:raise ValueError('質問を確認してください。')
  label=str(q.get('label','')).strip();options=q.get('options',[])
  if not label or len(label)>100:raise ValueError('質問文は1〜100文字で入力してください。')
  if base['type']=='select':
   if not isinstance(options,list) or not 1<=len(options)<=30 or any(not isinstance(v,str) or not v.strip() or len(v)>100 for v in options):raise ValueError('選択肢は1〜30個、各100文字以内で入力してください。')
   options=list(dict.fromkeys(v.strip() for v in options))
  else:options=[]
  prepared.append({**base,'label':label,'options':options})
 c.execute('INSERT OR REPLACE INTO meta VALUES(?,?)',('report_template_'+kind,json.dumps({'revision':old['revision']+1,'questions':prepared},ensure_ascii=False)))
