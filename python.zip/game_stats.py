"""Per-player match records with server-side publication controls."""
import json,time
FIELDS=('points','fouls','rebounds','assists','steals','blocks','turnovers')
def init(c):
    c.execute('CREATE TABLE IF NOT EXISTS game_stats(result_id TEXT,user_id TEXT,body TEXT,PRIMARY KEY(result_id,user_id))')
    c.execute('CREATE TABLE IF NOT EXISTS game_stats_publication(result_id TEXT PRIMARY KEY,visibility TEXT,updated TEXT)')
def read(c,u):
    staff=u['role']!='member';out=[]
    for row in c.execute('SELECT s.*,p.visibility,u.name FROM game_stats s JOIN users u ON u.id=s.user_id JOIN game_stats_publication p ON p.result_id=s.result_id'):
        if staff or row['visibility']=='team' or (row['visibility']=='personal' and row['user_id']==u['id']):
            out.append({'result_id':row['result_id'],'user_id':row['user_id'],'name':row['name'],**json.loads(row['body'])})
    publications=[dict(r) for r in c.execute('SELECT * FROM game_stats_publication')]
    return {'rows':out,'publications':publications if staff else [r for r in publications if r['visibility']!='draft']}
def save(c,u,d):
    if u['role']!='admin':raise ValueError('管理者のみ編集できます。')
    rid=d.get('result_id');visibility=d.get('visibility');entries=d.get('entries')
    if not c.execute('SELECT 1 FROM results WHERE id=?',(rid,)).fetchone():raise ValueError('試合が見つかりません。')
    if visibility not in ('draft','personal','team') or not isinstance(entries,list) or len(entries)>50:raise ValueError('公開設定・選手一覧を確認してください。')
    members={r[0] for r in c.execute("SELECT id FROM users WHERE role='member'")};seen=set();records=[]
    for row in entries:
        uid=row.get('user_id')
        if uid not in members or uid in seen:raise ValueError('選手の重複・会員IDを確認してください。')
        seen.add(uid);body={}
        for key in FIELDS:
            value=row.get(key)
            if value in ('',None):body[key]=None;continue
            if isinstance(value,bool) or not str(value).isdigit() or not 0<=int(value)<=999:raise ValueError('記録は0〜999の整数、未記録は空欄にしてください。')
            body[key]=int(value)
        body['number']=str(row.get('number','')).strip()
        if body['number'] and (not body['number'].isdigit() or len(body['number'])>2):raise ValueError('背番号は0〜99で入力してください。')
        body['participation']=row.get('participation','')
        if body['participation'] not in ('出場','ベンチ（出場なし）','未確認'):raise ValueError('出場状況を選択してください。')
        if body['participation']=='ベンチ（出場なし）' and any(body[k] not in (None,0) for k in FIELDS):raise ValueError('出場なしの選手に実績を入力できません。')
        old=c.execute('SELECT body FROM game_stats WHERE result_id=? AND user_id=?',(rid,uid)).fetchone()
        starter=row.get('starter',json.loads(old[0]).get('starter',False) if old else False)
        if not isinstance(starter,bool):raise ValueError('スタメンの指定を確認してください。')
        if starter and body['participation']!='出場':raise ValueError('スタメンは出場した選手を選択してください。')
        body['starter']=starter
        records.append((rid,uid,json.dumps(body,ensure_ascii=False)))
    if sum(json.loads(r[2]).get('starter',False) for r in records)>5:raise ValueError('スタメンは5人まで選択してください。')
    c.execute('DELETE FROM game_stats WHERE result_id=?',(rid,))
    c.executemany('INSERT INTO game_stats VALUES(?,?,?)',records)
    c.execute('INSERT OR REPLACE INTO game_stats_publication VALUES(?,?,?)',(rid,visibility,time.strftime('%Y-%m-%d %H:%M:%S')))

IMPORT_HEADERS=['試合ID','日付','対戦相手','会員ID','氏名','背番号','出場状況','得点','ファウル','リバウンド','アシスト','スティール','ブロック','ターンオーバー']
def import_file(c,u,d):
    if u['role']!='admin':raise ValueError('管理者のみ編集できます。')
    import base64,csv,io,local_fees
    try: content=base64.b64decode(d.get('content',''),validate=True)
    except Exception:raise ValueError('ファイルを読み込めません。')
    if not content or len(content)>5*1024*1024:raise ValueError('5MB以下のファイルを選んでください。')
    if str(d.get('filename','')).lower().endswith('.xlsx'):
        try:rows=local_fees.parse(content,'個人試合記録',IMPORT_HEADERS)
        except Exception as e:raise ValueError('個人試合記録シートを確認してください：'+str(e))
    elif str(d.get('filename','')).lower().endswith('.csv'):
        try:rows=list(csv.reader(io.StringIO(content.decode('utf-8-sig'))))
        except Exception:raise ValueError('CSVはUTF-8で保存してください。')
        if not rows or rows.pop(0)!=IMPORT_HEADERS:raise ValueError('CSVの見出しを個人試合記録シートと同じにしてください。')
    else:raise ValueError('Excel（.xlsx）またはCSVを選択してください。')
    groups={};seen=set()
    if len(rows)>5000:raise ValueError('一度に5000行まで取り込めます。')
    for row in rows:
        if not any(row):continue
        if len(row)!=14:raise ValueError('列数を確認してください。')
        rid,_,_,uid,_,number,participation,*values=row
        if (rid,uid) in seen:raise ValueError('同じ試合・会員の行が重複しています。')
        seen.add((rid,uid));groups.setdefault(rid,[]).append({'user_id':uid,'number':number,'participation':participation,**dict(zip(FIELDS,values))})
    if not groups:raise ValueError('取り込む記録がありません。')
    c.execute('SAVEPOINT stats_import')
    try:
        for rid,updates in groups.items():
            old=[{'user_id':r['user_id'],**json.loads(r['body'])} for r in c.execute('SELECT * FROM game_stats WHERE result_id=?',(rid,))]
            byid={r['user_id']:r for r in old};byid.update({r['user_id']:r for r in updates})
            save(c,u,{'result_id':rid,'visibility':'draft','entries':list(byid.values())})
        if d.get('confirm') is not True:c.execute('ROLLBACK TO stats_import')
        c.execute('RELEASE stats_import')
    except Exception:
        c.execute('ROLLBACK TO stats_import');c.execute('RELEASE stats_import');raise
    return {'games':len(groups),'players':len(seen),'preview':[{'result_id':rid,**r} for rid,rows in groups.items() for r in rows]}
