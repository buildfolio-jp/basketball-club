# coding: utf-8
"""Year-scoped treasurer accounts and locally archived accounting records."""
import base64,hashlib,json,re,secrets,datetime,io
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
from xml.sax.saxutils import escape
import admin_access,accounts,credentials
ACCOUNT_TYPES=['一般会計','特別会計','NEW YEARチャレンジカップ','合宿']
def account_type(value):
 if value not in ACCOUNT_TYPES:raise ValueError('会計区分を選択してください。')
 return value
CATEGORIES=['会費収入','参加費収入','寄付金','その他収入','備品費','会場費','交通費','大会参加費','消耗品費','通信費','保険料','その他支出']
def today():return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9))).date()
def fiscal_year():return today().year-(today().month<4)
def init(c):
 c.executescript('''CREATE TABLE IF NOT EXISTS accounting_assignments(id TEXT PRIMARY KEY,name TEXT,year INTEGER,login_id TEXT,code TEXT,active INTEGER,revision TEXT);
 CREATE TABLE IF NOT EXISTS accounting_entries(id TEXT PRIMARY KEY,year INTEGER,date TEXT,direction TEXT,category TEXT,amount INTEGER,description TEXT,note TEXT,file_id TEXT,updated TEXT,updated_by TEXT,revision TEXT);
 CREATE TABLE IF NOT EXISTS accounting_files(id TEXT PRIMARY KEY,year INTEGER,name TEXT,mime TEXT,content BLOB);
 CREATE TABLE IF NOT EXISTS accounting_audit(id TEXT PRIMARY KEY,actor TEXT,action TEXT,entry_id TEXT,detail TEXT,created TEXT);''')
 if 'account_type' not in {r[1] for r in c.execute('PRAGMA table_info(accounting_entries)')}:c.execute("ALTER TABLE accounting_entries ADD COLUMN account_type TEXT NOT NULL DEFAULT '一般会計'")
def now():return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9))).isoformat(timespec='seconds')
def active(c,uid):return c.execute('SELECT 1 FROM accounting_assignments WHERE login_id=? AND active=1 AND year=?',(uid,fiscal_year())).fetchone() is not None
def access(c,u,year,write=False):
 if not u:raise PermissionError('ログインしてください。')
 if u['role']=='admin' and not u.get('delegated_officer') and admin_access.can(u,'finance-admin',write):return
 if (u['role']=='accountant' or u.get('delegated_officer')) and int(year)==fiscal_year() and active(c,u['id']):return
 raise PermissionError('この年度の会計を操作する権限がありません。')
def audit(c,u,action,rid,detail):c.execute('INSERT INTO accounting_audit VALUES(?,?,?,?,?,?)',(secrets.token_hex(16),u['id'],action,rid,json.dumps(detail,ensure_ascii=False),now()))
def assignment(c,u,d):
 if u.get('delegated_officer') or not admin_access.full(u):raise PermissionError('会計担当者を設定する権限がありません。')
 rid=d.get('id') or secrets.token_hex(16);old=c.execute('SELECT * FROM accounting_assignments WHERE id=?',(rid,)).fetchone()
 if old and old['revision']!=d.get('revision'):raise ValueError('担当者情報が更新されています。再読み込みしてください。')
 if d.get('delete'):
  if not old:raise ValueError('担当者が見つかりません。')
  c.execute('UPDATE accounting_assignments SET active=0,revision=? WHERE id=?',(secrets.token_hex(12),rid))
  if old['login_id']:c.execute('UPDATE users SET active=0 WHERE id=?',(old['login_id'],));c.execute('DELETE FROM login_sessions WHERE user_id=?',(old['login_id'],))
 else:
  name=str(d.get('name','')).strip();year=int(d.get('year',0))
  if not name or len(name)>100 or not 2020<=year<=2100:raise ValueError('氏名と年度を確認してください。')
  c.execute('INSERT OR REPLACE INTO accounting_assignments VALUES(?,?,?,?,?,?,?)',(rid,name,year,old['login_id'] if old else '',old['code'] if old else secrets.token_urlsafe(24),1,secrets.token_hex(12)))
  if old and old['login_id']:c.execute('UPDATE users SET name=?,active=1 WHERE id=?',(name,old['login_id']))
 audit(c,u,'担当者変更',rid,{'delete':bool(d.get('delete'))});return rid

def register(c,d,hash_password):
 a=c.execute("SELECT * FROM accounting_assignments WHERE code=? AND active=1 AND login_id=''",(str(d.get('code','')),)).fetchone()
 if not a or int(a['year'])<fiscal_year():raise ValueError('登録案内が無効、期限切れ、または登録済みです。')
 uid=str(d.get('id','')).strip();pw=d.get('password','')
 if not re.fullmatch(r'[A-Za-z0-9_-]{3,40}',uid) or not isinstance(pw,str) or not 8<=len(pw)<=128 or pw!=d.get('password_confirm'):raise ValueError('IDと8文字以上のパスワード・確認用パスワードを確認してください。')
 if credentials.taken(c,uid) or c.execute('SELECT 1 FROM users WHERE id=?',(uid,)).fetchone() or c.execute('SELECT 1 FROM guardian_accounts WHERE login_id=?',(uid,)).fetchone():raise ValueError('このIDは登録済みです。別のIDを入力してください。')
 c.execute("INSERT INTO users VALUES(?,?,'会計','accountant',?,1)",(uid,a['name'],hash_password(pw)))
 c.execute('UPDATE accounting_assignments SET login_id=?,revision=? WHERE id=?',(uid,secrets.token_hex(12),a['id']))
 return a['year']

def read(c,u,year,section=None):
 access(c,u,year)
 entries=[dict(r) for r in c.execute('SELECT * FROM accounting_entries WHERE year=? ORDER BY date DESC,id',(year,))]
 if section is not None:
  account_type(section);entries=[r for r in entries if r['account_type']==section]
 income=sum(r['amount'] for r in entries if r['direction']=='収入');expense=sum(r['amount'] for r in entries if r['direction']=='支出')
 import finance_reports
 return {'account_type':section or '全て','account_types':ACCOUNT_TYPES,'transport_reports':[r for r in transport_reports(c,year) if section is None or r['body'].get('account_type','一般会計')==section],'member_reports':[r for r in finance_reports.read(c,u,year) if section is None or r['account_type']==section],'year':year,'entries':entries,'categories':CATEGORIES,'income':income,'expense':expense,'balance':income-expense,'files':[dict(r) for r in c.execute('SELECT id,name,mime FROM accounting_files WHERE year=?',(year,))], 'assignments':[dict(r) for r in c.execute('SELECT * FROM accounting_assignments ORDER BY year DESC,name')] if u['role']=='admin' and not u.get('delegated_officer') else [],'years':sorted({r[0] for r in c.execute('SELECT year FROM accounting_assignments UNION SELECT year FROM accounting_entries')}|{fiscal_year()},reverse=True) if u['role']=='admin' and not u.get('delegated_officer') else [fiscal_year()]}

def entry(c,u,d):
 year=int(d.get('year',0));access(c,u,year,True)
 rid=d.get('id') or secrets.token_hex(16);old=c.execute('SELECT * FROM accounting_entries WHERE id=?',(rid,)).fetchone()
 if old and (old['year']!=year or old['revision']!=d.get('revision')):raise ValueError('明細が更新されています。再読み込みして内容を確認してください。')
 if d.get('delete'):
  if not old:raise ValueError('明細がありません。')
  audit(c,u,'明細削除',rid,dict(old));c.execute('DELETE FROM accounting_entries WHERE id=?',(rid,));return
 date=datetime.date.fromisoformat(str(d.get('date','')));direction=d.get('direction');category=d.get('category');amount=d.get('amount')
 if not datetime.date(year,4,1)<=date<=datetime.date(year+1,3,31):raise ValueError('日付を選択した年度内にしてください。')
 if direction not in ('収入','支出') or category not in CATEGORIES or type(amount)!=int or not 0<=amount<=100000000:raise ValueError('収支区分・明細区分・金額を確認してください。')
 description=str(d.get('description','')).strip();note=str(d.get('note','')).strip()
 if not description or len(description)>300 or len(note)>3000:raise ValueError('摘要は1〜300文字、備考は3000文字以内で入力してください。')
 file_id=old['file_id'] if old else '';upload=d.get('upload')
 if upload:
  try:raw=base64.b64decode(upload['content'],validate=True)
  except Exception:raise ValueError('添付ファイルを読み込めません。')
  if not 0<len(raw)<=10*1024*1024:raise ValueError('添付は10MB以下にしてください。')
  mime='application/pdf' if raw.startswith(b'%PDF-') and b'%%EOF' in raw[-2048:] else 'image/png' if raw.startswith(b'\x89PNG\r\n\x1a\n') else 'image/jpeg' if raw.startswith(b'\xff\xd8\xff') else 'image/webp' if raw.startswith(b'RIFF') and raw[8:12]==b'WEBP' else ''
  if not mime and str(upload.get('name','')).lower().endswith('.csv'):
   try:raw.decode('utf-8-sig')
   except UnicodeDecodeError:
    try:raw.decode('shift_jis')
    except UnicodeDecodeError:raise ValueError('CSVの文字コードを確認してください。')
   mime='text/csv'
  if not mime:raise ValueError('PDF・CSV・JPEG・PNG・WebPを添付してください。')
  file_id=secrets.token_hex(16);c.execute('INSERT INTO accounting_files VALUES(?,?,?,?,?)',(file_id,year,str(upload.get('name','領収書'))[:200],mime,raw))
 section=account_type(d.get('account_type',old['account_type'] if old else '一般会計'))
 rev=secrets.token_hex(12)
 c.execute('INSERT OR REPLACE INTO accounting_entries VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',(rid,year,date.isoformat(),direction,category,amount,description,note,file_id,now(),u['id'],rev,section))
 audit(c,u,'明細保存',rid,{'before':dict(old) if old else None,'revision':rev})

def report_lines(state):
 year=state['year'];lines=[f'SHINING CHEETAHS {year}年度 {state.get("account_type","全て")} 収支報告書',f'{year}/04/01 〜 {year+1}/03/31',f"収入合計 {state['income']:,}円    支出合計 {state['expense']:,}円",f"当年度収支差額 {state['balance']:,}円",'（繰越金は含みません。必要に応じて収入明細として登録してください。）','', '区分別集計']
 for cat in CATEGORIES:
  for direction in ('収入','支出'):
   total=sum(r['amount'] for r in state['entries'] if r['category']==cat and r['direction']==direction)
   if total:lines.append(f'{direction} ／ {cat}　{total:,}円')
 lines+=['','明細（日付順）']
 for r in reversed(state['entries']):lines += [f"{r['date']}　{r.get('account_type','一般会計')}　{r['direction']}　{r['category']}　{r['amount']:,}円",'摘要：'+r['description'],'備考：'+(r['note'] or '—'),'']
 return lines

def pdf_bytes(state,source_lines=None):
 # Standard Japanese CID font, searchable Unicode text, paginated A4.
 lines=[]
 for s in (report_lines(state) if source_lines is None else source_lines):
  chunk='';width=0
  for ch in s:
   w=1 if ord(ch)<128 else 2
   if width+w>88:lines.append(chunk);chunk='';width=0
   chunk+=ch;width+=w
  lines.append(chunk)
 pages=[lines[i:i+39] for i in range(0,len(lines),39)];objects=[b'',b'',b'<< /Type /Font /Subtype /Type0 /BaseFont /HeiseiMin-W3 /Encoding /UniJIS-UTF16-H /DescendantFonts [4 0 R] /ToUnicode 6 0 R >>',b'<< /Type /Font /Subtype /CIDFontType0 /BaseFont /HeiseiMin-W3 /FontDescriptor 5 0 R /DW 1000 /W [1 95 500] /CIDSystemInfo << /Registry (Adobe) /Ordering (Japan1) /Supplement 6 >> >>']
 cmap=b'/CIDInit /ProcSet findresource begin 12 dict begin begincmap /CIDSystemInfo << /Registry (Adobe) /Ordering (UCS) /Supplement 0 >> def /CMapName /Adobe-Identity-UCS def /CMapType 2 def 1 begincodespacerange <0000> <FFFF> endcodespacerange 1 beginbfrange <0000> <FFFF> <0000> endbfrange endcmap CMapName currentdict /CMap defineresource pop end end'
 objects += [b'<< /Type /FontDescriptor /FontName /HeiseiMin-W3 /Flags 6 /FontBBox [-123 -257 1001 910] /ItalicAngle 0 /Ascent 723 /Descent -241 /CapHeight 709 /StemV 69 >>',b'<< /Length '+str(len(cmap)).encode()+b' >>\nstream\n'+cmap+b'\nendstream']
 kids=[]
 for n,page in enumerate(pages):
  pid=len(objects)+1;kids.append(f'{pid} 0 R');stream='BT /F1 11 Tf 40 790 Td 19 TL\n'+''.join('<'+s.encode('utf-16-be').hex()+'> Tj T*\n' for s in page)+'ET\nBT /F1 9 Tf 280 25 Td <'+f'{n+1} / {len(pages)}'.encode('utf-16-be').hex()+'> Tj ET'
  raw=stream.encode('ascii');objects += [f'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 3 0 R >> >> /Contents {pid+1} 0 R >>'.encode(),b'<< /Length '+str(len(raw)).encode()+b' >>\nstream\n'+raw+b'\nendstream']
 objects[0]=b'<< /Type /Catalog /Pages 2 0 R >>';objects[1]=f'<< /Type /Pages /Count {len(kids)} /Kids [{" ".join(kids)}] >>'.encode();out=bytearray(b'%PDF-1.4\n');offsets=[0]
 for i,obj in enumerate(objects,1):offsets.append(len(out));out+=f'{i} 0 obj\n'.encode()+obj+b'\nendobj\n'
 xref=len(out);out+=f'xref\n0 {len(objects)+1}\n0000000000 65535 f \n'.encode()+b''.join(f'{n:010} 00000 n \n'.encode() for n in offsets[1:])+f'trailer << /Size {len(objects)+1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF'.encode();return bytes(out)

def xlsx_bytes(state):
 from excel_export import sheet_xml
 rows=[[r['date'],r.get('account_type','一般会計'),r['direction'],r['category'],r['amount'],r['description'],r['note']] for r in reversed(state['entries'])]
 summary=[['会計区分',state.get('account_type','全て')],['期間',f"{state['year']}/04/01〜{state['year']+1}/03/31"],['収入合計',state['income']],['支出合計',state['expense']],['当年度収支差額',state['balance']]]
 summary += [[direction+' / '+cat,sum(r['amount'] for r in state['entries'] if r['category']==cat and r['direction']==direction)] for direction in ('収入','支出') for cat in CATEGORIES if any(r['category']==cat and r['direction']==direction for r in state['entries'])]
 sheets=[('収支報告',['項目','金額・内容'],summary),('明細',['日付','会計区分','収支','明細区分','金額（円）','摘要','備考'],rows)];out=io.BytesIO()
 with ZipFile(out,'w',ZIP_DEFLATED) as z:
  z.writestr('[Content_Types].xml','<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'+''.join(f'<Override PartName="/xl/worksheets/sheet{i}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' for i in (1,2))+'</Types>')
  z.writestr('_rels/.rels','<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
  z.writestr('xl/workbook.xml','<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>'+''.join(f'<sheet name="{name}" sheetId="{i}" r:id="rId{i}"/>' for i,(name,_,_) in enumerate(sheets,1))+'</sheets></workbook>')
  z.writestr('xl/_rels/workbook.xml.rels','<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'+''.join(f'<Relationship Id="rId{i}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{i}.xml"/>' for i in (1,2))+'<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>')
  z.writestr('xl/styles.xml','<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Yu Gothic"/></font><font><b/><sz val="11"/><name val="Yu Gothic"/></font></fonts><fills count="4"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FFE7EFFA"/></patternFill></fill><fill><patternFill patternType="none"/></fill></fills><borders count="1"><border/></borders><cellStyleXfs count="1"><xf/></cellStyleXfs><cellXfs count="4"><xf/><xf fontId="1" fillId="2" applyFont="1" applyFill="1"/><xf/><xf numFmtId="3" applyNumberFormat="1"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>')
  for i,(_,heads,values) in enumerate(sheets,1):z.writestr(f'xl/worksheets/sheet{i}.xml',re.sub(r'<c r="([^"]+)" s="[02]"><v>',r'<c r="\1" s="3"><v>',sheet_xml(heads,values)))
 return out.getvalue()

def archive(c,root,year):
 folder=Path(root)/'会計'/str(year);folder.mkdir(parents=True,exist_ok=True)
 state=read(c,{'id':'archive','role':'admin','admin_rank':1},year)
 for name,raw in [('収支報告書.xlsx',xlsx_bytes(state)),('収支報告書.pdf',pdf_bytes(state)),('会計明細.json',json.dumps(state,ensure_ascii=False,indent=2).encode())]:
  # Invitation codes and account assignments stay in the database, not exported.
  if name.endswith('.json'):raw=json.dumps({k:v for k,v in state.items() if k not in ('assignments',)},ensure_ascii=False,indent=2).encode()
  temp=folder/(name+'.tmp');temp.write_bytes(raw);temp.replace(folder/name)
 for section in ACCOUNT_TYPES:
  target=folder/section;target.mkdir(exist_ok=True);part=read(c,{'id':'archive','role':'admin','admin_rank':1},year,section)
  for name,raw in [('収支報告書.xlsx',xlsx_bytes(part)),('収支報告書.pdf',pdf_bytes(part))]:
   temp=target/(name+'.tmp');temp.write_bytes(raw);temp.replace(target/name)
 for f in c.execute('SELECT * FROM accounting_files WHERE year=?',(year,)):
  ext={'application/pdf':'pdf','image/png':'png','image/jpeg':'jpg','image/webp':'webp','text/csv':'csv'}[f['mime']];receipts=folder/'領収書';receipts.mkdir(exist_ok=True);(receipts/(f['id']+'.'+ext)).write_bytes(f['content'])
 return 'data / 会計 / '+str(year)


def transport_reports(c,year):
 if not c.execute("SELECT 1 FROM sqlite_master WHERE name='logistics_expenses'").fetchone():return []
 return [{**dict(r),'body':json.loads(r['body'])} for r in c.execute("SELECT x.*,e.date,e.title FROM logistics_expenses x JOIN events e ON e.id=x.event_id WHERE e.date>=? AND e.date<? ORDER BY e.date DESC",(f'{year}-04-01',f'{year+1}-04-01'))]
