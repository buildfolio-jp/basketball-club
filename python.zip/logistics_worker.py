"""Server-side durable reminder scheduling and LINE delivery (never browser timers)."""
import datetime,time,os,json,urllib.request,urllib.error
import event_logistics as L

def schedule(c,current=None):
 current=current or L.now()
 for row in c.execute('SELECT * FROM logistics_settings').fetchall():
  s=L.settings(c,row['event_id'],row['kind'])
  if not s['enabled']:continue
  try:e=L.event(c,row['event_id']);due=L.deadline(s)
  except ValueError:continue
  p=L.plan(c,e['id'],row['kind']);kind=row['kind']
  if not p['published'] and due-datetime.timedelta(hours=s['remind_hours'])<=current<due:L.enqueue(c,e,kind,'unanswered','auto')
  match=L.re.search(r'(\d{1,2}:\d{2})',e['time'])
  if match:
   try:start=datetime.datetime.fromisoformat(e['date']+'T'+match[1].zfill(5)).replace(tzinfo=L.JST)
   except ValueError:continue
   if p['published'] and start-datetime.timedelta(hours=s['confirm_hours'])<=current<start:L.enqueue(c,e,kind,'unconfirmed','auto')

def claim(c):
 row=c.execute("SELECT * FROM logistics_messages WHERE status='queued' ORDER BY created LIMIT 1").fetchone()
 if not row:return None
 r=dict(row)
 try:e=L.event(c,r['event_id'])
 except ValueError:
  c.execute("UPDATE logistics_messages SET status='対象外（日程削除済み）' WHERE id=?",(r['id'],));return None
 eligible=L.recipients(c,e,r['kind'],r['type'])
 if r['family_id'] not in eligible or not L.settings(c,e['id'],r['kind'])['enabled']:
  c.execute("UPDATE logistics_messages SET status='対象外（回答・確認済み等）' WHERE id=?",(r['id'],));return None
 token=os.environ.get('CHEETAHS_LINE_CHANNEL_ACCESS_TOKEN');dest=L.line_targets().get(r['family_id'])
 if not token or not dest:c.execute("UPDATE logistics_messages SET status='未送信（LINE未連携）' WHERE id=?",(r['id'],));return None
 c.execute("UPDATE logistics_messages SET status='sending' WHERE id=? AND status='queued'",(r['id'],));return r,token,dest

def deliver(job):
 r,token,dest=job
 req=urllib.request.Request('https://api.line.me/v2/bot/message/push',data=json.dumps({'to':dest,'messages':[{'type':'text','text':r['body']}]}).encode(),headers={'Authorization':'Bearer '+token,'Content-Type':'application/json','X-Line-Retry-Key':r['retry_key']},method='POST')
 try:
  with urllib.request.urlopen(req,timeout=15) as response:response.read()
  return '成功（LINE受付済み）',''
 except urllib.error.HTTPError as e:
  if e.code==409 and e.headers.get('x-line-accepted-request-id'):return '成功（LINE受付済み）',''
  return '失敗',f'LINE HTTP {e.code}'
 except (OSError,ValueError):return '要確認','通信結果を確認できませんでした。自動再送は行いません。'

def run(connect,lock):
 # An interrupted request may already have reached LINE. Never resend blindly.
 with lock:
  with connect() as c:c.execute("UPDATE logistics_messages SET status='要確認',error='サーバー再起動時に送信途中でした。' WHERE status='sending'")
 while True:
  try:
   with lock:
    with connect() as c:schedule(c);job=claim(c)
   if job:
    status,error=deliver(job)
    with lock:
     with connect() as c:c.execute('UPDATE logistics_messages SET status=?,sent=?,error=? WHERE id=?',(status,L.stamp(),error,job[0]['id']))
  except Exception as e:print('配車・撮影通知の待機:',type(e).__name__,flush=True)
  time.sleep(10)
