"""Private U15アドバンス school reports with versioned administrator-defined fields."""
import json, secrets, datetime
import admin_access, scheduling, submission_files

def exam_numbers(values):
 if not isinstance(values,dict):raise ValueError('点数・順位を確認してください。')
 result={}
 for key in ('score','maximum','rank','participants'):
  v=values.get(key,'')
  if v in ('',None):result[key]=None;continue
  if isinstance(v,bool) or not str(v).isascii() or not str(v).isdigit() or not (0 if key=='score' else 1)<=int(v)<=100000:raise ValueError('点数は0以上、満点・順位・人数は1以上の整数で入力してください。')
  result[key]=int(v)
 if result['score'] is not None and result['maximum'] is not None and result['score']>result['maximum']:raise ValueError('点数が満点を超えています。')
 if result['rank'] is not None and result['participants'] is not None and result['rank']>result['participants']:raise ValueError('順位が受験人数を超えています。')
 return result

def init(c):
 c.execute('CREATE TABLE IF NOT EXISTS school_reports(id TEXT PRIMARY KEY,user_id TEXT,body TEXT,revision INTEGER)')
def eligible(c,u):
 if not u or u['role']!='member':return False
 r=c.execute('SELECT categories FROM member_categories JOIN users ON users.id=user_id WHERE user_id=? AND active=1',(u['id'],)).fetchone()
 return bool(r and scheduling.categories(r[0]) & {'U15アドバンス'})
def manager(u,write=False):return admin_access.can(u,'school-reports',write)
def template(c):
 r=c.execute("SELECT value FROM meta WHERE key='school_report_template'").fetchone()
 if r:return json.loads(r[0])
 return {'revision':1,'subjects':[{'id':str(i),'label':v} for i,v in enumerate(['国語','社会','数学','理科','音楽','美術','保健体育','技術・家庭','英語'])],'criteria':[{'id':'rating','label':'評定','options':['5','4','3','2','1']},*({'id':str(i),'label':v,'options':['A','B','C']} for i,v in enumerate(['知識・技能','思考・判断・表現','主体的に学習に取り組む態度']))]}
def read(c,u):
 if not (manager(u) or eligible(c,u)):return {'available':False,'rows':[]}
 rows=[]
 for r in c.execute('SELECT s.*,u.name FROM school_reports s JOIN users u ON u.id=s.user_id ORDER BY s.rowid DESC'):
  if manager(u) or r['user_id']==u['id']:rows.append({**json.loads(r['body']),'id':r['id'],'user_id':r['user_id'],'name':r['name'],'revision':r['revision'],'files':submission_files.listing(c,'school_report',r['id'])})
 return {'available':True,'template':template(c),'rows':rows}
def save(c,u,d):
 if d.get('action')=='template':
  if not manager(u,True):raise PermissionError('管理者のみ項目を編集できます。')
  old=template(c)
  if d.get('revision')!=old['revision']:raise ValueError('項目が更新されています。開き直してください。')
  value={'revision':old['revision']+1}
  for key in ('subjects','criteria'):
   items=d.get(key)
   if not isinstance(items,list) or not 1<=len(items)<=30:raise ValueError('教科・評価項目は各1〜30件です。')
   cleaned=[]
   for item in items:
    label=str(item.get('label','')).strip();ident=str(item.get('id') or secrets.token_hex(8))
    if not label or len(label)>80 or not ident.isalnum():raise ValueError('項目名・IDを確認してください。')
    entry={'id':ident,'label':label}
    if key=='criteria':
     opts=item.get('options')
     if not isinstance(opts,list) or not 1<=len(opts)<=10 or any(not isinstance(x,str) or not x.strip() or len(x)>20 for x in opts) or len(set(opts))!=len(opts):raise ValueError('選択肢は重複しない1〜10個を指定してください。')
     entry['options']=opts
    cleaned.append(entry)
   if len({x['id'] for x in cleaned})!=len(cleaned):raise ValueError('項目IDが重複しています。')
   value[key]=cleaned
  c.execute('INSERT OR REPLACE INTO meta VALUES(?,?)',('school_report_template',json.dumps(value,ensure_ascii=False)));return
 if not eligible(c,u):raise PermissionError('U15アドバンスの会員のみ提出できます。')
 old=c.execute('SELECT * FROM school_reports WHERE id=?',(d.get('id',''),)).fetchone()
 if d.get('id') and not old:raise ValueError('提出が見つかりません。')
 if old and old['user_id']!=u['id']:raise PermissionError('本人の成績報告のみ編集できます。')
 if old and old['revision']!=d.get('revision'):raise ValueError('提出内容が更新されています。開き直してください。')
 t=json.loads(old['body'])['template'] if old else template(c)
 if d.get('template_revision')!=t['revision']:raise ValueError('項目が更新されています。開き直してください。')
 kind=d.get('kind','report')
 if kind not in ('report','exam') or (old and json.loads(old['body']).get('kind','report')!=kind):raise ValueError('報告の種類を確認してください。')
 period=str(d.get('period','')).strip();answers=d.get('answers',{})
 if not period or len(period)>80 or not isinstance(answers,dict):raise ValueError('年度・学期を入力してください。')
 clean={}
 for s in t['subjects'] if kind=='report' else []:
  clean[s['id']]={}
  values=answers.get(s['id'],{})
  if not isinstance(values,dict):raise ValueError('評価を確認してください。')
  for q in t['criteria']:
   value=values.get(q['id'],'')
   if value not in ['',*q['options']]:raise ValueError('評価は選択肢から選んでください。')
   clean[s['id']][q['id']]=value
 uploads=d.get('uploads',[])
 totals={}
 if kind=='exam':
  clean={s['id']:exam_numbers(answers.get(s['id'],{})) for s in t['subjects']}
  totals=exam_numbers(d.get('totals',{}))
  if not any(row[k] is not None for row in [*clean.values(),totals] for k in ('score','rank')):raise ValueError('点数または順位を入力してください。')
 elif not uploads and not (old and submission_files.listing(c,'school_report',old['id'])) and not any(v for row in clean.values() for v in row.values()):raise ValueError('通知表を添付するか、評価を入力してください。')
 if d.get('confirmed') is not True:raise ValueError('入力・読み取り結果を確認してください。')
 body={'kind':kind,'period':period,'answers':clean,'totals':totals,'template':t,'updated':datetime.datetime.now().isoformat(timespec='seconds')}
 rid=old['id'] if old else secrets.token_hex(16)
 if old:c.execute('UPDATE school_reports SET body=?,revision=revision+1 WHERE id=?',(json.dumps(body,ensure_ascii=False),rid))
 else:c.execute('INSERT INTO school_reports VALUES(?,?,?,1)',(rid,u['id'],json.dumps(body,ensure_ascii=False)))
 submission_files.add(c,'school_report',rid,uploads)
