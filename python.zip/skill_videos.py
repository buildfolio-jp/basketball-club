"""Training videos with the same result-view/edit grants as match videos."""
import datetime,re,secrets
from urllib.parse import urlparse,parse_qs
import admin_access,scheduling
GROUPS=['男子A','男子B','女子A','女子B','U15A','U15B']
def init(c):c.execute('CREATE TABLE IF NOT EXISTS skill_videos(id TEXT PRIMARY KEY,title TEXT,date TEXT,group_name TEXT,note TEXT,video TEXT,revision INTEGER)')
def read(c,u):
 if not u:return []
 if u['role']=='admin' and not admin_access.can(u,'results'):return []
 if u['role'] not in ('member','coach','admin'):return []
 own=c.execute('SELECT categories FROM member_categories WHERE user_id=?',(u['id'],)).fetchone()
 cats=scheduling.categories(own[0]) if own else set()
 return [dict(r) for r in c.execute('SELECT * FROM skill_videos ORDER BY date DESC,rowid DESC') if u['role']!='member' or r['group_name']=='全員' or r['group_name'] in cats]
def save(c,u,d):
 if not admin_access.can(u,'results',True):raise PermissionError('試合動画と同じ編集権限が必要です。')
 rid=d.get('id','');old=c.execute('SELECT * FROM skill_videos WHERE id=?',(rid,)).fetchone() if rid else None
 if rid and (not old or old['revision']!=d.get('revision')):raise ValueError('動画が更新されています。開き直してください。')
 if d.get('delete'):
  if not old:raise ValueError('動画が見つかりません。')
  c.execute('DELETE FROM skill_videos WHERE id=?',(rid,));return
 title=str(d.get('title','')).strip();note=str(d.get('note','')).strip();date=str(d.get('date',''));group=d.get('group_name');video=str(d.get('video','')).strip()
 try:datetime.date.fromisoformat(date)
 except ValueError:raise ValueError('日付を確認してください。')
 if not title or len(title)>120 or len(note)>10000 or group not in ['全員']+GROUPS:raise ValueError('タイトル・対象カテゴリー・説明を確認してください。')
 url=urlparse(video);host=(url.hostname or '').lower();vid=url.path.strip('/') if host=='youtu.be' else (parse_qs(url.query).get('v',[''])[0] or url.path.rstrip('/').split('/')[-1])
 if url.scheme!='https' or host not in ('youtu.be','youtube.com','www.youtube.com','m.youtube.com','www.youtube-nocookie.com') or not re.fullmatch(r'[A-Za-z0-9_-]{11}',vid):raise ValueError('YouTube動画のURLを入力してください。')
 c.execute('INSERT OR REPLACE INTO skill_videos VALUES(?,?,?,?,?,?,?)',(rid or secrets.token_hex(12),title,date,group,note,'https://www.youtube.com/watch?v='+vid,(old['revision']+1) if old else 1))
