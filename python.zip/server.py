import coach_scope,score_resources
"""CHEETAHS local demo. Bind to loopback only; not a production server."""
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from http.cookies import SimpleCookie
import sqlite3, json, hashlib, secrets, time, threading, subprocess, os, mimetypes, base64, re
from excel_export import write_workbook
import shop,upload_staging
import concurrency
import school_year,enrollment
import staff_activity
import local_members,member_workbook
import fee_ledger
import credentials
import note_templates
import basket_notes
import attendance_rates,trial_reviews
import staff_intro
import staff_access
import report_templates
import coach_registration
import demo_registration
import venues,equipment_master,choice_masters
import event_logistics, logistics_worker, skill_videos
import member_progress
import receipts
import category_migration
import staff_attendance
import school_reports
import accounts, admin_access, accounting, conditioning, worksheets, submission_files, finance_reports
import seo, importlib, club_portal, scheduling, local_fees, game_stats, schedule_documents, announcement_reads, surveys, family_payments, fee_adjustments
import billing_plan, event_briefings, fee_collection
import withdrawals, sheet_sync
from urllib.parse import urlparse,parse_qs

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'data'
DATA.mkdir(exist_ok=True)
DB = DATA / 'club.sqlite3'
LOCK = threading.RLock()
SESSIONS = {}
FAILURES = {}
NODE = '/Users/tomomi/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node'

def conn():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def password(p, salt=None):
    salt = salt or secrets.token_hex(16)
    return salt + ':' + hashlib.pbkdf2_hmac('sha256', p.encode(), salt.encode(), 260000).hex()

def rows(c, q, args=()): return [dict(r) for r in c.execute(q, args)]

def init():
    with conn() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,name TEXT,grade TEXT,role TEXT,hash TEXT,active INTEGER DEFAULT 1);
        CREATE TABLE IF NOT EXISTS content(id INTEGER PRIMARY KEY CHECK(id=1), value TEXT);
        CREATE TABLE IF NOT EXISTS events(id TEXT PRIMARY KEY,title TEXT,date TEXT,time TEXT,place TEXT,kind TEXT,group_name TEXT,note TEXT);
        CREATE TABLE IF NOT EXISTS reports(user_id TEXT,event_id TEXT,condition INTEGER,sleep REAL,note TEXT,attendance TEXT,actual TEXT DEFAULT '',updated TEXT,PRIMARY KEY(user_id,event_id));
        CREATE TABLE IF NOT EXISTS results(id TEXT PRIMARY KEY,date TEXT,opponent TEXT,ours INTEGER,theirs INTEGER,group_name TEXT,note TEXT,video TEXT);
        CREATE TABLE IF NOT EXISTS trials(id TEXT PRIMARY KEY,event_id TEXT,name TEXT,grade TEXT,contact TEXT,note TEXT,created TEXT);
        CREATE TABLE IF NOT EXISTS trial_reviews(trial_id TEXT PRIMARY KEY,reviewed_by TEXT,reviewed_at TEXT);
        CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY,value TEXT);
        CREATE TABLE IF NOT EXISTS member_families(user_id TEXT PRIMARY KEY,family_id TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS new_seen(user_id TEXT,item_key TEXT,PRIMARY KEY(user_id,item_key));
        ''')
        accounts.init(c)
        coach_registration.init(c)
        event_logistics.init(c)
        skill_videos.init(c)
        school_year.init(c)
        staff_activity.init(c)
        local_members.init(c)
        local_fees.init(c)
        game_stats.init(c)
        score_resources.init(c)
        schedule_documents.init(c)
        announcement_reads.init(c)
        trial_columns={r[1] for r in c.execute('PRAGMA table_info(trials)')}
        for column in ('parent_name','phone','contact_type','email','line_id'):
            if column not in trial_columns:c.execute(f"ALTER TABLE trials ADD COLUMN {column} TEXT DEFAULT ''")
        c.execute("UPDATE trials SET email=contact WHERE contact_type='email' AND email=''")
        c.execute("UPDATE trials SET line_id=contact WHERE contact_type='line' AND line_id=''")
        c.execute('CREATE TABLE IF NOT EXISTS login_sessions(token_hash TEXT PRIMARY KEY,user_id TEXT,expires REAL)')
        club_portal.init(c)
        fee_ledger.init(c)
        surveys.init(c)
        shop.init(c)
        scheduling.init(c)
        event_briefings.init(c)
        venues.init(c)
        equipment_master.init(c)
        choice_masters.init(c)
        if not c.execute('SELECT 1 FROM content').fetchone():
            content={'name':'三木　SHINING CHEETAHS','subname':'ミキシャイニングチーターズ バスケットボールクラブ','headline':'夢中になれる。\n仲間と、強くなる。','intro':'一歩踏み出す勇気も、仲間を想う気持ちも。\nバスケットボールで、コートの先につながる力を。','philosophy':'「できた！」を重ねて、自分を信じる力に。勝ち負けだけではなく、挑戦すること、仲間を尊重すること、自分で考えることを大切にしています。','recruit':'年長〜中学3年生の仲間を募集中。初めてボールに触れる子も、もっと上手くなりたい子も。まずは体験会で、一緒にバスケを楽しもう。','place':'小学校体育館','address':'詳しくは申込後にお伝えいたします。','practice':'年長・小学生：土曜日 9:00〜11:00 ／ 中学生：水曜日 19:00〜','equipment':'体育館シューズ・飲み物・タオル・動きやすい服装','instagram':'https://www.instagram.com/shiningcheetahs/','line':'','hero':'','gallery':'','gallery_caption':'いつもの練習から、一歩ずつ。','notice':'9月の体験会・新メンバー募集を開始しました。','accent':'#ffe04a'}
            content.update(hero='/uploads/00000000000000000000000000000002.jpg',gallery='/uploads/00000000000000000000000000000003.jpg',gallery_caption='公式Instagramより：コートで挑戦し、仲間と成長する。',address='詳しくは申込後にお伝えいたします。')
            c.execute('INSERT INTO content VALUES(1,?)',(json.dumps(content,ensure_ascii=False),))
            for uid,name,grade,role,pw in [('member01','青木 はると','小学5年','member','Cheetahs123!'),('member02','佐藤 ひなた','中学1年','member','Cheetahs123!'),('coach01','田中 コーチ','スタッフ','coach','Coach123!'),('admin01','管理者','運営','admin','Admin123!')]:
                c.execute('INSERT INTO users VALUES(?,?,?,?,?,1)',(uid,name,grade,role,password(pw)))
                if role=='member':c.execute('INSERT OR IGNORE INTO member_categories VALUES(?,?)',(uid,'U15' if grade.startswith('中学') else 'U12'))
            for e in [('e1','はじめてのバスケ体験会','2026-09-19','09:00〜11:00','小学校体育館','体験会','年長・小学生','初心者歓迎。保護者の見学もできます。'),('e2','U15 チーム練習','2026-09-23','19:00〜','小学校体育館','練習','中学生','基礎練習・チームディフェンス'),('e3','秋のバスケ体験会','2026-09-26','09:00〜11:00','小学校体育館','体験会','年長・小学生','バスケットボールの貸し出しがあります。'),('e4','U12 チーム練習','2026-09-19','13:00〜15:00','小学校体育館','練習','小学生','ボールハンドリング・ミニゲーム'),('e5','練習試合 vs EAST','2026-09-27','09:00〜13:00','総合スポーツセンター','試合','小中学生','8:45 現地集合')]:
                c.execute('INSERT INTO events VALUES(?,?,?,?,?,?,?,?)',e)
            for eid,date in [('e1-junior','2026-09-19'),('e3-junior','2026-09-26')]:
                c.execute('INSERT INTO events VALUES(?,?,?,?,?,?,?,?)',(eid,'中学生 バスケ体験会',date,'19:00〜','小学校体育館','体験会','中学生','詳しくは申込後にお伝えいたします。'))
            c.execute('INSERT INTO results VALUES(?,?,?,?,?,?,?,?)',('r1','2026-09-13','EAST JUNIORS',48,42,'女子U12','最後まで声をかけ合い、全員で走りきりました。',''))
            for day,opponent,ours,theirs in [('05','NORTH STARS',36,32),('06','WEST WINGS',40,44),('12','SOUTH HOOPS',52,46)]:
                c.execute('INSERT INTO results VALUES(?,?,?,?,?,?,?,?)',('sample-result-sep'+day,'2026-09-'+day,opponent+'（サンプル）',ours,theirs,{'05':'男子A','06':'男子B','12':'女子U９'}[day],'表示確認用の架空の試合です。',''))
            for result in [('sample-result-u15a', '2026-09-20', 'BLUE STARS（サンプル）', 62, 54, 'U15アドバンス', '表示確認用の架空の試合です。', 'https://www.youtube.com/watch?v=U6wjx5TxM4M'), ('sample-result-u15b', '2026-09-21', 'GREEN HOOPS（サンプル）', 38, 42, 'U15ベーシック', '表示確認用の架空の試合です。', 'https://www.youtube.com/watch?v=U6wjx5TxM4M')]:
                c.execute('INSERT INTO results VALUES(?,?,?,?,?,?,?,?)',result)
            c.execute('INSERT INTO event_details VALUES(?,?)',('e4','https://www.google.com/maps?q=34.7968,134.9902'))
            c.execute("UPDATE results SET video=? WHERE video=''",('https://www.youtube.com/watch?v=U6wjx5TxM4M',))
        c.execute("INSERT OR IGNORE INTO event_details SELECT id,'https://www.google.com/maps?q=34.7968,134.9902' FROM events")
        c.execute("INSERT OR IGNORE INTO member_school_year SELECT id,?,grade FROM users WHERE role='member'",(school_year.year(),))
        accounts.ensure_invites(c)
        submission_files.init(c)
        staff_intro.init(c)
        finance_reports.init(c)
        worksheets.init(c)
        accounting.init(c)
        staff_access.init_officers(c)
        conditioning.init(c)
        attendance_rates.init(c)
        trial_reviews.init(c)
        basket_notes.init(c)
        admin_access.init(c)
        if not c.execute("SELECT 1 FROM meta WHERE key='demo_admin2_added'").fetchone():
            if not c.execute("SELECT 1 FROM users WHERE id='adimin2'").fetchone():
                c.execute("INSERT INTO users VALUES('adimin2','管理者2（デモ）','運営','admin',?,1)",(password('Admin2Demo123!'),))
                grants={'members':'view','staff-members':'view','schedule':'view','attendance-list':'edit','billing-settings':'view','staff-approvals':'view','results':'edit','announcement-admin':'view','survey-admin':'view','shop-admin':'view','board-admin':'view','admin-guide':'view'}
                c.execute("INSERT INTO admin_access VALUES('adimin2',2,?)",(json.dumps(grants),))
            c.execute("INSERT INTO meta VALUES('demo_admin2_added','1')")
        staff_access.init(c)
        category_migration.init(c)
        staff_attendance.init(c)
        school_reports.init(c)
        withdrawals.init(c)
        receipts.init(c)
        sheet_sync.init(c)

def export_excel():
    with conn() as c:
        users=rows(c,"SELECT u.id,u.name,u.grade,u.role,u.active,COALESCE(f.family_id,'') AS family_id FROM users u LEFT JOIN member_families f ON f.user_id=u.id ORDER BY u.role,u.id")
        profiles={r['user_id']:r['kind'] for r in c.execute('SELECT * FROM staff_profiles')}
        schools={r['user_id']:r['school'] for r in c.execute('SELECT * FROM member_schools')}
        for person in users:
            person['school']=schools.get(person['id'],'');enrollment.attach(c,person)
        for person in users:person['staff_kind']=profiles.get(person['id'],'コーチ' if person['role']=='coach' else 'スタッフ')
        reports=rows(c,'SELECT r.*,u.name,e.title,e.date FROM reports r JOIN users u ON u.id=r.user_id JOIN events e ON e.id=r.event_id ORDER BY e.date,u.id')
        payload={'users':users,'reports':reports,'events':rows(c,'SELECT * FROM events ORDER BY date'),'results':rows(c,'SELECT * FROM results ORDER BY date'),'trials':rows(c,'SELECT t.*,r.reviewed_by,r.reviewed_at,u.name AS reviewer_name FROM trials t LEFT JOIN trial_reviews r ON r.trial_id=t.id LEFT JOIN users u ON u.id=r.reviewed_by ORDER BY t.created')}
        payload['staff_activity']=staff_activity.read(c)
        payload['shop_orders']=shop.orders(c,{'role':'admin'})
        payload['lunch_answers']=surveys.read(c,{'role':'admin'})['answers']
        payload['announcement_reads']=announcement_reads.read(c,{'role':'admin'})
        payload['game_stats']=game_stats.read(c,{'role':'admin'})['rows']
        fee_ledger.sync(c,club_portal.billing_settings(c))
        payload['fee_ledger']=fee_ledger.read(c)
        payload['fee_collection']=fee_collection.read(c,club_portal.billing_settings(c))
        payload['billing']=club_portal.billing_export(c)
        payload['fee_adjustments']=fee_adjustments.rows(c)
        payload['billing_plan']=billing_plan.read(c)
        venues.enrich(c,payload['events'])
        payload['venues']=venues.listing(c)
        payload['event_briefings']=event_briefings.read(c,{'role':'admin'})
        payload['family_payment_receipts']=[{**dict(r),'body':json.loads(r['body'])} for r in c.execute('SELECT * FROM family_payment_receipts')]
        payload['family_payment_methods']=rows(c,'SELECT * FROM family_payment_methods')
        details={r['event_id']:r['map_url'] for r in c.execute('SELECT * FROM event_details')}
        for event in payload['events']:event['map_url']=details.get(event['id'],'')
        payload['fee_amounts']=rows(c,'SELECT * FROM fee_amounts ORDER BY kind,target,cycle')
        payload['attendance_meta']=rows(c,'SELECT * FROM attendance_meta')
    (DATA/'export.json').write_text(json.dumps(payload,ensure_ascii=False))
    try:
        write_workbook(payload,DATA/'チーターズ管理.xlsx')
        status={'ok':True,'updated':time.strftime('%Y-%m-%d %H:%M:%S'),'file':'data/チーターズ管理.xlsx'}
    except Exception as e:
        print('Excel export:',e,flush=True)
        status={'ok':False,'updated':time.strftime('%Y-%m-%d %H:%M:%S'),'message':'記録は保存済みです。Excel更新に失敗しました。再同期してください。'}
    with conn() as c: c.execute('INSERT OR REPLACE INTO meta VALUES(?,?)',('excel',json.dumps(status,ensure_ascii=False)))
    return status

class Handler(BaseHTTPRequestHandler):
    def send(self,value,status=200,headers=None):
        b=json.dumps(value,ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        if getattr(self,'renew_session_cookie',None) and 'Set-Cookie' not in (headers or {}):self.send_header('Set-Cookie',self.renew_session_cookie)
        for k,v in (headers or {}).items(): self.send_header(k,v)
        self.end_headers();self.wfile.write(b)
    def user(self,selected_id=None):
        cookies=SimpleCookie()
        try: cookies.load(self.headers.get('Cookie',''))
        except: return None
        token=cookies.get('club_session')
        s=SESSIONS.get(token.value if token else '')
        if not s and token:
            with conn() as c:
                saved=c.execute('SELECT user_id,expires FROM login_sessions WHERE token_hash=?',(hashlib.sha256(token.value.encode()).hexdigest(),)).fetchone()
                if saved:s=(saved[0],saved[1])
        if not s or s[1]<time.time(): return None
        with conn() as c:
            subject=accounts.identity(c,s[0])
            u=c.execute('SELECT id,name,grade,role FROM users WHERE id=? AND active=1',(subject,)).fetchone()
            if not u:return None
            u={**dict(u),'login_display':credentials.display(c,s[0]),'login_id':s[0],'needs_profile':False}
            if token and s[1]<time.time()+14400:
                expires=time.time()+28800
                c.execute('UPDATE login_sessions SET expires=? WHERE token_hash=?',(expires,hashlib.sha256(token.value.encode()).hexdigest()))
                SESSIONS[token.value]=(s[0],expires)
                self.renew_session_cookie=f'club_session={token.value}; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800'
            if u['role']=='accountant' and not accounting.active(c,u['id']):return None
            if u['role']=='accountant':u=staff_access.officer_effective(c,u)
            if u['role']=='coach':u=staff_access.effective(c,u)
            if u['role']=='admin' and not u.get('delegated_coach') and not u.get('delegated_officer'):u.update(admin_access.profile(c,u['id']))
            if u['role']!='member':return u
            family=c.execute('SELECT family_id FROM member_families WHERE user_id=?',(u['id'],)).fetchone()
            children=rows(c,"SELECT u.id,u.name,u.grade FROM users u JOIN member_families f ON f.user_id=u.id WHERE f.family_id=? AND u.role='member' AND u.active=1 ORDER BY u.id",(family[0],)) if family else [{k:u[k] for k in ('id','name','grade')}]
            chosen=selected_id or self.headers.get('X-Club-Member') or u['id']
            child=next((v for v in children if v['id']==chosen),None)
            if not child:return None
            cat=c.execute('SELECT categories FROM member_categories WHERE user_id=?',(child['id'],)).fetchone()
            return {**child,'role':'member','login_id':s[0],'needs_profile':u['needs_profile'],'family_members':children,'categories':cat[0] if cat else 'U12'}
    def do_GET(self):
        with LOCK:
            with conn() as c:
                    enrollment.sync_due(c)
                    changed=school_year.sync(c)
            if changed:export_excel()
            self.read_get()
    def read_get(self):
        with conn() as c:enrollment.sync_due(c)
        path=urlparse(self.path).path
        if path=='/api/score_resource_file':
            u=self.user();q=parse_qs(urlparse(self.path).query)
            with conn() as c:r=score_resources.file(c,u,q.get('id',[''])[0])
            if not r:self.send({'error':'閲覧権限がありません。'},403);return
            self.send_response(200);self.send_header('Content-Type','application/pdf');self.send_header('Content-Disposition',('attachment' if q.get('download',[''])[0]=='1' else 'inline')+'; filename="score-sheet.pdf"');self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(r['content']);return
        if path=='/api/receipt_document':
            q=parse_qs(urlparse(self.path).query)
            with conn() as c:raw=receipts.document(c,self.user(q.get('member',[''])[0]),q.get('id',[''])[0])
            self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8');self.send_header('Cache-Control','private, no-store');self.end_headers();self.wfile.write(raw);return
        if path=='/api/withdrawal_document':
            try:
                q=parse_qs(urlparse(self.path).query);u=self.user(q.get('member',[''])[0])
                with conn() as c:mime,raw,name=withdrawals.document(c,u,q.get('id',[''])[0],q.get('kind',['template'])[0])
                self.send_response(200);self.send_header('Content-Type',mime);self.send_header('Content-Disposition','attachment; filename="'+name+'"');self.send_header('Cache-Control','private, no-store');self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(raw)
            except PermissionError as e:self.send({'error':str(e)},403)
            except ValueError as e:self.send({'error':str(e)},400)
            return
        if path.startswith('/api/'):
            actor=self.user()
            if actor and actor['role']=='accountant' and path not in ('/api/me','/api/data','/api/public','/api/submission_file') and not path.startswith('/api/finance_'):
                self.send({'error':'会計専用アカウントでは利用できません。'},403);return
            try:
                with conn() as c:admin_access.check(c,self.user(),path.split('/')[-1])
            except PermissionError as e:self.send({'error':str(e)},403);return
        # Local demo: pick up public copy/template edits without restarting sessions.
        if path in ('/','/api/public'):
            with LOCK: importlib.reload(seo)
        if path in ('/api/logistics','/api/logistics_export'):
            u=self.user()
            if not u:self.send({'error':'ログインしてください。'},401);return
            q=parse_qs(urlparse(self.path).query);eid=q.get('event_id',[''])[0];kind=q.get('kind',['ride'])[0]
            try:
                with conn() as c:
                    coach_scope.check(c,u,{'event_id':eid})
                    if path.endswith('_export'):raw=event_logistics.export_messages(c,u,eid)
                    else:self.send(event_logistics.state(c,u,eid,kind));return
                self.send_response(200);self.send_header('Content-Type','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');self.send_header('Content-Disposition','attachment; filename="line-history.xlsx"');self.end_headers();self.wfile.write(raw)
            except PermissionError as e:self.send({'error':str(e)},403)
            except ValueError as e:self.send({'error':str(e)},400)
            return
        if path=='/robots.txt':
            self.send_response(200);self.send_header('Content-Type','text/plain; charset=utf-8');self.end_headers();self.wfile.write(b'User-agent: *\nDisallow: /\n');return
        if path=='/':
            with conn() as c:
                content=seo.public_content(json.loads(c.execute('SELECT value FROM content').fetchone()[0]))
                events=rows(c,"SELECT * FROM events WHERE kind='体験会' ORDER BY date")
            html=seo.render_document((ROOT/'public'/'index.html').read_text(),content,events)
            self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8');self.send_header('Cache-Control','no-store');self.send_header('X-Robots-Tag','noindex, nofollow');self.end_headers();self.wfile.write(html.encode());return
        if re.fullmatch(r'/uploads/[a-f0-9]{32}\.(jpg|png|webp)',path):
            f=ROOT/'public'/path.lstrip('/')
            if not f.is_file(): self.send({'error':'画像が見つかりません。'},404);return
            self.send_response(200);self.send_header('Content-Type',mimetypes.guess_type(f)[0]);self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(f.read_bytes());return
        if path=='/api/choice_master_excel':
            if not admin_access.full(self.user()):raise PermissionError('管理者のみダウンロードできます。')
            with conn() as c:raw=choice_masters.workbook(c,(ROOT/'public/member-registration.xlsx').read_bytes())
            self.send_response(200);self.send_header('Content-Type','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');self.send_header('Content-Disposition','attachment; filename=member-master.xlsx');self.end_headers();self.wfile.write(raw);return
        if path=='/api/choice_masters':
            if not self.user():self.send({'error':'ログインしてください。'},403);return
            with conn() as c:self.send({'choice_masters':choice_masters.read(c),'equipment_master':equipment_master.read(c),'venues':venues.listing(c)})
            return
        if path=='/api/venues':
            if not self.user():raise PermissionError('ログインしてください。')
            with conn() as c:self.send({'venues':venues.listing(c),'schedule_titles':venues.titles(c)})
            return
        if path=='/api/registration_context':
            self.send({'demo':demo_registration.allowed(self.user())});return
        if path=='/api/public':
            with conn() as c:
                content=seo.public_content(json.loads(c.execute('SELECT value FROM content').fetchone()[0]))
                self.send({'trial_reviews':trial_reviews.public(c),'staff_intros':staff_intro.read(c,True),'account_mail_ready':accounts.mail_ready(),'content':content,'faq':seo.questions(content),'events':rows(c,"SELECT * FROM events WHERE kind='体験会' ORDER BY date")})
            return
        if path=='/api/me': self.send({'user':self.user()});return
        if path=='/api/event_attachment':
            q=parse_qs(urlparse(self.path).query);u=self.user(q.get('member',[''])[0])
            if not u:self.send({'error':'ログインしてください。'},401);return
            with conn() as c:attachment=event_briefings.file(c,u,q.get('id',[''])[0])
            if not attachment:self.send({'error':'閲覧権限がありません。'},403);return
            ext={'application/pdf':'pdf','image/jpeg':'jpg','image/png':'png','image/webp':'webp'}[attachment['mime']]
            self.send_response(200);self.send_header('Content-Type',attachment['mime']);self.send_header('Content-Disposition',('attachment' if q.get('download',[''])[0]=='1' else 'inline')+'; filename="activity.'+ext+'"');self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(attachment['content']);return
        if path=='/api/board_attachment':
            if not self.user():self.send({'error':'ログインしてください。'},401);return
            q=parse_qs(urlparse(self.path).query)
            with conn() as c:f=c.execute("SELECT f.* FROM board_files f JOIN portal_entries e ON e.id=f.entry_id JOIN users u ON u.id=e.user_id WHERE f.id=? AND e.kind='board' AND u.role IN ('coach','admin')",(q.get('id',[''])[0],)).fetchone()
            if not f:self.send({'error':'添付が見つかりません。'},404);return
            ext={'text/csv':'csv','application/pdf':'pdf','image/jpeg':'jpg','image/png':'png','image/webp':'webp'}[f['mime']]
            self.send_response(200);self.send_header('Content-Type',f['mime']);self.send_header('Content-Disposition',('attachment' if ext=='csv' or q.get('download',[''])[0]=='1' else 'inline')+'; filename="board.'+ext+'"');self.send_header('Cache-Control','private, no-store');self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(f['content']);return
        if path=='/api/announcement_attachment':
            if not self.user():self.send({'error':'ログインしてください。'},401);return
            q=parse_qs(urlparse(self.path).query)
            with conn() as c:f=c.execute("SELECT f.* FROM announcement_files f JOIN portal_items p ON p.id=f.entry_id WHERE f.id=? AND p.kind='announcements'",(q.get('id',[''])[0],)).fetchone()
            if not f:self.send({'error':'添付が見つかりません。'},404);return
            ext={'text/csv':'csv','application/pdf':'pdf','image/jpeg':'jpg','image/png':'png','image/webp':'webp'}[f['mime']]
            self.send_response(200);self.send_header('Content-Type',f['mime']);self.send_header('Content-Disposition',('attachment' if ext=='csv' or q.get('download',[''])[0]=='1' else 'inline')+'; filename="notice.'+ext+'"');self.send_header('Cache-Control','private, no-store');self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(f['content']);return
        if path=='/api/shop_image':
            if not self.user():self.send({'error':'ログインしてください。'},401);return
            q=parse_qs(urlparse(self.path).query)
            with conn() as c:photo=c.execute('SELECT * FROM shop_images WHERE id=?',(q.get('id',[''])[0],)).fetchone()
            if not photo:self.send({'error':'写真が見つかりません。'},404);return
            self.send_response(200);self.send_header('Content-Type',photo['mime']);self.send_header('Cache-Control','private, no-store');self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(photo['content']);return
        if path=='/api/schedule_pdf':
            q=parse_qs(urlparse(self.path).query);u=self.user(q.get('member',[''])[0])
            if not u:self.send({'error':'ログインしてください。'},401);return
            with conn() as c:
                document=c.execute('SELECT * FROM schedule_documents WHERE id=?',(q.get('id',[''])[0],)).fetchone()
                if document and u and not schedule_documents.can_read(c,u,document):document=None
            if not document:self.send({'error':'閲覧権限がありません。'},403);return
            self.send_response(200);self.send_header('Content-Type','application/pdf');self.send_header('Content-Disposition',('attachment' if q.get('download',[''])[0]=='1' else 'inline')+'; filename="schedule.pdf"');self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(document['content']);return
        if path=='/api/conditioning_export':
            u=self.user()
            if not conditioning.allowed(u):self.send({'error':'閲覧権限がありません。'},403);return
            q=parse_qs(urlparse(self.path).query);fmt=q.get('format',['csv'])[0]
            if fmt not in ('csv','pdf'):self.send({'error':'形式を確認してください。'},400);return
            with conn() as c:records=coach_scope.filtered(c,u,conditioning.read(c,q.get('member',[''])[0],q.get('date',[''])[0]))
            raw=conditioning.csv_bytes(records) if fmt=='csv' else conditioning.pdf_bytes(records)
            self.send_response(200);self.send_header('Content-Type','text/csv; charset=utf-8' if fmt=='csv' else 'application/pdf');self.send_header('Content-Disposition','attachment; filename="conditioning.'+fmt+'"');self.send_header('Cache-Control','private, no-store');self.end_headers();self.wfile.write(raw);return
        if path.startswith('/api/finance_'):
            try:
                q=parse_qs(urlparse(self.path).query);u=self.user();year=int(q.get('year',[accounting.fiscal_year()])[0])
                with conn() as c:
                    accounting.access(c,u,year)
                    if path=='/api/finance_data':self.send(accounting.read(c,u,year,q.get('account_type',[None])[0]));return
                    if path=='/api/finance_file':
                        f=c.execute('SELECT * FROM accounting_files WHERE id=? AND year=?',(q.get('id',[''])[0],year)).fetchone()
                        if not f:raise ValueError('添付が見つかりません。')
                        raw=f['content'];mime=f['mime'];filename='receipt.'+{'application/pdf':'pdf','image/png':'png','image/jpeg':'jpg','image/webp':'webp','text/csv':'csv'}[mime]
                    elif path=='/api/finance_report':
                        state=accounting.read(c,u,year,q.get('account_type',[None])[0]);fmt=q.get('format',['xlsx'])[0]
                        if fmt not in ('xlsx','pdf'):raise ValueError('形式を確認してください。')
                        raw=accounting.xlsx_bytes(state) if fmt=='xlsx' else accounting.pdf_bytes(state);mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' if fmt=='xlsx' else 'application/pdf';filename=f'accounting-{year}.{fmt}'
                    else:raise ValueError('項目がありません。')
                self.send_response(200);self.send_header('Content-Type',mime);self.send_header('Content-Disposition','attachment; filename="'+filename+'"');self.send_header('Cache-Control','private, no-store');self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(raw);return
            except PermissionError as e:self.send({'error':str(e)},403);return
            except (ValueError,TypeError) as e:self.send({'error':str(e)},400);return
        if path=='/api/review_photo':
            with conn() as c:
                fid=parse_qs(urlparse(self.path).query).get('id',[''])[0]
                row=c.execute("SELECT f.* FROM submission_files f JOIN public_reviews r ON r.id=f.record_id WHERE f.id=? AND f.kind='review' AND r.photo=f.id",(fid,)).fetchone()
                published=c.execute("SELECT 1 FROM public_reviews WHERE photo=? AND status='published'",(fid,)).fetchone()
                if not row or (not published and not admin_access.full(self.user())):self.send({'error':'写真がありません。'},404);return
                self.send_response(200);self.send_header('Content-Type',row['mime']);self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(row['content']);return
        if path=='/api/trial_review_invite':
            try:
                with conn() as c:invite=trial_reviews.invitation(c,parse_qs(urlparse(self.path).query).get('token',[''])[0])
                self.send({'ok':True,'kind':invite['kind']})
            except ValueError as e:self.send({'error':str(e)},400)
            return
        if path in ('/api/attendance_rates','/api/attendance_rates_export'):
            u=self.user()
            if not attendance_rates.allowed(u):self.send({'error':'閲覧権限がありません。'},403);return
            q=parse_qs(urlparse(self.path).query);uid=q.get('member',[''])[0];month=q.get('month',[''])[0];fmt=q.get('format',['csv'])[0]
            with conn() as c:
                rs=coach_scope.filtered(c,u,attendance_rates.read(c,uid,month))
                if path=='/api/attendance_rates':self.send({'rows':rs,'status':attendance_rates.status(c)});return
                if fmt=='xlsx':
                    import tempfile
                    with tempfile.TemporaryDirectory() as folder:
                        file=Path(folder)/'input.xlsx';attendance_rates.workbook(file,coach_scope.filtered(c,u,attendance_rates.records(c,uid,month)));raw=file.read_bytes()
                    mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
                elif fmt=='pdf':raw=attendance_rates.pdf_bytes(rs,month);mime='application/pdf'
                else:fmt='csv';raw=attendance_rates.csv_bytes(rs);mime='text/csv; charset=utf-8'
            self.send_response(200);self.send_header('Content-Type',mime);self.send_header('Content-Disposition','attachment; filename="attendance-rates.'+fmt+'"');self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(raw);return
        if path=='/staff-photo':
            fid=parse_qs(urlparse(self.path).query).get('id',[''])[0]
            with conn() as c:
                r=c.execute("SELECT f.* FROM submission_files f JOIN staff_intros s ON s.id=f.record_id WHERE f.id=? AND f.kind='staff-intro' AND s.published=1",(fid,)).fetchone()
            if not r:self.send({'error':'写真がありません。'},404);return
            self.send_response(200);self.send_header('Content-Type',r['mime']);self.send_header('Cache-Control','no-cache');self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(r['content']);return
        if path=='/api/worksheet_excel':
            import tempfile
            u=self.user(parse_qs(urlparse(self.path).query).get('member',[''])[0])
            with conn() as c:
                if not worksheets.read(c,u)['available']:self.send({'error':'権限がありません。'},403);return
                with tempfile.TemporaryDirectory() as folder:
                    file=Path(folder)/'worksheets.xlsx';worksheets.workbook(c,u,file);raw=file.read_bytes()
            self.send_response(200);self.send_header('Content-Type','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');self.send_header('Content-Disposition','attachment; filename="worksheets.xlsx"');self.send_header('Cache-Control','private, no-store');self.end_headers();self.wfile.write(raw);return
        if path=='/api/submission_file':
            u=self.user(parse_qs(urlparse(self.path).query).get('member',[''])[0]);fid=parse_qs(urlparse(self.path).query).get('id',[''])[0]
            with conn() as c:
                r=c.execute('SELECT * FROM submission_files WHERE id=?',(fid,)).fetchone()
                if not u or not r:self.send({'error':'添付が見つかりません。'},404);return
                if r['kind']=='school_report':allowed=any(w['id']==r['record_id'] for w in school_reports.read(c,u)['rows'])
                elif r['kind']=='worksheet':allowed=any(w['id']==r['record_id'] for w in worksheets.read(c,u)['rows'])
                else:
                    owner=c.execute('SELECT user_id,year FROM finance_reports WHERE id=?',(r['record_id'],)).fetchone()
                    allowed=bool(owner and u['role']=='member' and owner['user_id']==u['id'])
                    if not allowed and owner:
                        try:accounting.access(c,u,owner['year']);allowed=True
                        except PermissionError:pass
                if not allowed:self.send({'error':'閲覧する権限がありません。'},403);return
                self.send_response(200);self.send_header('Content-Type',r['mime']);self.send_header('Content-Disposition','attachment; filename="attachment.'+{'application/pdf':'pdf','image/png':'png','image/jpeg':'jpg','image/webp':'webp'}[r['mime']]+'"');self.send_header('Cache-Control','private, no-store');self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(r['content']);return
        if path=='/api/data':
            u=self.user()
            if not u: self.send({'error':'ログインしてください。'},401);return
            with conn() as c:
                if u['role']=='accountant':self.send({'finance':accounting.read(c,u,accounting.fiscal_year()),'receipts':receipts.read(c,u)});return
                staff=u['role'] in ('coach','admin')
                data={'events':rows(c,'SELECT * FROM events ORDER BY date,time'),'results':rows(c,'SELECT * FROM results ORDER BY date DESC'),'reports':rows(c,'SELECT * FROM reports'+('' if staff else ' WHERE user_id=?'),() if staff else (u['id'],))}
                if u['role']=='admin' and admin_access.can(u,'finance-admin'):data['finance']=accounting.read(c,u,accounting.fiscal_year())
                if u['role']=='member':data['finance_reports']=finance_reports.read(c,u)
                if admin_access.full(u):data['trial_reviews']=trial_reviews.listing(c)
                if admin_access.can(u,'staff-members'):data['staff_intros']=staff_intro.read(c)
                if admin_access.full(u):data['note_templates']=note_templates.read(c)
                data['report_templates']={kind:report_templates.read(c,kind) for kind in report_templates.DEFAULTS}
                data['basket_notes']=basket_notes.read(c,u)
                if u['role']=='member':data['member_progress']=member_progress.read(c,u)
                data['basket_note_statuses']=basket_notes.status_rows(c) if staff else []
                data['worksheets']=worksheets.read(c,u)
                if conditioning.allowed(u):data['conditioning_status']=conditioning.status(c)
                data['account_self']=accounts.profile(c,u.get('login_id',u['id']))
                if u['role']=='admin':accounts.ensure_invites(c);data['accounts']=accounts.admin_read(c)
                if staff:
                    data.update(users=rows(c,"SELECT u.id,u.name,u.grade,u.role,u.active,COALESCE(f.family_id,'') AS family_id FROM users u LEFT JOIN member_families f ON f.user_id=u.id WHERE NOT EXISTS(SELECT 1 FROM deleted_members dm WHERE dm.user_id=u.id)"),trials=rows(c,'SELECT t.*,r.reviewed_by,r.reviewed_at,u.name AS reviewer_name FROM trials t LEFT JOIN trial_reviews r ON r.trial_id=t.id LEFT JOIN users u ON u.id=r.reviewed_by ORDER BY t.created DESC'))
                    m=c.execute("SELECT value FROM meta WHERE key='excel'").fetchone()
                    data['excel']=json.loads(m[0]) if m else {'ok':False}
                if staff:
                    activity=staff_activity.read(c)
                    data['staff_activity']=activity if u['role']=='admin' and not u.get('delegated_coach') else {k:[r for r in v if r['user_id']==u['id']] for k,v in activity.items()}
                if u['role']=='admin':data['member_input_status']=local_members.status(c)
                if staff:
                    fee_ledger.sync(c,club_portal.billing_settings(c))
                    data['fee_ledger']=fee_ledger.read(c)
                    if u['role']=='admin':data['fee_collection']=fee_collection.read(c,club_portal.billing_settings(c))
                    data['edit_token']=concurrency.capture(c,u['id'])
                data['portal']=club_portal.read(c,u)
                data['new_seen']=[r[0] for r in c.execute('SELECT item_key FROM new_seen WHERE user_id=?',(u['id'],))]
                if staff:data['fee_input_status']=local_fees.status(c)
                else:data['family_billing']=family_payments.read(c,u,club_portal.billing_settings(c))
                if staff:
                    data['fee_adjustments']=fee_adjustments.rows(c)
                    data['billing_plan']=billing_plan.read(c)
                    start,end=family_payments.period(club_portal.billing_settings(c))
                    data['fee_adjustment_periods']={'current':start,'next':fee_adjustments.next_month(end)}
                data['game_stats']=game_stats.read(c,u)
                data['score_resources']=score_resources.read(c,u)
                data['shop']=shop.read(c,u)
                data['surveys']=surveys.read(c,u)
                data['announcement_reads']=announcement_reads.read(c,u)
                data['board_reads']=announcement_reads.read(c,u,board=True)
                if staff:
                    notice_status=c.execute("SELECT value FROM meta WHERE key='announcement_input_status'").fetchone()
                    data['announcement_input_status']=json.loads(notice_status[0]) if notice_status else {}
                data['schedule_documents']=schedule_documents.read(c,u)
                data['scheduling']=scheduling.read(c,u)
                venues.enrich(c,data['events'])
                data['choice_masters']=choice_masters.read(c)
                data['equipment_master']=equipment_master.read(c) if staff else []
                data['venues']=venues.listing(c) if staff else []
                data['schedule_titles']=venues.titles(c) if staff else []
                data['event_briefings']=event_briefings.read(c,u)
                details={r['event_id']:r['map_url'] for r in c.execute('SELECT * FROM event_details')}
                for event in data['events']:event['map_url']=details.get(event['id'],'')
                if staff:
                    cats={r['user_id']:r['categories'] for r in c.execute('SELECT * FROM member_categories')}
                    schools={r['user_id']:r['school'] for r in c.execute('SELECT * FROM member_schools')}
                    profiles={r['user_id']:r['kind'] for r in c.execute('SELECT * FROM staff_profiles')}
                    for person in data['users']:
                        person['school']=schools.get(person['id'],'');enrollment.attach(c,person)
                        if admin_access.full(u) and person['role']=='member':person['registration_contact']={k:v for k,v in accounts.profile(c,person['id']).items() if k in ('parent_name','email','phone')}
                        person['categories']=cats.get(person['id'],'U12' if person['role']=='member' else '')
                        person['staff_kind']=profiles.get(person['id'],'コーチ' if person['role']=='coach' else 'スタッフ')
                else:
                    data['events']=[e for e in data['events'] if scheduling.eligible(c,u['id'],e)]
                if u['role']=='admin':
                    if admin_access.full(u):
                        data['officer_accounts']=staff_access.officer_listing(c);data['coach_registrations']=coach_registration.listing(c);data['admin_accounts']=admin_access.listing(c);data['coach_accounts']=staff_access.listing(c);data['credential_accounts']=credentials.listing(c)
                    else:
                        own_activity=data.get('staff_activity',{})
                        data=admin_access.filtered(data,u)
                        if u.get('delegated_coach'):data['staff_activity']=own_activity;data['users'] += [dict(c.execute('SELECT id,name,grade,role,active FROM users WHERE id=?',(u['id'],)).fetchone())]
                if u['role']=='coach' or (u['role']=='admin' and admin_access.can(u,'members')):data['guardian_contacts']=accounts.guardian_contacts(c,data.get('users',[]))
                data['skill_videos']=skill_videos.read(c,u)
                data['receipts']=receipts.read(c,u)
                data['staff_attendance']=staff_attendance.read(c,u)
                data['school_reports']=school_reports.read(c,u)
                data['withdrawals']=withdrawals.listing(c,u)
                data['private_messages']=withdrawals.messages(c,u)
                if admin_access.full(u):data['sheet_sync']=sheet_sync.status(c)
                data['logistics']=event_logistics.summary(c,u,data.get('events',[]))
                self.send(coach_scope.data(c,u,data))
            return
        if path=='/api/fee-unpaid-excel':
            u=self.user()
            if not u or u['role']!='admin':self.send({'error':'権限がありません。'},403);return
            period=parse_qs(urlparse(self.path).query).get('period',[''])[0]
            with conn() as c:collection=fee_collection.read(c,club_portal.billing_settings(c))
            if period not in [p['start'] for p in collection['periods']]:self.send({'error':'期間を選択してください。'},400);return
            unpaid_rows=[r for r in collection['rows'] if r['start_month']==period and r['collection_status']=='未納入']
            import tempfile
            with tempfile.TemporaryDirectory() as folder:
                file=Path(folder)/'unpaid.xlsx'
                write_workbook({'users':[],'reports':[],'events':[],'results':[],'trials':[],'unpaid_only':True,'fee_collection':{'rows':unpaid_rows}},file)
                content=file.read_bytes()
            self.send_response(200);self.send_header('Content-Type','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');self.send_header('Content-Disposition','attachment; filename="unpaid-'+period+'.xlsx"');self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(content);return
        if path=='/api/excel':
            u=self.user()
            if not u or u['role'] not in ('coach','admin'): self.send({'error':'権限がありません。'},403);return
            if u['role']=='coach' or u.get('delegated_coach'):
                with conn() as c:
                    activity=staff_activity.read(c)
                    payload={'users':[dict(c.execute('SELECT id,name,grade,role,active FROM users WHERE id=?',(u['id'],)).fetchone())],'events':[],'reports':[],'results':[],'trials':[],'staff_activity':{k:[r for r in v if r['user_id']==u['id']] for k,v in activity.items()}}
                import tempfile
                with tempfile.TemporaryDirectory() as folder:
                    file=Path(folder)/'own.xlsx';write_workbook(payload,file);content=file.read_bytes()
                self.send_response(200);self.send_header('Content-Type','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');self.send_header('Content-Disposition','attachment; filename=own-activity.xlsx');self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(content);return
            if u['role']=='admin' and not admin_access.full(u):
                with conn() as c:payload=admin_access.export_payload(c,u)
                import tempfile
                with tempfile.TemporaryDirectory() as folder:
                    limited=Path(folder)/'permitted.xlsx';write_workbook(payload,limited);content=limited.read_bytes()
                self.send_response(200);self.send_header('Content-Type','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');self.send_header('Content-Disposition','attachment; filename=permitted.xlsx');self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(content);return
            file=DATA/'チーターズ管理.xlsx'
            if not file.exists(): self.send({'error':'Excelファイルがまだありません。'},404);return
            self.send_response(200);self.send_header('Content-Type','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');self.send_header('Content-Disposition','attachment; filename="cheetahs.xlsx"');self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(file.read_bytes());return
        allowed={'/choice-masters.js':'choice-masters.js','/member-registration.js':'member-registration.js','/member-registration.xlsx':'member-registration.xlsx','/member-roster.js':'member-roster.js','/receipts.js':'receipts.js','/date-picker.js':'date-picker.js','/staff-attendance.js':'staff-attendance.js','/school-reports.js':'school-reports.js','/withdrawals.js':'withdrawals.js','/event-logistics.js':'event-logistics.js','/event-logistics.css':'event-logistics.css','/uploads.js':'uploads.js','/submissions.js':'submissions.js','/accounting.js':'accounting.js','/details-state.js':'details-state.js','/score-import.js':'score-import.js','/lunch-export.js':'lunch-export.js','/staff-activity.js':'staff-activity.js','/shop.js':'shop.js','/event-details.js':'event-details.js','/schedule.js':'schedule.js','/portal.js':'portal.js','/':'index.html','/accounts.js':'accounts.js','/app.js':'app.js','/style.css':'style.css','/favicon.svg':'favicon.svg','/hero.jpg':'hero.jpg'}
        file=ROOT/'public'/allowed.get(path,'__missing__')
        if path.startswith('/vendor/'):
            candidate=(ROOT/'public'/path.lstrip('/')).resolve()
            if (ROOT/'public'/'vendor').resolve() in candidate.parents:file=candidate
        if not file.is_file(): self.send({'error':'見つかりません。'},404);return
        self.send_response(200);self.send_header('Cache-Control','no-store');self.send_header('Content-Type',mimetypes.guess_type(file)[0] or 'application/octet-stream');self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(file.read_bytes())
    def do_POST(self):
        host=self.headers.get('Host','')
        public_origin=os.environ.get('CHEETAHS_PUBLIC_ORIGIN','')
        allowed_hosts=('127.0.0.1:8765','localhost:8765',urlparse(public_origin).netloc)
        if host not in allowed_hosts or self.headers.get('Origin') not in (None,'http://'+host,public_origin): self.send({'error':'リクエスト元が不正です。'},403);return
        if self.headers.get('Content-Type','').split(';')[0]!='application/json': self.send({'error':'JSONが必要です。'},415);return
        try:
            length=int(self.headers.get('Content-Length',0))
            if not 0<length<(36000000 if urlparse(self.path).path in ('/api/upload_stage','/api/event_briefing','/api/shop_product','/api/portal','/api/finance_entry','/api/finance_batch','/api/worksheet','/api/member_finance_report') else 8000000): raise ValueError('データサイズが不正です。写真は5MB以下にしてください。')
            d=json.loads(self.rfile.read(length))
            if not isinstance(d,dict): raise ValueError('入力が不正です。')
            with LOCK:
                with conn() as c:
                    enrollment.sync_due(c)
                    changed=school_year.sync(c)
                if changed:export_excel()
                path=urlparse(self.path).path
                u=self.user()
                if path=='/api/upload_stage':
                    self.send({'token':upload_staging.stage(DATA,u,d)});return
                d,staged_tokens=upload_staging.hydrate(DATA,u,d)
                if u and u['role']=='accountant' and path not in ('/api/login','/api/logout') and not path.startswith('/api/finance_'):raise PermissionError('会計専用アカウントでは利用できません。')
                if u and (u['role']=='coach' or u.get('delegated_coach')) and path=='/api/staff_activity' and d.get('user_id')!=u['id']:
                    self.send({'error':'本人の実績のみ操作できます。'},403);return
                with conn() as c:
                    admin_access.check(c,u,path.removeprefix('/api/'),d)
                    coach_scope.check_request(c,u,path.removeprefix('/api/'),d)
                if path in ('/api/event','/api/events_bulk','/api/schedule_document','/api/event_briefing','/api/roster','/api/attendance_review') and (not u or u['role']!='admin'):
                    self.send({'error':'管理者のみ編集できます。'},403);return
                if path in ('/api/result','/api/game_stats','/api/game_stats_import') and (not u or u['role']!='admin'):
                    self.send({'error':'管理者のみ編集できます。'},403);return
                if u and u['role'] in ('coach','admin') and path not in ('/api/login','/api/logout') and not path.startswith('/api/finance_'):
                    if u['role']!='admin' and (path in ('/api/account_review','/api/member_approval','/api/member_remove','/api/guardian_remove','/api/guardian_update','/api/user','/api/content','/api/billing_plan','/api/billing_plan_import','/api/fee_adjustment','/api/fee_receipt') or (path=='/api/staff_activity' and d.get('action')=='approval') or (path=='/api/portal' and d.get('action')=='billing_settings')):
                        self.send({'error':'管理者権限が必要です。'},403);return
                    with conn() as c:conflict=concurrency.check(c,u,path.removeprefix('/api/'),d)
                    if conflict:self.send(conflict,409);return
                self.mutate(path,d)
                upload_staging.discard(DATA,u,staged_tokens)
                if path not in ('/api/login','/api/logout','/api/new_seen','/api/upload_stage'):
                    with conn() as c:sheet_sync.mark(c)
        except PermissionError as e:self.send({'error':str(e)},403)
        except (ValueError,KeyError,TypeError) as e: self.send({'error':str(e) or '入力内容を確認してください。'},400)
        except sqlite3.IntegrityError: self.send({'error':'同じIDが登録済みです。'},400)
        except Exception as e:
            print(e,flush=True);self.send({'error':'保存できませんでした。もう一度お試しください。'},500)
    def mutate(self,path,d):
        if path=='/api/choice_masters':
            with conn() as c:result=choice_masters.apply(c,self.user(),d)
            self.send(result);return
        if path=='/api/equipment_master':
            with conn() as c:result=equipment_master.apply(c,self.user(),d)
            self.send(result);return
        if path in ('/api/member_workbook','/api/member_record'):
            with conn() as c:
                u=self.user()
                result=member_workbook.apply(c,u,d,password) if path.endswith('member_workbook') else {'ok':True,'action':member_workbook.save(c,u,d,password)}
            self.send(result);return
        if path in ('/api/withdrawal','/api/private_message','/api/sheet_sync'):
            with conn() as c:
                u=self.user()
                if path=='/api/withdrawal':result=withdrawals.mutate(c,u,d)
                elif path=='/api/private_message':result=withdrawals.send_message(c,u,d)
                else:
                    if not admin_access.full(u):raise PermissionError('管理者のみ設定できます。')
                    result=sheet_sync.configure(c,d)
            self.send(result);return
        if path=='/api/score_resource':
            with conn() as c:score_resources.save(c,u,d)
            self.send({'ok':True});return
        if path=='/api/skill_video':
            with conn() as c:skill_videos.save(c,self.user(),d)
            self.send({'ok':True});return
        if path=='/api/staff_remove':
            with conn() as c:accounts.remove_staff(c,self.user(),d)
            for token in list(SESSIONS):
                if SESSIONS[token][0]==d.get('user_id'):SESSIONS.pop(token,None)
            self.send({'ok':True});return
        if path=='/api/logistics':
            with conn() as c:result=event_logistics.mutate(c,self.user(),d)
            self.send(result);return
        if path=='/api/venues':
            with conn() as c:(venues.save_title if d.get('kind')=='title' else venues.save)(c,self.user(),d)
            self.send({'ok':True});return
        if path=='/api/officer_access':
            with conn() as c:staff_access.officer_save(c,self.user(),d)
            self.send({'ok':True});return
        if path=='/api/coach_register':
            with conn() as c:accounts.throttle(c,path,self.client_address[0],20,3600)
            with conn() as c:coach_registration.register(c,demo_registration.prepare(c,self.user(),'coach',d,password),password)
            self.send({'ok':True});return
        if path=='/api/coach_registration':
            with conn() as c:coach_registration.manage(c,self.user(),d)
            self.send({'ok':True});return
        if path=='/api/report_template':
            with conn() as c:report_templates.save(c,self.user(),d)
            self.send({'ok':True});return
        if path in ('/api/trial_review_submit','/api/trial_review_admin'):
            with conn() as c:
                if path.endswith('_submit'):trial_reviews.submit(c,d)
                else:trial_reviews.manage(c,self.user(),d)
            self.send({'ok':True});return

        if path=='/api/reset_credentials':
            with conn() as c:account=credentials.reset(c,self.user(),d,password)
            for token in list(SESSIONS):
                if SESSIONS[token][0]==account:SESSIONS.pop(token,None)
            self.send({'ok':True});return
        if path=='/api/note_templates':
            with conn() as c:note_templates.save(c,self.user(),d)
            self.send({'ok':True});return
        if path=='/api/basket_note_status':
            with conn() as c:basket_notes.save_status(c,self.user(),d)
            self.send({'ok':True});return
        if path=='/api/basket_note':
            with conn() as c:basket_notes.save(c,self.user(),d)
            self.send({'ok':True});return
        if path=='/api/staff_intro':
            with conn() as c:staff_intro.save(c,self.user(),d)
            self.send({'ok':True});return
        if path=='/api/coach_access':
            with conn() as c:staff_access.save(c,self.user(),d)
            self.send({'ok':True});return
        if path=='/api/member_finance_report':
            with conn() as c:finance_reports.submit(c,self.user(),d)
            self.send({'ok':True});return
        if path=='/api/receipt':
            with conn() as c:receipts.save(c,self.user(),d)
            self.send({'ok':True});return
        if path=='/api/staff_attendance':
            with conn() as c:staff_attendance.save(c,self.user(),d)
            self.send({'ok':True});return
        if path=='/api/school_report':
            with conn() as c:school_reports.save(c,self.user(),d)
            self.send({'ok':True});return
        if path=='/api/worksheet':
            with conn() as c:worksheets.save(c,self.user(),d)
            try:
                with conn() as c:worksheets.archive(c,DATA)
            except OSError:self.send({'ok':True,'archive_error':'Excelを閉じて、ダウンロードで控えを保存してください。'});return
            self.send({'ok':True});return
        if path.startswith('/api/finance_'):
            u=self.user()
            with conn() as c:
                if path=='/api/finance_register':
                    accounts.throttle(c,path,self.client_address[0],20,3600);year=accounting.register(c,demo_registration.prepare(c,u,'officer',d,password),password);self.send({'ok':True,'year':year});return
                if path=='/api/finance_member_review':finance_reports.review(c,u,d);self.send({'ok':True});return
                if path=='/api/finance_assignment':accounting.assignment(c,u,d);self.send({'ok':True});return
                year=int(d.get('year',0));accounting.access(c,u,year,True)
                if path=='/api/finance_entry':accounting.entry(c,u,d)
                elif path=='/api/finance_batch':
                    entries=d.get('entries')
                    if not isinstance(entries,list) or not 1<=len(entries)<=3000:raise ValueError('一度に1〜3000件登録してください。')
                    for row in entries:accounting.entry(c,u,{**row,'year':year})
                else:raise ValueError('操作がありません。')
            try:
                with conn() as c:folder=accounting.archive(c,DATA,year)
                self.send({'ok':True,'archive':folder})
            except Exception as e:
                print('Accounting archive:',e,flush=True);self.send({'ok':True,'archive_error':'明細は保存しましたが、ローカル帳票の更新に失敗しました。ダウンロードで控えを保存してください。'})
            return
        if path=='/api/admin_access':
            actor=self.user()
            with conn() as c:admin_access.save(c,actor,d,password)
            for token in list(SESSIONS):
                if SESSIONS[token][0]==d.get('id'):SESSIONS.pop(token,None)
            self.send({'ok':True});return
        if path in ('/api/register','/api/password_reset_request','/api/password_reset'):
            with conn() as c:accounts.throttle(c,path,self.client_address[0],50 if path=='/api/register' else 20,3600)
            with conn() as c:
                if path=='/api/register':accounts.registration(c,demo_registration.prepare(c,self.user(),'member',d,password),password)
                elif path=='/api/password_reset_request':accounts.request_reset(c,d)
                else:
                    uid=accounts.reset_password(c,d,password)
                    for token in list(SESSIONS):
                        if SESSIONS[token][0]==uid:SESSIONS.pop(token,None)
            self.send({'ok':True});return
        if path in ('/api/account_profile','/api/account_review','/api/member_approval','/api/member_remove','/api/guardian_remove','/api/guardian_update'):
            actor=self.user()
            if not actor:self.send({'error':'ログインしてください。'},401);return
            with conn() as c:
                if path=='/api/account_profile':accounts.save_profile(c,actor.get('login_id',actor['id']),d,password)
                elif path=='/api/account_review':accounts.review(c,actor,d,password)
                elif path=='/api/member_approval':accounts.member_approval(c,actor,d,password)
                elif path=='/api/guardian_update':accounts.update_guardian(c,actor,d)
                elif path=='/api/guardian_remove':accounts.remove_guardian(c,actor,d)
                else:accounts.remove_member(c,actor,d)
            if path in ('/api/member_approval','/api/member_remove','/api/guardian_remove'):
                with conn() as c:affected=[d.get('user_id')]+[r[0] for r in c.execute('SELECT login_id FROM guardian_accounts WHERE student_id=?',(d.get('user_id'),))]
                if path=='/api/guardian_remove':affected=[d.get('login_id')]
                for t in list(SESSIONS):
                    if SESSIONS[t][0] in affected:SESSIONS.pop(t,None)
            self.send({'ok':True,'excel':export_excel()});return
        if path=='/api/login':
            uid=str(d.get('id',''));key=(self.client_address[0],uid)
            attempts=[t for t in FAILURES.get(key,[]) if time.time()-t<300]
            if len(attempts)>=10: self.send({'error':'5分ほど待ってお試しください。'},429);return
            with conn() as c:
                valid=accounts.authenticate(c,uid,str(d.get('password','')),password)
                if valid:uid=credentials.resolve(c,uid)
                role=c.execute('SELECT role FROM users WHERE id=?',(uid,)).fetchone()
                if valid and role and role['role']=='accountant':valid=accounting.active(c,uid)
            if not valid:
                FAILURES[key]=attempts+[time.time()];self.send({'error':'IDまたはパスワードが違います。'},401);return
            token=secrets.token_urlsafe(32);expires=time.time()+28800;SESSIONS[token]=(uid,expires);FAILURES.pop(key,None)
            with conn() as c:
                c.execute('DELETE FROM login_sessions WHERE expires<?',(time.time(),))
                c.execute('INSERT INTO login_sessions VALUES(?,?,?)',(hashlib.sha256(token.encode()).hexdigest(),uid,expires))
                needs_profile=False
            self.send({'ok':True,'needs_profile':needs_profile},headers={'Set-Cookie':f'club_session={token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800'});return
        if path=='/api/logout':
            cookie=SimpleCookie(self.headers.get('Cookie',''));t=cookie.get('club_session')
            if t:
                SESSIONS.pop(t.value,None)
                with conn() as c:c.execute('DELETE FROM login_sessions WHERE token_hash=?',(hashlib.sha256(t.value.encode()).hexdigest(),))
            self.send({'ok':True},headers={'Set-Cookie':'club_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'});return
        if path=='/api/staff_activity':
            u=self.user()
            if not u or u['role'] not in ('coach','admin') or (d.get('action')=='approval' and u['role']!='admin'):
                self.send({'error':'この操作の権限がありません。'},403);return
            with conn() as c:staff_activity.save(c,u,d)
            self.send({'ok':True,'excel':export_excel()});return
        if path=='/api/trial':
            with conn() as c:
                if not c.execute("SELECT 1 FROM events WHERE id=? AND kind='体験会'",(d.get('event_id'),)).fetchone(): raise ValueError('体験会を選択してください。')
                for k in ['name','grade','contact','parent_name','phone','contact_type']:
                    if not str(d.get(k,'')).strip(): raise ValueError('必須項目を入力してください。')
                if d['grade'] not in ['年長']+[f'小学{i}年' for i in range(1,7)]+[f'中学{i}年' for i in range(1,4)]:raise ValueError('学年を選択してください。')
                contact=str(d['contact']).strip();kind=d['contact_type'];phone=str(d['phone']).strip()
                if kind not in ('email','line'):raise ValueError('連絡先の種類を選択してください。')
                if len(contact)>200 or (kind=='email' and not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',contact)):raise ValueError('連絡先を確認してください。')
                if kind=='line' and not re.fullmatch(r'[A-Za-z0-9._-]{1,100}',contact):raise ValueError('LINE IDは半角英数字・「.」「_」「-」で入力してください。')
                if not re.fullmatch(r'[0-9+()\-\s]{8,30}',phone):raise ValueError('電話番号を確認してください。')
                c.execute('INSERT INTO trials(id,event_id,name,grade,contact,note,created,parent_name,phone,contact_type,email,line_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',(secrets.token_hex(8),d['event_id'],d['name'][:100],d['grade'],contact,str(d.get('note',''))[:2000],time.strftime('%Y-%m-%d %H:%M:%S'),str(d['parent_name']).strip()[:100],phone,kind,contact if kind=='email' else '',contact if kind=='line' else ''))
            self.send({'ok':True,'excel':export_excel()});return
        u=self.user()
        if not u: self.send({'error':'ログインしてください。'},401);return
        staff=u['role'] in ('coach','admin')
        if path=='/api/enrollment':
            if not admin_access.can(u,'billing-settings',True):raise PermissionError('会費設定の編集権限が必要です。')
            with conn() as c:
                if d.get('status') in ('休会','即時休会','即日休会','指定日休会') and not d.get('reason'):raise ValueError('停止理由を選択してください。')
                enrollment.save(c,d.get('user_id'),d.get('status'),str(d.get('reason','')),str(d.get('note','')),d.get('revision'),d.get('pause_date'))
            self.send({'ok':True,'excel':export_excel()});return
        if path in ('/api/billing_plan','/api/billing_plan_import'):
            if u['role']!='admin':self.send({'error':'管理者のみ設定できます。'},403);return
            with conn() as c:
                plan=billing_plan.import_file(c,d) if path.endswith('_import') else billing_plan.validate(c,d)
                if d.get('confirm') is True:plan=billing_plan.save(c,plan)
            if d.get('confirm') is True:export_excel()
            self.send({'plan':plan});return
        if path=='/api/fee_receipt':
            if not u or u['role']!='admin':self.send({'error':'管理者のみ操作できます。'},403);return
            with conn() as c:
                if d.get('collection'):fee_collection.confirm(c,u,d,club_portal.billing_settings(c))
                else:fee_ledger.confirm(c,u,d)
            self.send({'ok':True,'excel':export_excel()});return
        if path=='/api/fee_adjustment':
            if u['role']!='admin':self.send({'error':'管理者のみ設定できます。'},403);return
            with conn() as c:fee_adjustments.save(c,u,d,club_portal.billing_settings(c))
            self.send({'ok':True,'excel':export_excel()});return
        if path=='/api/new_seen':
            keys=d.get('keys')
            if not isinstance(keys,list) or not 1<=len(keys)<=300 or any(not isinstance(k,str) or len(k)>220 for k in keys):raise ValueError('確認する記事が不正です。')
            with conn() as c:c.executemany('INSERT OR IGNORE INTO new_seen VALUES(?,?)',[(u['id'],k) for k in keys])
            self.send({'ok':True});return
        if path=='/api/family_checkout':
            with conn() as c:family_payments.checkout(c,u,d,club_portal.billing_settings(c))
            self.send({'ok':True,'excel':export_excel()});return
        if path=='/api/shop_product':
            if not staff:self.send({'error':'スタッフ権限が必要です。'},403);return
            with conn() as c:shop.save(c,d)
            self.send({'ok':True});return
        if path=='/api/shop_order':
            with conn() as c:oid=shop.create_order(c,u,d)
            self.send({'ok':True,'id':oid,'excel':export_excel()});return
        if path=='/api/shop_checkout':
            with conn() as c:shop.checkout(c,u,d)
            self.send({'ok':True,'excel':export_excel()});return
        if path=='/api/lunch_answer':
            with conn() as c:surveys.answer(c,u,d)
            self.send({'ok':True,'excel':export_excel()});return
        if path=='/api/board_read':
            with conn() as c:announcement_reads.acknowledge(c,u,d,board=True)
            self.send({'ok':True});return
        if path=='/api/announcement_read':
            with conn() as c:announcement_reads.acknowledge(c,u,d)
            self.send({'ok':True,'excel':export_excel()});return
        if path=='/api/shop_delivery':
            if not staff:self.send({'error':'スタッフ権限が必要です。'},403);return
            with conn() as c:shop.delivery(c,u,d)
            self.send({'ok':True,'excel':export_excel()});return
        if path=='/api/events_bulk':
            if not staff:self.send({'error':'スタッフ権限が必要です。'},403);return
            with conn() as c:count=event_briefings.save_bulk_events(c,d)
            self.send({'ok':True,'count':count,'excel':export_excel()});return
        if path=='/api/event_briefing':
            if not staff:self.send({'error':'スタッフ権限が必要です。'},403);return
            with conn() as c:event_briefings.save(c,d)
            self.send({'ok':True,'excel':export_excel()});return
        if path=='/api/schedule_document':
            if not staff:self.send({'error':'スタッフ権限が必要です。'},403);return
            with conn() as c:schedule_documents.save(c,d)
            self.send({'ok':True});return
        if path=='/api/game_stats_import':
            if not staff:self.send({'error':'スタッフ権限が必要です。'},403);return
            with conn() as c:result=game_stats.import_file(c,u,d)
            if d.get('confirm') is True:export_excel()
            self.send(result);return
        if path=='/api/game_stats':
            if not staff:self.send({'error':'スタッフ権限が必要です。'},403);return
            with conn() as c:game_stats.save(c,u,d)
            self.send({'ok':True,'excel':export_excel()});return
        if path=='/api/attendance_batch':
            entries=d.get('entries')
            if not isinstance(entries,list) or not 1<=len(entries)<=200: raise ValueError('日程を1〜200件選択してください。')
            with conn() as c:
                for entry in entries:
                    if not isinstance(entry,dict): raise ValueError('出欠内容が不正です。')
                    scheduling.mutate(c,u,'attendance',entry)
            self.send({'ok':True,'excel':export_excel()});return
        if path in ('/api/attendance','/api/condition','/api/attendance_review','/api/roster'):
            if path in ('/api/attendance_review','/api/roster') and not staff:
                self.send({'error':'スタッフ権限が必要です。'},403);return
            with conn() as c: scheduling.mutate(c,u,path.split('/')[-1],d)
            self.send({'ok':True,'excel':export_excel()});return
        if path=='/api/portal':
            if d.get('action')=='billing_settings' and u['role']!='admin':
                self.send({'error':'管理者権限が必要です。'},403);return
            with conn() as c: club_portal.mutate(c,u,d)
            self.send({'ok':True,'excel':export_excel()} if d.get('action') in ('billing_settings','payment_preferences') else {'ok':True});return
        if path=='/api/upload':
            if u['role']!='admin': self.send({'error':'管理者権限が必要です。'},403);return
            raw=base64.b64decode(d.get('image',''),validate=True)
            if len(raw)>5*1024*1024: raise ValueError('写真は5MB以下にしてください。')
            ext='jpg' if raw.startswith(b'\xff\xd8\xff') else 'png' if raw.startswith(b'\x89PNG\r\n\x1a\n') else 'webp' if raw.startswith(b'RIFF') and raw[8:12]==b'WEBP' else None
            if not ext: raise ValueError('JPEG・PNG・WebPの画像を選択してください。')
            filename=secrets.token_hex(16)+'.'+ext
            folder=ROOT/'public'/'uploads';folder.mkdir(exist_ok=True);(folder/filename).write_bytes(raw)
            self.send({'url':'/uploads/'+filename});return
        if path=='/api/report':
            eid=d['event_id'];condition=int(d['condition']);sleep=float(d['sleep']);attendance=d['attendance']
            if not 1<=condition<=5 or not 0<=sleep<=24 or attendance not in ['出席','欠席','遅刻']: raise ValueError('入力値を確認してください。')
            with conn() as c:
                if not c.execute('SELECT 1 FROM events WHERE id=?',(eid,)).fetchone(): raise ValueError('日程が見つかりません。')
                c.execute('INSERT INTO reports(user_id,event_id,condition,sleep,note,attendance,updated) VALUES(?,?,?,?,?,?,?) ON CONFLICT(user_id,event_id) DO UPDATE SET condition=excluded.condition,sleep=excluded.sleep,note=excluded.note,attendance=excluded.attendance,updated=excluded.updated',(u['id'],eid,condition,sleep,str(d.get('note',''))[:2000],attendance,time.strftime('%Y-%m-%d %H:%M:%S')))
        elif not staff: self.send({'error':'スタッフ権限が必要です。'},403);return
        elif path=='/api/trial_review':
            with conn() as c:
                if not c.execute('SELECT 1 FROM trials WHERE id=?',(d.get('id'),)).fetchone(): raise ValueError('申し込みが見つかりません。')
                c.execute('INSERT OR IGNORE INTO trial_reviews VALUES(?,?,?)',(d['id'],u['id'],time.strftime('%Y-%m-%d %H:%M:%S')))
        elif path=='/api/actual':
            if d['actual'] not in ['出席','欠席','遅刻','']: raise ValueError('出欠を確認してください。')
            with conn() as c:
                if not c.execute('SELECT 1 FROM users WHERE id=? AND role="member"',(d['user_id'],)).fetchone() or not c.execute('SELECT 1 FROM events WHERE id=?',(d['event_id'],)).fetchone(): raise ValueError('会員または日程が見つかりません。')
                c.execute('INSERT INTO reports(user_id,event_id,actual,updated) VALUES(?,?,?,?) ON CONFLICT(user_id,event_id) DO UPDATE SET actual=excluded.actual,updated=excluded.updated',(d['user_id'],d['event_id'],d['actual'],time.strftime('%Y-%m-%d %H:%M:%S')))
        elif path=='/api/content':
            if u['role']!='admin': self.send({'error':'管理者権限が必要です。'},403);return
            with conn() as c:
                content=seo.public_content(json.loads(c.execute('SELECT value FROM content').fetchone()[0]))
                if 'practice_slots' in d:
                    slots=json.loads(d['practice_slots']) if isinstance(d['practice_slots'],str) else d['practice_slots']
                    if not isinstance(slots,list) or len(slots)>40:raise ValueError('練習日は40件以内で登録してください。')
                    clean=[]
                    for row in slots:
                        if not isinstance(row,dict) or row.get('group') not in ('年長・小学生','中学生') or row.get('day') not in ('月','火','水','木','金','土','日'):raise ValueError('対象と曜日を選択してください。')
                        start=str(row.get('start',''));end=str(row.get('end',''))
                        if not re.fullmatch(r'([01]\d|2[0-3]):[0-5]\d',start) or (end and not re.fullmatch(r'([01]\d|2[0-3]):[0-5]\d',end)):raise ValueError('開始・終了時間を確認してください。')
                        if end and end<=start:raise ValueError('終了時間は開始時間より後にしてください。')
                        clean.append({'group':row['group'],'day':row['day'],'start':start,'end':end})
                    d['practice_slots']=json.dumps(clean,ensure_ascii=False)
                    d['practice']=' ／ '.join(group+'：'+'、'.join(r['day']+'曜日 '+r['start']+'〜'+r['end'] for r in clean if r['group']==group) for group in ('年長・小学生','中学生') if any(r['group']==group for r in clean))
                for k in content:
                    if k in d:
                        v=str(d[k])[:5000]
                        if k in ('hero','gallery','conditioning_photo','instagram','facebook','line','conditioning_instagram','mikitiv_url','mikitiv_clubs_url') and v and not (v.startswith('https://') or (k in ('hero','gallery','conditioning_photo') and re.fullmatch(r'/uploads/[a-f0-9]{32}\.(jpg|png|webp)',v))): raise ValueError('リンクにはhttps://で始まるURLを入力してください。')
                        if k=='accent' and (len(v)!=7 or any(x not in '0123456789abcdefABCDEF' for x in v[1:]) or not v.startswith('#')): raise ValueError('色を選択してください。')
                        content[k]=v
                c.execute('UPDATE content SET value=?',(json.dumps(content,ensure_ascii=False),))
        elif path=='/api/user':
            if u['role']!='admin': self.send({'error':'管理者権限が必要です。'},403);return
            uid=str(d['id']).strip()
            if not uid or len(uid)>40 or not all(x.isalnum() or x in '_-' for x in uid): raise ValueError('IDは40文字以内の英数字で入力してください。')
            role=d.get('role','member');active=int(d.get('active',1));name=str(d.get('name','')).strip()
            if role not in ['member','coach','admin'] or active not in (0,1) or not name: raise ValueError('会員情報を確認してください。')
            if uid==u['id'] and (active==0 or role!='admin'): raise ValueError('自分の管理者権限は解除できません。')
            with conn() as c:
                old=c.execute('SELECT * FROM users WHERE id=?',(uid,)).fetchone()
                if not old and credentials.taken(c,uid):raise ValueError('このログインIDは使用されています。')
                if not old and c.execute('SELECT 1 FROM guardian_accounts WHERE login_id=?',(uid,)).fetchone():raise ValueError('このIDは既に使用されています。')
                if not old and role not in ('member','coach') and not d.get('password'): raise ValueError('新規登録にはパスワードが必要です。')
                if d.get('password') and len(d['password'])<8: raise ValueError('パスワードは8文字以上で入力してください。')
                h=password(d['password']) if d.get('password') else old['hash'] if old else password(secrets.token_urlsafe(32))
                if not old and role=='member' and not d.get('password'):
                    c.execute('INSERT INTO student_only VALUES(?)',(uid,))
                    c.execute('INSERT INTO member_access VALUES(?,0)',(uid,))
                c.execute('INSERT INTO users VALUES(?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,grade=excluded.grade,role=excluded.role,hash=excluded.hash,active=excluded.active',(uid,name,str(d.get('grade',''))[:40],role,h,active))
                if role=='admin' and admin_access.full(u):c.execute("INSERT OR REPLACE INTO admin_access VALUES(?,1,'{}')",(uid,))
                if 'staff_permissions' in d:
                    if role!='coach' or uid=='admin01' or not admin_access.full(u):raise PermissionError('管理者のみスタッフの権限を設定できます。')
                    staff_access.save(c,u,{'id':uid,'kind':'個別設定','permissions':d['staff_permissions'],'revision':d.get('staff_permission_revision',0)})
                    c.execute('DELETE FROM admin_access WHERE user_id=?',(uid,))
                if not old and role=='coach':coach_registration.manage(c,u,{'action':'invite','user_id':uid})
                if role=='member' and 'enrollment_status' in d:
                    previous=enrollment.read(c,uid)
                    enrollment.save(c,uid,d['enrollment_status'],previous['reason'],previous['note'],pause_date=d.get('pause_date'))
                accounts.ensure_invites(c)
                school_year.anchor(c,uid,str(d.get('grade',''))[:40])
                if role=='member' and 'school' in d:
                    school=str(d['school']).strip()
                    if len(school)>150:raise ValueError('学校名は150文字以内にしてください。')
                    c.execute('INSERT OR REPLACE INTO member_schools VALUES(?,?)',(uid,school))
                if 'categories' in d or not old:
                    cats=str(d.get('categories','U12')).strip()
                    if role=='member' and (not cats or len(cats)>200):raise ValueError('所属カテゴリーを入力してください。')
                    c.execute('INSERT OR REPLACE INTO member_categories VALUES(?,?)',(uid,cats))
                if 'family_id' in d or role!='member':
                    family_id=str(d.get('family_id','')).strip() if role=='member' else ''
                    if family_id and not re.fullmatch(r'[A-Za-z0-9_-]{1,40}',family_id):raise ValueError('家族IDは40文字以内の半角英数字・ハイフン・下線で入力してください。')
                    c.execute('DELETE FROM member_families WHERE user_id=?',(uid,))
                    if family_id:c.execute('INSERT INTO member_families VALUES(?,?)',(uid,family_id))
            if not active or d.get('password'):
                with conn() as c:c.execute('DELETE FROM login_sessions WHERE user_id=?',(uid,))
                for t in list(SESSIONS):
                    if SESSIONS[t][0]==uid: SESSIONS.pop(t,None)
        elif path in ['/api/event','/api/result']:
            table='events' if path.endswith('event') else 'results'
            fields=['title','date','time','place','kind','group_name','note'] if table=='events' else ['date','opponent','ours','theirs','group_name','note','video']
            rid=d.get('id') or secrets.token_hex(8)
            with conn() as c:
                if d.get('delete'):
                    c.execute('DELETE FROM '+table+' WHERE id=?',(rid,))
                    if table=='results':
                        c.execute('DELETE FROM game_stats WHERE result_id=?',(rid,))
                        c.execute('DELETE FROM game_stats_publication WHERE result_id=?',(rid,))
                    if table=='events':
                        c.execute('DELETE FROM attendance_meta WHERE event_id=?',(rid,))
                        c.execute('DELETE FROM match_rosters WHERE event_id=?',(rid,))
                        c.execute('DELETE FROM event_details WHERE event_id=?',(rid,))
                        c.execute('DELETE FROM event_addresses WHERE event_id=?',(rid,))
                        c.execute('DELETE FROM event_briefings WHERE event_id=?',(rid,))
                        c.execute('DELETE FROM event_briefing_files WHERE event_id=?',(rid,))
                    if table=='events': c.execute('DELETE FROM reports WHERE event_id=?',(rid,));c.execute('DELETE FROM trials WHERE event_id=?',(rid,))
                else:
                    from datetime import date
                    date.fromisoformat(d['date'])
                    if table=='events' and d['kind'] not in ['体験会','練習','試合']: raise ValueError('種別が不正です。')
                    if table=='events' and 'address' in d:
                        addr=venues.save_address(c,rid,d['address'])
                        if addr:d['map_url']=venues.map_url(addr)
                    if table=='events' and 'map_url' in d:
                        map_url=str(d['map_url']).strip()
                        if map_url and (urlparse(map_url).scheme!='https' or not urlparse(map_url).hostname or len(map_url)>2000):raise ValueError('地図にはhttps://で始まるURLを入力してください。')
                        c.execute('INSERT OR REPLACE INTO event_details VALUES(?,?)',(rid,map_url))
                    if table=='results':
                        for k in ['ours','theirs']:
                            d[k]=int(d[k])
                            if not 0<=d[k]<=999: raise ValueError('スコアは0〜999で入力してください。')
                        v=d.get('video','')
                        if v and (urlparse(v).scheme!='https' or urlparse(v).hostname not in ['www.youtube.com','youtube.com','youtu.be']): raise ValueError('YouTubeのhttps URLを入力してください。')
                    vals=[d.get(k,'') for k in fields]
                    if any(len(str(v))>5000 for v in vals): raise ValueError('入力が長すぎます。')
                    c.execute('INSERT OR REPLACE INTO '+table+' VALUES(?,?,?,?,?,?,?,?)',[rid]+vals)
                    if table=='events' and 'equipment_items' in d:equipment_master.save_event(c,rid,d['equipment_items'])
        elif path!='/api/sync': self.send({'error':'見つかりません。'},404);return
        self.send({'ok':True,'excel':export_excel()})

def watch_fee_inputs():
    while True:
        try:
            with LOCK:
                with conn() as c:
                    accounts.flush_mail(c)
                    enrollment.sync_due(c)
                    changed=school_year.sync(c)
                    changed=local_members.sync(c,DATA/'会員スタッフ入力.xlsx',password) or changed
                    changed=local_fees.sync(c,DATA/'会費金額設定.xlsx') or changed
                    changed=announcement_reads.sync(c,DATA/'お知らせ入力.xlsx') or changed
                    changed=conditioning.sync(c,DATA/'コンディショニング入力.csv') or changed
                    changed=attendance_rates.sync(c,DATA/'出欠入力.xlsx') or changed
                if changed:export_excel()
        except (OSError,sqlite3.Error) as e:print('会費Excelの読み込み待機:',e,flush=True)
        time.sleep(5)

if __name__=='__main__':
    os.umask(0o077)
    init()
    local_members.ensure_template(DATA/'会員スタッフ入力.xlsx')
    if not (DATA/'チーターズ管理.xlsx').exists(): export_excel()
    threading.Thread(target=watch_fee_inputs,daemon=True).start()
    threading.Thread(target=logistics_worker.run,args=(conn,LOCK),daemon=True).start()
    threading.Thread(target=sheet_sync.run,args=(conn,LOCK),daemon=True).start()
    print('CHEETAHS demo: http://127.0.0.1:8765',flush=True)
    ThreadingHTTPServer(('127.0.0.1',int(os.environ.get('CHEETAHS_PORT','8765'))),Handler).serve_forever()
