"""Private, versioned activity details published after attendance review."""
import base64, json, secrets, time
from urllib.parse import urlparse
import scheduling, venues

def init(c):
    c.execute("CREATE TABLE IF NOT EXISTS event_briefings(event_id TEXT PRIMARY KEY,draft TEXT,published TEXT)")
    c.execute("CREATE TABLE IF NOT EXISTS event_briefing_files(id TEXT PRIMARY KEY,event_id TEXT,name TEXT,mime TEXT,content BLOB)")

def read(c,u):
    output=[]
    for row in c.execute('SELECT b.*,e.group_name,e.kind FROM event_briefings b JOIN events e ON e.id=b.event_id'):
        if u['role']=='member' and not scheduling.eligible(c,u['id'],row):continue
        published=json.loads(row['published']) if row['published'] else None
        if u['role']=='member':
            if published:output.append(published)
        else:output.append({'event_id':row['event_id'],'draft':json.loads(row['draft']),'published':published})
    return output

def save(c,d):
    eid=d.get('event_id');event=c.execute('SELECT * FROM events WHERE id=?',(eid,)).fetchone()
    if not event or event['kind'] not in ('練習','試合','体験会'):raise ValueError('日程を選択してください。')
    schedule=d.get('schedule')
    if schedule is not None:
        if not isinstance(schedule,dict):raise ValueError('日程を確認してください。')
        from datetime import date
        schedule={k:str(schedule.get(k,event[k] if k in ('kind','group_name') else '')).strip() for k in ('title','date','time','place','kind','group_name')}
        if any(not v or len(v)>5000 for v in schedule.values()):raise ValueError('タイトル・日付・時間・会場を入力してください。')
        date.fromisoformat(schedule['date'])
        if schedule['kind'] not in ('練習','試合','体験会'):raise ValueError('種別を選択してください。')
        event={**dict(event),**schedule}
    mode=d.get('mode','all');ids=d.get('member_ids',[])
    if mode not in ('all','selected') or not isinstance(ids,list):raise ValueError('参加メンバーを確認してください。')
    valid={u['id']:u['name'] for u in c.execute("SELECT id,name FROM users WHERE role='member' AND active=1") if scheduling.eligible(c,u['id'],event)}
    if any(not isinstance(uid,str) or uid not in valid for uid in ids):raise ValueError('この活動区分の在籍会員を選択してください。')
    ids=list(dict.fromkeys(ids)) if mode=='selected' else []
    previous=c.execute('SELECT address FROM event_addresses WHERE event_id=?',(eid,)).fetchone()
    address=venues.address(d.get('address',previous[0] if previous else ''))
    note=str(d.get('note','')).strip();map_url=venues.map_url(address) if address else str(d.get('map_url','')).strip()
    if len(note)>10000:raise ValueError('注意事項は10000文字以内にしてください。')
    if map_url and (urlparse(map_url).scheme not in ('https','http') or not urlparse(map_url).netloc):raise ValueError('地図URLを確認してください。')
    keep=d.get('keep_files',[]);uploads=d.get('uploads',[])
    if not isinstance(keep,list) or not isinstance(uploads,list) or len(keep)+len(uploads)>30:raise ValueError('添付は合計30件までです。')
    files=[]
    for fid in dict.fromkeys(keep):
        f=c.execute('SELECT id,name,mime FROM event_briefing_files WHERE id=? AND event_id=?',(fid,eid)).fetchone()
        if not f:raise ValueError('添付ファイルが見つかりません。')
        files.append(dict(f))
    for upload in uploads:
        try:raw=base64.b64decode(upload['content'],validate=True)
        except Exception:raise ValueError('添付ファイルを読み込めません。')
        if not 0<len(raw)<=5*1024*1024:raise ValueError('添付ファイルは1件5MB以下にしてください。')
        if raw.startswith(b'%PDF-') and b'%%EOF' in raw[-2048:]:mime='application/pdf'
        elif raw.startswith(b'\xff\xd8\xff'):mime='image/jpeg'
        elif raw.startswith(b'\x89PNG\r\n\x1a\n'):mime='image/png'
        elif raw.startswith(b'RIFF') and raw[8:12]==b'WEBP':mime='image/webp'
        else:raise ValueError('PDF・JPEG・PNG・WebPを添付してください。')
        name=str(upload.get('name','添付ファイル'))[:150];fid=secrets.token_hex(16)
        c.execute('INSERT INTO event_briefing_files VALUES(?,?,?,?,?)',(fid,eid,name,mime,raw))
        files.append({'id':fid,'name':name,'mime':mime})
    brief={'address':address,'event_id':eid,'mode':mode,'member_ids':ids,'names':[{'id':uid,'name':valid[uid]} for uid in ids],'note':note,'map_url':map_url,'files':files,'revision':secrets.token_hex(12),'updated':time.strftime('%Y-%m-%d %H:%M:%S')}
    if schedule is not None:brief['schedule']=schedule
    old=c.execute('SELECT published FROM event_briefings WHERE event_id=?',(eid,)).fetchone()
    published=old['published'] if old else None
    publish=d.get('publish') is True
    encoded=json.dumps(brief,ensure_ascii=False)
    c.execute('INSERT OR REPLACE INTO event_briefings VALUES(?,?,?)',(eid,encoded,encoded if publish else published))
    if publish:
        venues.save_address(c,eid,address)
        if schedule is not None:
            c.execute('UPDATE events SET title=?,date=?,time=?,place=?,kind=?,group_name=?,note=? WHERE id=?',(schedule['title'],schedule['date'],schedule['time'],schedule['place'],schedule['kind'],schedule['group_name'],note,eid))
            c.execute('INSERT OR REPLACE INTO event_details VALUES(?,?)',(eid,map_url))
        roster=ids if mode=='selected' else list(valid)
        c.execute('INSERT OR REPLACE INTO match_rosters VALUES(?,?,1,?)',(eid,json.dumps(roster),brief['updated']))
    # Keep both the draft and currently published attachments; remove abandoned blobs.
    refs={f['id'] for f in files}
    if published and not publish:refs.update(f['id'] for f in json.loads(published)['files'])
    for row in c.execute('SELECT id FROM event_briefing_files WHERE event_id=?',(eid,)).fetchall():
        if row[0] not in refs:c.execute('DELETE FROM event_briefing_files WHERE id=?',(row[0],))
    return brief

def file(c,u,fid):
    f=c.execute('SELECT f.*,e.group_name,e.kind,b.published FROM event_briefing_files f JOIN events e ON e.id=f.event_id JOIN event_briefings b ON b.event_id=f.event_id WHERE f.id=?',(fid,)).fetchone()
    if not f:return None
    if u['role']=='member':
        if not scheduling.eligible(c,u['id'],f) or not f['published']:return None
        if fid not in {x['id'] for x in json.loads(f['published'])['files']}:return None
    return f

def save_bulk_events(c,d):
    from datetime import date
    rows=d.get('events')
    if not isinstance(rows,list) or not 1<=len(rows)<=50:raise ValueError('日程は1〜50件で登録してください。')
    categories={'男子A','男子B','女子A','女子B','U15A','U15B'}
    prepared=[];seen=set()
    for i,row in enumerate(rows,1):
        if not isinstance(row,dict):raise ValueError('日程の形式が不正です。')
        fields={k:str(row.get(k,'')).strip() for k in ('title','date','time','place','kind','group_name','note','map_url')}
        if any(len(v)>5000 for v in fields.values()):raise ValueError(f'{i}件目：入力が長すぎます。')
        if any(not fields[k] for k in ('title','date','time','place','group_name')):raise ValueError(f'{i}件目：必須項目を入力してください。')
        try:date.fromisoformat(fields['date'])
        except ValueError:raise ValueError(f'{i}件目：日付を確認してください。')
        if fields['kind'] not in ('練習','試合','体験会'):raise ValueError(f'{i}件目：活動内容を選択してください。')
        groups=[g.strip() for g in fields['group_name'].split('、')]
        if not set(groups)<=categories:raise ValueError(f'{i}件目：カテゴリーを確認してください。')
        fields['group_name']='、'.join(sorted(set(groups)))
        fields['address']=venues.address(row.get('address',''))
        if fields['address']:fields['map_url']=venues.map_url(fields['address'])
        url=fields['map_url']
        if url and (urlparse(url).scheme!='https' or not urlparse(url).hostname):raise ValueError(f'{i}件目：地図URLはhttpsで入力してください。')
        key=tuple(fields[k] for k in ('title','date','time','place','kind','group_name'))
        if key in seen or c.execute('SELECT 1 FROM events WHERE title=? AND date=? AND time=? AND place=? AND kind=? AND group_name=?',key).fetchone():raise ValueError(f'{i}件目：同じ日程が登録済み、または入力内で重複しています。')
        seen.add(key);prepared.append(fields)
    for row in prepared:
        eid=secrets.token_hex(8)
        c.execute('INSERT INTO events VALUES(?,?,?,?,?,?,?,?)',[eid]+[row[k] for k in ('title','date','time','place','kind','group_name','note')])
        c.execute('INSERT INTO event_details VALUES(?,?)',(eid,row['map_url']))
        venues.save_address(c,eid,row['address'])
    return len(prepared)
