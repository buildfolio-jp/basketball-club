"""Private PDF and image attachments, served only after owner access checks."""
import base64,secrets

def init(c):c.execute('CREATE TABLE IF NOT EXISTS submission_files(id TEXT PRIMARY KEY,kind TEXT,record_id TEXT,name TEXT,mime TEXT,content BLOB)')
def listing(c,kind,rid):return [dict(r) for r in c.execute('SELECT id,name,mime FROM submission_files WHERE kind=? AND record_id=?',(kind,rid))]
def add(c,kind,rid,uploads):
 if not isinstance(uploads,list) or len(uploads)+len(listing(c,kind,rid))>30:raise ValueError('添付は30件までです。')
 for upload in uploads:
  try:raw=base64.b64decode(upload['content'],validate=True)
  except Exception:raise ValueError('添付ファイルを読み込めません。')
  if not 0<len(raw)<=5*1024*1024:raise ValueError('添付は1件5MB以下にしてください。')
  mime='application/pdf' if raw.startswith(b'%PDF-') and b'%%EOF' in raw[-2048:] else 'image/png' if raw.startswith(b'\x89PNG\r\n\x1a\n') else 'image/jpeg' if raw.startswith(b'\xff\xd8\xff') else 'image/webp' if raw.startswith(b'RIFF') and raw[8:12]==b'WEBP' else ''
  if not mime:raise ValueError('PDF・JPEG・PNG・WebPを添付してください。')
  c.execute('INSERT INTO submission_files VALUES(?,?,?,?,?,?)',(secrets.token_hex(16),kind,rid,str(upload.get('name','添付'))[:200],mime,raw))
