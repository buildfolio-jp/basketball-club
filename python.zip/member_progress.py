"""Member-only fiscal-year attendance and notebook summaries (April to March)."""
import accounting,basket_notes
from attendance_rates import PRESENT

def read(c,u):
 if not u or u['role']!='member':return None
 today=accounting.today();current=today.year-(today.month<4)
 rows=[dict(r) for r in c.execute("SELECT e.date,r.actual,n.submitted,n.user_id AS note_owner FROM reports r JOIN events e ON e.id=r.event_id LEFT JOIN basket_notes n ON n.event_id=r.event_id AND n.user_id=r.user_id WHERE r.user_id=? AND e.kind<>'体験会' AND e.date<=?",(u['id'],today.isoformat()))]
 def fiscal(day):return int(day[:4])-(int(day[5:7])<4)
 earliest=min([current]+[fiscal(r['date']) for r in rows])
 summaries=[]
 for year in range(current,earliest-1,-1):
  own=[r for r in rows if fiscal(r['date'])==year]
  present=sum(r['actual'] in PRESENT for r in own);confirmed=present+sum(r['actual']=='欠席' for r in own)
  attended={r['date'] for r in own if r['actual'] in PRESENT};submitted={r['date'] for r in own if r['actual'] in PRESENT and r['submitted']}
  applicable=bool(basket_notes.group(u.get('grade','')) or any(r['note_owner'] for r in own))
  summaries.append({'year':year,'start':f'{year}-04-01','end':f'{year+1}-03-31','present':present,'confirmed':confirmed,'attendance_rate':round(present*100/confirmed,1) if confirmed else None,'note_applicable':applicable,'attended_days':len(attended),'submitted_days':len(submitted),'note_rate':round(len(submitted)*100/len(attended),1) if attended and applicable else None})
 return {'current_year':current,'years':summaries}
