"""Public HTML and metadata for the local demo. No member data is accepted."""
import json
import calendar
from datetime import date
from html import escape

SEO_DEFAULTS = {
    'region': '兵庫県三木市',
    'seo_title': '三木市のバスケットボールクラブ｜小学生〜中学生｜SHINING CHEETAHS',
    'seo_description': '三木　SHINING CHEETAHS（ミキシャイニングチーターズ）は兵庫県三木市で活動する小学生から中学生のバスケットボールクラブです。初心者も歓迎。チームの理念、体験会の日程、参加方法、練習場所をご案内します。',
}

def public_content(c):
    c={k:(v.replace("年長〜","小学1年生〜").replace("年長～","小学1年生〜").replace("年長・","") if isinstance(v,str) else v) for k,v in c.items()}
    return {**{'conditioning_category': 'コンディショニングコーチ', 'conditioning_title': '外部コーチによるコンディショニング', 'conditioning_intro': '外部コーチによるコンディショニングも月1回開催しています。', 'conditioning_name': '廣田 梨恵 コーチ', 'conditioning_comment': '選手たちの体づくりや怪我予防のためのケアを目的にサポートしてくださっています。', 'conditioning_contact': 'コーチとの直接やりとりも可能となっております。', 'conditioning_instagram': 'https://www.instagram.com/athlete.support.rie_hirota?stkn=d2EzYzdyYzFsMTJn', 'mikitiv_category': '三木市地域クラブ「みきティブ」認定登録', 'mikitiv_title': '地域とともに、子どもたちの「やってみたい」を応援。', 'mikitiv_intro': '三木　SHINING CHEETAHSは、兵庫県三木市の地域クラブ「みきティブ」に認定登録されています。', 'mikitiv_heading': '「みきティブ」とは？', 'mikitiv_description': '三木市が学校部活動の地域展開を進める中で名付けた、地域クラブの愛称です。「みきっこアクティブ」を略した名前で、子どもたちが自分でやりたい活動を選び、主体的に取り組むことへの願いが込められています。地域の力で、スポーツや文化芸術に親しむ機会を支える取り組みです。', 'mikitiv_url': 'https://www.city.miki.lg.jp/site/tiikiclub/80939.html', 'mikitiv_clubs_url': 'https://www.city.miki.lg.jp/site/tiikiclub/88187.html'}, 'facebook':'', 'conditioning_photo':'', 'practice_slots':'[]', **SEO_DEFAULTS, **c}

def questions(c):
    return [
        {'q':'どの地域・学年を対象にしたクラブですか？','a':'三木　SHINING CHEETAHSは、兵庫県三木市を拠点に活動する、小学生・中学生を対象としたバスケットボールクラブです。\n三木市をはじめ、小野市・加古川市・加東市・神戸市西区など、さまざまな地域から選手が参加しています。'},
        {'q':'バスケットボールが初めてでも参加できますか？','a':'初心者も歓迎しています。まずは体験会で、チームの雰囲気や練習を体験してください。'},
        {'q':'練習場所はどこですか？','a':'基本的に小学校体育館で活動します。詳しくは申込後にお伝えいたします。'},
        {'q':'体験会にはどう申し込めますか？','a':f"体験会カレンダーから日程を選び、「参加する」からお申し込みください。持ち物は{c['equipment']}です。"},
    ]

def structured_data(c):
    return {'@context':'https://schema.org','@type':'SportsOrganization','@id':'#club',
            'name':c['name'],'alternateName':c['subname'],'sport':'Basketball',
            'description':f"{c['region']}で活動する小学生・中学生のバスケットボールクラブ。初心者も歓迎しています。",
            'areaServed':{'@type':'City','name':c['region']},
            'sameAs':[c[k] for k in ('instagram','line') if c.get(k,'').startswith('https://')]}

def render_public(c,events):
    """Initial, visible page HTML; JavaScript progressively adds interactive controls."""
    e=lambda v:escape(str(v),quote=True)
    logo='<img class="club-logo" src="/uploads/00000000000000000000000000000001.jpg" width="53" height="53" alt="SHINING CHEETAHS ロゴ">'
    wordmark='<strong class="team-wordmark miki-wordmark"><span class="team-name-white">MIKI </span><span class="team-name-yellow">S</span><span class="team-name-white">HINING C</span><span class="team-name-yellow">HEETAHS</span></strong>' if c["name"].upper().replace(" ", "").replace("　", "") in ("SHININGCHEETAHS","MIKISHININGCHEETAHS","三木SHININGCHEETAHS") else "<strong>"+e(c["name"])+"</strong>"
    brand=f'<a class="brand" href="/">{logo}<span>{wordmark}<small>YOUTH BASKETBALL CLUB</small></span></a>'
    groups=[('elementary','小学生','U9・U12'),('junior','中学生','U15')]
    def matches(x,kind):
        g=x['group_name']
        return ('小学生' in g or '小中学生' in g or 'U9' in g.upper() or 'U12' in g.upper()) if kind=='elementary' else ('中学生' in g or 'U15' in g.upper())
    cards=''
    for kind,label,note in groups:
        es=[x for x in events if matches(x,kind)]
        body=''.join(f'<article class="event-card"><div><span class="tag">{e(x["group_name"])}</span><h3>{e(x["title"])}</h3><p><time datetime="{e(x["date"])}">{e(x["date"])}</time> {e(x["time"])}<br>{e(x["place"])}</p></div></article>' for x in es) or '<p class="empty">体験会はまだ登録されていません。</p>'
        cards+=f'<section class="trial-age-group"><div class="trial-age-heading"><h3><i class="trial-dot {kind}" aria-hidden="true"></i>{label}の体験会</h3><span>{note}</span></div>{body}</section>'
    y,m=2026,9
    start=(calendar.monthrange(y,m)[0]+1)%7
    cells='<span></span>'*start
    for day in range(1,calendar.monthrange(y,m)[1]+1):
        d=date(y,m,day).isoformat();es=[x for x in events if x['date']==d]
        dots=''.join(f'<i class="trial-dot {kind}" aria-hidden="true"></i>' for kind,_,_ in groups if any(matches(x,kind) for x in es))
        cells+=f'<span class="day {"event" if es else ""}">{day}<span class="day-dots">{dots}</span></span>'
    cal=f'<div class="card calendar-card"><div class="calendar-head"><strong>{y}. {m:02}</strong></div><div class="calendar">'+''.join(f'<div class="dow">{d}</div>' for d in '日月火水木金土')+cells+'</div><div class="calendar-legend"><span><i class="trial-dot elementary"></i>小学生</span><span><i class="trial-dot junior"></i>中学生</span></div></div>'
    faqs=''.join(f'<details><summary>{e(q["q"])}</summary><p>{e(q["a"])}</p></details>' for q in questions(c))
    photo=c.get('gallery') or c.get('hero')
    image=f'<img src="{e(photo)}" alt="{e(c["name"])}の活動風景" width="640" height="640" loading="lazy" decoding="async">' if photo else ''
    social=''.join(f'<a class="btn small social-{key}" href="{e(c[key])}" target="_blank" rel="noopener noreferrer">{label}</a>' if c.get(key) else f'<span class="btn small social-{key}">{label}（準備中）</span>' for key,label in [('instagram','Instagram'),('line','公式 LINE')])
    hero=f'<div class="hero-media"><img class="hero-photo" src="{e(c["hero"])}" alt="{e(c["name"])}のバスケットボール活動風景" width="640" height="640" fetchpriority="high" decoding="async"></div>' if c.get('hero') else '<div class="hero-media"></div>'
    return f'''<header class="header"><div class="wrap nav">{brand}<nav class="navlinks"><a href="#philosophy">チームについて</a><a href="#trial">体験会・入会案内</a><a href="#location">活動場所</a><a class="btn outline small" href="#login">ログイン</a></nav></div></header>
<main><section class="hero">{hero}<div class="wrap"><div class="eyebrow">PLAY TOGETHER. GROW TOGETHER.</div><h1>{e(c['headline'])}</h1><p class="club-area">{e(c['region'])}の小学生・中学生バスケットボールクラブ</p><p>{e(c['intro'])}</p><div class="hero-bottom"><a class="btn lime" href="#trial">体験会に参加する</a><div class="hero-small">小学生・中学生 ／ 初心者も大歓迎</div></div></div><div class="hero-num">CHEETAHS</div></section>
<div class="wrap"><div class="notice"><b>NEWS</b><span>{e(c['notice'])}</span></div></div>
<section class="section wrap" id="philosophy"><div class="about-grid"><div><div class="eyebrow">OUR PHILOSOPHY</div><h2>バスケを通して、<br>「生きる力」を育てる。</h2></div><div><p>{e(c['philosophy'])}</p><div class="values"><div><span>01</span>挑戦する心</div><div><span>02</span>仲間への敬意</div><div><span>03</span>考える力</div></div></div></div></section>
<section class="section schedule-section" id="trial"><div class="wrap"><div class="section-title"><div><div class="eng">TRYOUT SCHEDULE</div><h2>その一歩が、夢中のはじまり。</h2></div><p class="tryout-intro">{e(c['recruit'])}</p></div><div class="schedule-grid">{cal}<div>{cards}<p class="hint">持ち物：{e(c['equipment'])}</p></div></div><noscript>カレンダー操作・申込・会員ログインにはJavaScriptを有効にしてください。</noscript></div></section>
<section class="section wrap" id="location"><div class="section-title"><div><div class="eng">OUR HOME COURT</div><h2>練習場所・練習風景</h2></div></div><div class="location-grid"><div>{image}</div><div><h3>{e(c['place'])}</h3><p class="muted">{e(c['address'])}</p><div class="info-row"><b>練習日</b><span>{e(c['practice'])}</span></div><div class="info-row"><b>持ち物</b><span>{e(c['equipment'])}</span></div><div class="social">{social}</div></div></div></section>
<section class="section wrap faq-section" id="faq"><div class="section-title"><div><div class="eng">FAQ</div><h2>体験・入会についてのよくある質問</h2></div></div>{faqs}</section></main>
<footer class="footer"><div class="wrap">{brand}<p>{e(c['subname'])}<br>© 2026 {e(c['name'])} BASKETBALL CLUB</p></div></footer><div class="demo-strip">操作体験用デモ ｜ 日程・人物・活動場所はサンプルです</div>'''

def render_document(template,c,events):
    import re
    c=public_content(c)
    title=escape(c['seo_title'] or f"{c['name']}｜{c['region']}のバスケットボールクラブ",quote=True)
    description=escape(c['seo_description'],quote=True)
    template=re.sub(r'<title>.*?</title>',lambda _:f'<title>{title}</title>',template)
    template=re.sub(r'<meta name="description"[^>]*>',lambda _:f'<meta name="description" content="{description}">',template)
    schema=json.dumps(structured_data(c),ensure_ascii=False).replace('<','\\u003c').replace('>','\\u003e').replace('&','\\u0026')
    head=f'<meta name="robots" content="noindex, nofollow"><meta property="og:type" content="website"><meta property="og:locale" content="ja_JP"><meta property="og:site_name" content="{escape(c["name"],quote=True)}"><meta property="og:title" content="{title}"><meta property="og:description" content="{description}"><script type="application/ld+json" id="club-schema">{schema}</script>'
    return template.replace('</head>',head+'</head>').replace('<div id="app"></div>','<div id="app">'+render_public(c,events)+'</div>')
