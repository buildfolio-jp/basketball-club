"""Advance active members once per Japanese school year (April 1, JST)."""
from datetime import datetime, timezone, timedelta
import re
JST=timezone(timedelta(hours=9))
def year(today=None):
    today=today or datetime.now(JST).date()
    return today.year-(today.month<4)
def init(c):
    c.execute('CREATE TABLE IF NOT EXISTS member_school_year(user_id TEXT PRIMARY KEY,school_year INTEGER,grade TEXT)')
    c.execute('CREATE TABLE IF NOT EXISTS grade_changes(id INTEGER PRIMARY KEY,user_id TEXT,old_grade TEXT,new_grade TEXT,school_year INTEGER,updated TEXT)')
def next_grade(grade,steps):
    grade=grade.strip().translate(str.maketrans('１２３４５６','123456'))
    if grade=='年長':index=0
    else:
        m=re.fullmatch(r'(小学|中学)([1-6])年(?:生)?',grade)
        if not m or (m[1]=='中学' and int(m[2])>3):return grade
        index=int(m[2])+(6 if m[1]=='中学' else 0)
    index+=steps
    return '小学%d年'%index if index<=6 else '中学%d年'%(index-6) if index<=9 else '卒業'
def anchor(c,uid,grade,today=None):
    c.execute('INSERT OR REPLACE INTO member_school_year VALUES(?,?,?)',(uid,year(today),grade))
def sync(c,today=None):
    current=year(today);changed=False
    for u in c.execute("SELECT id,grade FROM users WHERE role='member' AND active=1").fetchall():
        previous=c.execute('SELECT school_year,grade FROM member_school_year WHERE user_id=?',(u['id'],)).fetchone()
        if not previous or previous['grade']!=u['grade']:
            anchor(c,u['id'],u['grade'],today);continue
        if current<=previous['school_year']:continue
        grade=next_grade(u['grade'],current-previous['school_year'])
        if grade!=u['grade']:
            c.execute('UPDATE users SET grade=? WHERE id=?',(grade,u['id']))
            c.execute('INSERT INTO grade_changes(user_id,old_grade,new_grade,school_year,updated) VALUES(?,?,?,?,?)',(u['id'],u['grade'],grade,current,datetime.now(JST).isoformat(timespec='seconds')))
            changed=True
        anchor(c,u['id'],grade,today)
    return changed
