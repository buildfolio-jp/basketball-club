"""Staff actual work logs and administrator-only weekly approval."""
from datetime import date,timedelta,datetime
from zoneinfo import ZoneInfo
import uuid

def init(c):
    c.executescript('''CREATE TABLE IF NOT EXISTS staff_activity(id TEXT PRIMARY KEY,user_id TEXT,date TEXT,start TEXT,end TEXT,break_minutes INTEGER,minutes INTEGER,note TEXT,updated TEXT);
    CREATE TABLE IF NOT EXISTS staff_week_approval(user_id TEXT,week TEXT,approved INTEGER,approved_by TEXT,updated TEXT,PRIMARY KEY(user_id,week));''')
def week(day):
    d=date.fromisoformat(day);return (d-timedelta(days=d.weekday())).isoformat()
def read(c):
    logs=[dict(r) for r in c.execute('SELECT * FROM staff_activity ORDER BY date,start')]
    approvals=[dict(r) for r in c.execute('SELECT * FROM staff_week_approval')]
    groups={}
    for r in logs:
        key=(r['user_id'],week(r['date']));g=groups.setdefault(key,{'user_id':key[0],'week':key[1],'dates':set(),'minutes':0});g['dates'].add(r['date']);g['minutes']+=r['minutes']
    return {'logs':logs,'approvals':approvals,'weeks':[{'user_id':g['user_id'],'week':g['week'],'days':len(g['dates']),'minutes':g['minutes']} for g in groups.values()]}
def save(c,u,d):
    if u['role'] not in ('coach','admin'):raise ValueError('スタッフ専用です。')
    uid=d.get('user_id');target=c.execute("SELECT 1 FROM users WHERE id=? AND role IN ('coach','admin')",(uid,)).fetchone()
    if not target:raise ValueError('コーチ・スタッフを選択してください。')
    now=datetime.now(ZoneInfo('Asia/Tokyo')).isoformat(timespec='seconds')
    if d.get('action')=='approval':
        if u['role']!='admin':raise ValueError('承認を変更できるのは管理者のみです。')
        w=week(d['week'])
        if w!=d['week']:raise ValueError('週の開始日を確認してください。')
        if d.get('approved') and not any(r['user_id']==uid and r['week']==w for r in read(c)['weeks']):raise ValueError('活動実績がありません。')
        c.execute('INSERT OR REPLACE INTO staff_week_approval VALUES(?,?,?,?,?)',(uid,w,int(bool(d.get('approved'))),u['id'],now));return
    if uid!=u['id'] and u['role']!='admin':raise ValueError('他のスタッフの実績は編集できません。')
    rid=d.get('id') or uuid.uuid4().hex
    old=c.execute('SELECT * FROM staff_activity WHERE id=?',(rid,)).fetchone()
    if old and old['user_id']!=uid:raise ValueError('対象者が違います。')
    day=d.get('date','');w=week(day)
    for check in set([w]+([week(old['date'])] if old else [])):
        a=c.execute('SELECT approved FROM staff_week_approval WHERE user_id=? AND week=?',(uid,check)).fetchone()
        if a and a[0]:raise ValueError('承認済みです。管理者が未承認に戻してから編集してください。')
    if d.get('delete'):
        c.execute('DELETE FROM staff_activity WHERE id=? AND user_id=?',(rid,uid));return
    def minute(v):
        t=datetime.strptime(v,'%H:%M');return t.hour*60+t.minute
    start,end=d.get('start',''),d.get('end','');a,b=minute(start),minute(end);rest=int(d.get('break_minutes',0))
    if b<=a or rest<0 or rest>=b-a:raise ValueError('終了時刻と休憩時間を確認してください。日をまたぐ活動は日ごとに登録してください。')
    for r in c.execute('SELECT * FROM staff_activity WHERE user_id=? AND date=? AND id<>?',(uid,day,rid)):
        if a<minute(r['end']) and b>minute(r['start']):raise ValueError('同じ時間帯の実績が登録されています。')
    c.execute('INSERT OR REPLACE INTO staff_activity VALUES(?,?,?,?,?,?,?,?,?)',(rid,uid,day,start,end,rest,b-a-rest,str(d.get('note',''))[:2000],now))
