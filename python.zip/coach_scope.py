"""Category visibility for coaches, including delegated administrative screens."""
import re

ALIASES={'U15A':'U15アドバンス','U15B':'U15ベーシック','女子U9':'女子U９','男子Aチーム':'男子A','男子Bチーム':'男子B','女子A':'女子U９','女子B':'女子U12','U15アドバンス':'U15アドバンス','U15ベーシック':'U15ベーシック'}
ORDER=('男子A','男子B','女子U９','女子U12','U15アドバンス','U15ベーシック')
def categories(value):
 return {ALIASES.get(x,x) for x in re.split(r'[、,，\s]+',str(value or '')) if x}
def applies(u):return bool(u and (u.get('role')=='coach' or u.get('delegated_coach')))
def assigned(c,u):
 r=c.execute('SELECT grade FROM users WHERE id=?',(u['id'],)).fetchone()
 return categories(r[0] if r else '') & set(ORDER)
def context(c,u):
 cats=assigned(c,u)
 members={r['user_id'] for r in c.execute('SELECT * FROM member_categories') if categories(r['categories']) & cats}
 events={r['id'] for r in c.execute('SELECT id,group_name FROM events') if categories(r['group_name']) & cats}
 results={r['id'] for r in c.execute('SELECT id,group_name FROM results') if categories(r['group_name']) & cats}
 all_members={r[0] for r in c.execute("SELECT id FROM users WHERE role='member'")}
 return cats,members,events,results,all_members

def filtered(c,u,value):
 if not applies(u):return value
 cats,members,events,results,all_members=context(c,u)
 def allowed(r):
  if r.get('event_id') and r['event_id'] not in events:return False
  if r.get('result_id') and r['result_id'] not in results:return False
  if r.get('user_id') in all_members and r['user_id'] not in members:return False
  if r.get('id') in all_members and r['id'] not in members:return False
  if r.get('group_name') and r['group_name']!='全員' and not categories(r['group_name']) & cats:return False
  return True
 def walk(v):
  if isinstance(v,list):return [walk(r) for r in v if not isinstance(r,dict) or allowed(r)]
  if isinstance(v,dict):return {k:walk(x) for k,x in v.items()}
  return v
 return walk(value)

def data(c,u,d):
 if not applies(u):return d
 d=filtered(c,u,d);cats,members,events,_,_=context(c,u)
 d['coach_categories']=[x for x in ORDER if x in cats]
 d['events']=[e for e in d.get('events',[]) if e['id'] in events]
 # Contacts are keyed by member id rather than represented as rows.
 if isinstance(d.get('guardian_contacts'),dict):d['guardian_contacts']={k:v for k,v in d['guardian_contacts'].items() if k in members}
 return d

def check(c,u,d):
 if not applies(u):return
 cats,members,events,results,all_members=context(c,u)
 def visit(v):
  if isinstance(v,list):
   for r in v:visit(r)
  elif isinstance(v,dict):
   if (v.get('event_id') and v['event_id'] not in events) or (v.get('result_id') and v['result_id'] not in results) or (v.get('user_id') in all_members and v['user_id'] not in members):raise PermissionError('担当カテゴリの情報のみ操作できます。')
   if v.get('group_name') and v['group_name']!='全員' and not categories(v['group_name']) <= cats:raise PermissionError('担当カテゴリを選択してください。')
   for x in v.values():
    if isinstance(x,(dict,list)):visit(x)
 visit(d)


def check_request(c,u,path,d):
 if not applies(u):return
 check(c,u,d)
 rid=d.get('id')
 if not rid:return
 table_keys={'event':('events','event_id'),'event_briefing':('events','event_id'),'result':('results','result_id'),'skill_video':('skill_videos','group_name'),'worksheet':('worksheets','user_id'),'portal':('portal_entries','user_id'),'shop_delivery':('shop_orders','user_id')}
 spec=table_keys.get(path)
 if not spec:return
 table,key=spec
 row=c.execute('SELECT * FROM '+table+' WHERE id=?',(rid,)).fetchone()
 if row:check(c,u,{key:rid if key in ('event_id','result_id') else row[key]})
